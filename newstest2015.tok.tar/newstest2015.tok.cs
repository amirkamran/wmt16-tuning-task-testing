petr čech : přestup na poslední chvíli ?
možné je všechno
dnešek je posledním dnem , kdy lze ještě proskočit transferním oknem a udělat velký přestup .
další šance přijde až v zimě .
petr čech , momentálně náhradní brankář chelsea , teď ale nesedí nad novou profesionální smlouvou v madridu , monaku ani paříži .
sedí ve smíchovském nh hotelu , hovoří s českými novináři a chystá se s českou reprezentací na herní generálku s američany a následně také na ostrý start kvalifikace o euro 2016 proti nizozemsku .
v brance chelsea dostává v nové sezoně premier league přednost thibaut courtois , čech se poprvé za deset let v londýnském klubu dostal do pozice náhradníka .
před časem se spekulovalo , že by o čecha mohl mít zájem real madrid .
ten v úvodu sezony ztratil španělský superpohár v soubojích s atlétikem a nezvládl ani vstup do ligové sezony , když prohrál 2 : 4 v san sebastiánu .
spekulovalo se také o zájmu paris sg .
ten do sezony francouzské ligy odstatoval dvěma výhrami a dvěma remízami , v neděli rozstřílel st . etienne 5 : 0 .
relativně nejvíc tlačí bota klub as monaco .
ten má v lize zatím bilanci 1-1-2 a o víkendu se rozešel s lille smírně 1 : 1 .
na bulvárních anglických webech dnes vyskočily zprávy , že by čecha mohli chtít v queens park rangers .
podle anglických bookmakerů ale čechův odchod z chelsea na poslední chvíli není příliš pravděpodobný .
skybet na něj vypsal kurz 4 : 1 .
petře , je možné , že ještě během zbývajících několika hodin změníte dres ?
já s tím nepočítám , ale ve fotbale není nikdy nic stoprocentní .
třeba během dne přijde nabídka , která nepůjde odmítnout .
jak by taková nabídka musela vypadat ?
( směje se ) &quot; no tak to ještě nevím , jak taková nabídka , co ji nelze odmítnout , vlastně vypadá .
muselo by dojít ke shodě všech stran především by záleželo na postoji chelsea , jestli by případnou nabídku klub řešil , nebo ne .
je vůbec technicky realizovatelné takový přestup udělat , když jste teď v praze ?
nebylo by potřeba , abyste někde v novém působišti případný nový kontrakt podepsal ?
tak nad tím jsem neuvažoval .
ale v takové situaci je dneska spousta hráčů , všichni jsou někde na reprezentačních srazech a určitě se dneska ještě spousta přestupů uzavře .
takže nějak realizovatelné by to jistě bylo .
kolik je na planetě klubů , které by si vás mohly dovolit ?
no tak to vážně nevím .
a vy tedy na odchod netlačíte ?
situace , kdy jsem v prvních třech zápasech nové sezony nechytal , je pro mě po patnácti letech kariéry nová .
nicméně není důvod panikařit , balit se a někam odcházet .
já se chci toho souboje o pozici brankáře chelsea nadále účastnit a je na trenérovi , koho vybere , jaká rozhodnutí v průběhu následujících týdnů udělá .
jakou roli ve vašem rozhodování hraje rodina ?
v úvahu beru všechny faktory .
podstatné je pro mě pochopitelně sportovní hledisko , ale dívám se na to i z osobní stránky , do které potřeby rodiny samozřejmě patří .
je možné , že byste chytal i za jiný klub v anglii ?
to je otázka , o níž jsem si myslel , že se mě nikdy týkat nebude .
ale ve fotbale je možné všechno .
nechci nic vylučovat .
neznám odpověď .
předsedové vlády indie a japonska na setkání v tokiu
nový indický předseda vlády narendra modi je v tokiu na setkání se svým japonským protějškem shinzo abem . na své první větší návštěvě od květnového vítězství ve volbách má projednat ekonomické a bezpečnostní závazky .
modi je na pětidenní cestě do japonska , aby tam upevnil ekonomické vazby s třetí největší světovou ekonomikou .
na seznamu jsou v první řadě plány na rozsáhlejší spolupráci v oblasti jaderné energetiky .
podle zpravodajů indie také doufá , že se oba národy dohodnout na spolupráci v otázkách obrany .
policie v karratě po motocyklové honičce zatkla dvacetiletého mladíka
motorku zastavili poté , co se zónou s maximální povolenou rychlostí 70 km / h řítila 125 km / h a zajela do buše , aby policistům unikla .
hlídkující dopravní policie se ráno v karratě pokusila u krajnice zastavit modrou motorku , když si všimli , že při výjezdu z čerpací stanice na bathgate road jede 125 km / h .
podle policie řidič nezastavil a pokračoval po burgess road a poté zahnul do buše , takže ho policisté ztratili z dohledu .
motorka a osoba , která odpovídala popisu řidiče , poté byly spatřeny v domě ve walcott way v bulgaře .
karrathská policie obvinila dvacetiletého mladíka z neuposlechnutí výzvy k zastavení a neopatrného řízení .
před soudem v karratě stane 23. září .
motocykl byl na tři měsíce zabaven .
george webster obviněn ze znásilnění v hotelech v nairn a pitlochry
muž bude postaven před soud kvůli obvinění ze znásilnění žen ve dvou hotelích .
george webster , 28 , byl s obviněním seznámen během slyšení u nejvyššího soudu v glasgow .
údajně měl 7. června 2013 ve scotland &apos; s hotel v pitlochry v hrabství perthshire znásilnit ženu .
podle tvrzení ji webster napadl , zatímco „ nebyla při vědomí , spala a nebyla ve stavu dát svůj souhlas . “
dále je webster stíhán pro znásilnění další ženy v hotelu golf view v nairn na skotské vysočině ze 4. května 2014 .
soudkyně lady rae stanovila datum přelíčení na 17. listopadu u nejvyššího soudu v edinburghu .
obnovení velmi amerického ideálu , že pracovní práva jsou zároveň lidská práva
kongresmeni keith ellison a john lewis navrhli zákon , který má organizování v odborech chránit jako občanské právo .
„ podle toho , jak fungují odbory , fungují pracovní místa pro střední třídu , “ říká ellison , demokratický senátor za minnesotu , který je spolupředsedající kongresového výboru .
proto jsem tak hrdý , že mohu společně se vzorem občasných práv johnem lewisem představit zákon posilující postavení zaměstnanců .
tato průlomová legislativa dá pracovníkům stejné právní možnosti , jak se bránit diskriminaci při organizování v odborech , jako u jiných forem diskriminace - a zastaví protiodborové síly
upravit zákon o pracovních vztazích tak , aby umožňoval všem zaměstnancům , kteří čelí diskriminaci , pokud se chtějí zapojit do odborů , soudit se u civilního soudu - a vysoudit odškodnění nebo náhradu škody - je správná a nutná iniciativa .
určitě to ale není radikální iniciativa - alespoň ne podle amerických standardů .
nejlepším způsobem , jak pochopit , co ellison , lewis a další navrhovatelé v zákonu předkládají , je znovu navázat na americký ideál .
i přes odborové boje , které v proběhly v nedávných letech - ve wisconsinu , michiganu a dalších státech - američani kdysi podporovali země na celém světě , aby přijaly , rozšířily a respektovaly pracovní práva .
byly doby , a miliony američanů je stále pamatují , kdy země jedním dechem prosazovala demokracii , svobodu slova , svobodu tisku a právo na shromažďování .
když spojené státy po druhé světové válce obsadily japonsko , generál douglas macarthur a jeho poradci podporovali zemi , aby přijala ústavu navrženou tak , aby zajistila , že vojenská autokracie hideki toja bude nahrazena demokracií .
byli přesvědčení , že zaměstnanci a jejich odbory hrají roli ve formování nového japonska , zahrnuli do nich jazyk a otevřeně uznali , že „ právo zaměstnanců shromažďovat se , kolektivně vyjednávat a jednat je zaručeno . “
když spojené státy po druhé světové válce obsadily německo , generál dwight david eisenhower a jeho poradci vybízeli němce , aby vytvořili ústavu , která zajistí , že fašismus adolfa hitlera bude nahrazen silnou demokracií .
němci si uvědomovali , že zaměstnanci se budou v novém národu potřebovat organizovat a prosazovat , a proto zahrnuli klauzuli , která otevřeně říká : „ právo vytvářet spolky , které zabezpečí a zlepší pracovní a ekonomické podmínky bude každému jednotlivci a každému povolání nebo profesi garantováno .
ujednání , která budou toto právo omezovat nebo budou usilovat o jeho poškození , budou zrušena . opatření vedoucí ke splnění takového účelu jsou nezákonná .
když bývalá první dáma eleanor rooseveltová předsedala mezinárodní komisi pro lidská práva , která navrhla všeobecnou deklaraci lidských práv , která byla v roce 1948 přijata spojenými národy jako celosvětová smlouva , zahrnuli do ní navrhovatelé a rooseveltová garanci , že „ každý má právo v rámci ochrany svých zájmů vytvářet odbory a vstupovat do nich . “
američané celé generace přijímali základní premisu , že pracovní práva jsou lidská práva .
když země radila jiným zemím , jak vytvářet občanskou a demokratickou společnost , vysvětlovali američané , že právo vytvářet pracovní odbory - a jejich účast v kolektivním vyjednávání s firmami a vládními agenturami v pozici rovnocenného partnera - musí být chráněno .
nyní , když jsou tato práva v americe napadána , je rozhodně nutné , vrátit se k americkému ideálu , že pracující lidé musí mít právo se ve svobodné a otevřené společnosti organizovat a s prosazovat .
jak před padesáti lety řekl reverend martin luther king jr . :
historie je velká učitelka .
dnes každý ví , že odbory sílu národa nezmenšily , ale rozšířily ji .
zvýšily životní standard milionů lidí , vytvořily trh pro průmysl a výrobu pozvedly na netušenou úroveň .
ti , kdo odbory napadají , tyto jednoduché pravdy zapomínají , historie si je ale pamatuje .
historie nezapomíná a my bychom také neměli .
formální uznání pracovních práv jako lidských - a rozšíření ochrany občanských práv tak , aby bránily diskriminaci v organizování odborů - má velké zpoždění .
keith ellison a john lewis obnovují ideály , které pozvedly ameriku a učinily z ní skutečný příslib demokracie .
soudce dočasně zablokoval zákon , který mohl zavřít všechny potratové kliniky v louisianě
federální soudce v neděli dočasně zablokoval louisianský zákon , který by podle advokátů pravděpodobně zavřel všech pět klinik provádějících potraty ve státě .
nařízení uzákoněné podpisem louisianského guvernéra bobbyho jindala v červnu , které má v platnost vstoupit 1. září , by po lékařích provádějících potraty vyžadovalo , aby měli právo přijmout pacientku v nemocnici vzdálené do 30 mil od výkonu jejich praxe .
usnesení soudce znamená , že lékaři mohou dočasně v provádění legálních potratů pokračovat a mezitím si musí toto povolení opatřit .
„ navrhující strana bude moci zákonně provozovat svou činnost a mezitím si získá povolení , “ stojí v usnesení federálního soudce johna degravellese .
slyšení bude naplánované během jednoho měsíce , aby soudce mohl vydat trvalejší usnesení týkající se zákona .
aktivisté za práva na potrat usnesení , které je poslední v sérii podobných opatření , uvítali a řekli , že lékařům poskytne více času na získání povolení .
„ dnešní rozhodnutí zajišťuje ženám v louisianě , že budou v bezpečí před záludným zákonem , který je má připravit o zdraví a jejich práva , “ prohlásila nancy northupová , prezidentka a výkonná ředitelka centra pro reprodukční práva , která se jménem tří z pěti klinik žalobou domáhala zablokování zákona .
nebylo hned jasné , zda se rozhodnutí týká i lékařů ze dvou klinik , které nebyly mezi žalujícími , a také žádají o udělení tohoto povolení .
louisiana je mezi jedenácti státy , které schválily podobné zákony , přičemž soudy v alabamě a mississippi taková opatření ustanovením prohlásily za protiústavní .
klíčové části texaského zákona , které by uzavřely většinu zbývajících klinik ve státě zablokoval federální soudce v pátek .
bojovníci za práva žen na potrat společně se sdružením amerických porodníků a gynekologů a americkou lékařskou asociací tvrdí , že nutnost mít toto povolení klade na lékaře požadavky , které z lékařského hlediska nejsou nutné .
odpůrci potratů oponovali tím , že opatření mají za cíl chránit zdraví žen a někteří také uvítali fakt , že kvůli opatřením by byly kliniky uzavřeny .
centrum pro reprodukční práva uvedlo , že v louisianě má povolení pouze jeden lékař provádějící potraty .
pokud by všichni lékaři ve státě byli přinuceni přestat s prováděním potratů , tento lékař by ze strachu o své bezpečí také přestal zákrok provádět , řekla skupina .
louisianské úřady v reakci uvedly , že by netrestaly lékaře , kteří potraty provádějí , zatímco čekají na vyřízení žádosti o udělení práv.
kvůli pozdní diagnóze a špatné dostupnosti léčby zabíjí na venkově rakovina vaječníků častěji
angelina jolie a její bratr james zveřejnili video s holdem své zesnulé matce , která zemřela na rakovinu vaječníků v roce 2007 .
u žen na australském venkově hrozí vyšší riziko , že zemřou na rakovinu vaječníků , než u jejich protějšků ve městě .
výzkumníci analyzovali lékařské záznamy více než 1100 australanek diagnostikovaných v roce 2005 s rakovinou vaječníků a zjistili , že pouze 35 % pět let po diagnóze žilo .
vedoucí výzkumu susan jordanová z qimr berghofer medical research institute uvedla , že u žen ve venkovských a odlehlých oblastech státu byla asi o dvacet procent vyšší pravděpodobnost , že během studie zemřou než u žen v městských oblastech .
malá studie : nové léky mohou zpomalit rakovinu plic a vaječníků
výzkumníci ženy sledovali během sedmi let léčby .
doktorka jordanová řekla , že šance na přežití ovlivnil věk žen v době diagnózy , typ karcinomu vaječníků , další existující nemoci a socio-ekonomický status .
nejnižší míra přežití se vyskytovala u starších žen , u kterých byla rakovina diagnostikována v pokročilejším stádiu .
u žen ve venkovských a odlehlých oblastech státu byla asi o dvacet procent vyšší pravděpodobnost , že během studie zemřou než u žen v městských oblastech .
přestože studie nebyla navržena tak , aby určila , proč byla u žen žijících mimo město vyšší pravděpodobnost , že zemřou na rakovinu vaječníků , doktorka jordanová tvrdí , že faktory mohou být pozdní diagnóza a špatná dostupnost léčby .
„ nemoc umí nejlépe léčit gynekoonkologové , kteří obvykle sídlí ve větších městech , “ řekla .
i přes zlepšení lékařských služeb na dálku , které mají překonat bariéru v podobě vzdálenosti , doktorka navrhla , že by pomohlo posílení přepravní služby , které specialistům umožní léčit ženy blíž k jejich domovům , a programy na podporu lidí , kteří se léčí daleko od své rodiny a přátel .
doktorka jordanová prohlásila , že studie odhalila , že dlouhodobé přežití žen s rakovinou vaječníků je bez ohledu na zeměpisnou polohou nízké , což zdůrazňuje nutnost lepší léčby a preventivních programů .
výzkum financovaný rio tinto ride to conquer cancer dnes zveřejní medical journal of australia .
v březnu 2012 byla ve svých 33 letech mladá maminka elisha neaveová z města gold coast diagnostikována s agresivní formou rakovinu vaječníků .
zahradní centra litují snížení počtu vlastníků domů
podle studie hta , kterou zveřejnil financial times , pokles spojený s mimořádným úbytkem vlastníků domů mladších 35 let by mohl vést k tomu , že až dnešní mladá generace spotřebitelů dosáhne „ hlavní věkové skupiny zahrádkářů “ , zahradní centra přijdou až o deset milionů liber ročně .
podle zprávy utratí za své zahrady lidé , kteří si bydlení pronajímají , v průměru 55 % částky , kterou utratí lidé bydlící ve svém .
jako další faktory ohrožující odvětví , které vydělává odhadem pět miliard liber ročně , uvádí nárůst počtu lidí žijících ve velmi urbanizovaných oblastech , kde nejsou zahrady , oblibu dláždění místo předzahrádek používané jako parkovací plocha a zmenšující se velikost zahrad .
v oblasti velkého londýna , kde podíl vlastněných domů klesl během šesti let z 61 % na 43 % , připadají na jednu domácnost nejnižší výdaje na zahradnické produkty v británii .
hta a královská zahradnická společnost uvedly , že bydlení v podnájmu nebo nedostatek prostoru neznamená , že by lidé nemohli pěstovat rostliny .
guy barter , hlavní zahradnický poradce pro rhs , řekl : „ u nájemníků je velmi oblíbené pěstování rostlin v květináčích - když se přestěhují , mohou si rostliny vzít s sebou . “
zpráva hta odhalila , že „ zlatý věk “ zahradnického maloobchodního sektoru byl mezi lety 1997 a 2005 a byl výsledkem vyššího podílu vlastníků domů a ekonomické prosperity trvající od 80. do poloviny 90. let .
také na tento rok předpověděl vyšší odbyt díky lepšímu počasí , které přišlo po nepříznivých podmínkách v březnu a dubnu .
když východní diktátor káže o demokracii .
poté co putin na srazu své mládežnické organizace , která mi ze všeho nejvíce připomíná hitlerjugend , zachrastil atomovými zbraněmi a v podstatě všem dal najevo , že jejich názory jsou mu ukradené , udělil nám dnes přednášku o demokracii .
já mám ale takový pocit , že současný režim v rusku vykazuje mnoho rysů fašistického státu .
velké národy mají jedno společné a to je to , že je dokáže ovládnou jak vypjatý nacionalismus , tak i to že komplex méněcennosti dokáží transformovat v imperialistické choutky .
čas plyne na východě zřejmě jinak , než na západě .
zatímco západní svět si myslel , že doba válek o nadvládu nad evropou je už dávno pryč , na východě si naopak myslí , že přehlíženi byli již dlouho a je třeba získat si zpět svou mezinárodní pozici .
taková nálada a frustrace vládla v německu v třicátých letech , těsně před uchopením moci nacisty a pak následoval výbuch nacionalismu nepodobný dnešní situaci v rusku .
a pak ten zcela shodný kult silného vůdce , mlácení novinářů , likvidace nepohodlných politických oponentů , diskriminace menšin a homosexuálů , to je tedy věru dosti podobné .
vladimírovi putinovi a určitě i velké části rusů se asi stýská po době , kdy rusko vládlo půlce světa a druhá část se před nimi třásla .
asi si to západní politici zavinili sami , možná málo vladimíra poplácávali po ramenou , možná ho nepozvali tam kam toužil a možná ho začali podceňovat a on se prostě jen zachoval jako typický ruský mužik .
udělal si pořádek doma , tvářil se , že on vlastně nikam ani nechtěl a brousil doma nože .
teď se rozhodl , že dobude zpět ztracené pozice .
začne pomalu , má čas.
vůdcem je asi na doživotí , tak kam by spěchal .
pošlapal kavkazany , teď pošlape ukrajince , pak jsou na řadě trpaslíci z pobaltí .
ti už ruského medvěda štípou v kožichu dost dlouho .
toho už si určitě všimne i čína , která si nějak moc vyskakuje a určitě si dělá zálusk na dálný východ .
a ti němci toho vladimíra taky pěkně štvou , jak se mají dobře a to jsem jim dali v 45 tak na zadek .
co takhle udělat jednu novou novorosiju v karlových varech .
to by byla základnička a našich je tam spousta a jak je tam utiskují i daču už chtěli leckterému z nich zbourat .
vždyť naši veteráni doteďka vzpomnají , jak se v tom československu měli .
nu vot vždyť ten jejich premiér gospodin sobotka , ten je tak měký , dá se loupat jako cibule a sním celá ta jejich eu .
to by tak hrálo , aby si na veliké rusko vyskakovali .
je třeba jim připomenout , kde je jejich místo .
a jako rozbušky použijeme naše soukmenovce , kteří bydlí na jejich území .
rusů je všude dost a když se řekne , že je tam utiskují , tak je tam prostě utiskují a to my tak nenecháme , my je ochráníme .
a zase bude rus vládnout , vždyť k čemu jinému je zrozen .
evropa je přeci dobrá jen jako předložka , na které může hrdý ivan tančit kozáčka .
turecko si předvolalo amerického diplomata kvůli špionážní zprávě
turecký ministr zahraničí si zavolal nejvýše postaveného amerického diplomata v zemi , aby vysvětlil zprávu o americké a britské špionážní aktivitě v turecku .
náměstek předsedy vlády bulent řekl , že americký charge d &apos; affaires a turečtí státní úředníci o zprávě jednali v pondělí .
německý magazín der spiegel a internetový magazín the intercept uvedly , že podle dokumentů poskytnutých bývalým analytikem americké národní bezpečnostní agentury bylo turecko prioritním cílem amerických a britských zpravodajských služeb .
podle tureckých sdělovacích prostředků bagatelizoval turecký prezident recep tayyip erdogan důležitost zprávy a prohlásil , že všechny významné státy se navzájem sledují .
starší zpráva , podle které se na ankaru zaměřila i německá zpravodajská služba , vyvolala u turecké vlády rozhořčenější reakci .
seriál hra o trůny představil další triky čtvrté řady
tvůrci hry o trůny momentálně natáčejí epizody páté řády kultovního seriálu .
zároveň se pochlubili tím , jak vznikaly triky čtvrté řady .
nejviditelnější jsou počítačové úpravy seriálového prostředí a masové scény , kdy se z hloučku vojáků stane obří armáda slavné daenerys .
ředitel policie v magalufu obviněn z korupce
stěžovatelé v pátek předložili úřadu mallorského státního prokurátora důkazy o vydírání ze strany policistů a státních úředníků radnice v samosprávní oblasti calvia .
ředitel policie v calvia na prázdninovém ostrově mallorca byl zatčen po obvinění vznesených podnikateli a majiteli barů v nechvalně proslulé večírkové čtvrti v magalufu .
vrchní inspektor josé antonio navarro byl vzat do vyšetřovací vazby poté , co proti němu vzneslo obvinění z korupce několik podnikatelů z punta ballena , ulice , ve které se nachází většina barů a nočních podniků v magalufu .
podle internetového deníku mallorca diario předložili v pátek stěžovatelé prokurátorovi mallorského úřadu pro potírání korupce důkazy o vydírání ze strany policistů a státních úředníků radnice v samosprávní oblasti calvia .
dva další místní policisté byli zatčeni španělskou státní policií kvůli spojitosti s obviněním z korupce a společně s navarrem je vyslechne soudce .
španělský celostátní deník abc citoval nespokojené majitele nočních podniků , podle kterých má zvýhodňování ze strany veřejných činitelů vážné dopady na jejich podnikání .
„ už dávno to není o vydělávání peněz , ale o přežití , “ řekl u soudu jeden z podnikatelů .
nezahrávejte si s naším živobytím .
nemáme co ztratit .
magaluf se dostal na hlavní stránky časopisů na celém světě poté , co se na youtube objevilo video osmnáctileté britské turistky , která během turné po barech poskytla orální sex 24 mužům .
ostrovní úřady se od té doby snaží dohlížet na opilce a výtržníky v řadách účastníků prázdninových večírků v magafulu snižováním počtu nechvalně známých alkoholových turné po barech .
navíc klub playhouse , kde došlo k události s poskytováním orálního sexu , byl nucen na rok zavřít a společně s organizátory turné po barech společností carnage zaplatit pokutu 55 000 euro ( 73 000 dolarů ) .
turistický resort magaluf , který je oblíbený především u britů , byl také svědkem mnoha nehod pod vlivem alkoholu včetně módní vlny známé jako „ balconing “ , při kterém lidé skáčou z jednoho balkonu na druhý nebo z balkonu do hotelového bazénu .
první jarní den poznamenán deštěm a bouřkami , které měly dopad na let na letišti v adelaide
jaro přineslo jihu jižní austrálie ledové překvapení , přišlo se silným deštěm a prudkým větrem , které vážně zasáhly letiště v adelaide .
dalších 5 mm srážek má ve městě připadnout až do devíti hodin večer a dalších 6,6 mm připadne během noci na neděli .
poslední déšť se představil společně s několika krátkými přeháňkami spojenými s bouřkou a poryvy větru , které začaly před osmou hodinou večer a během asi deseti minut přinesly téměř 4 mm srážek .
poté , co po zimě minulý týden přišlo několik časných dávek jara , klesly v pondělí teploty ve městě opět na pouhých 15,8 ° c .
má se za to , že bouřkové počasí přispělo ke zpožděnému příletu virgin airlines z melbourne do adelaide .
letadlo mělo přistát chvíli po 19 : 30 , na krátké vzdálenosti ho ale zasáhla změna rychlosti nebo směru větru a bylo nuceno přistání odložit .
poryvy větru na letišti v adelaide v tu dobu dosahovaly na zemi rychlosti okolo 50 km / h .
letová data ukazovala , že letadlo muselo od druhého přistání upustit a nakonec dosedlo asi ve 20 : 40 .
zpoždění letadla následně způsobilo zpoždění dalších letů včetně letu společnosti emirates z dubaje a letu společnosti qantas ze sydney .
podle předpovědi dosáhnou v úterý teploty v adelaide maximálně 16 ° c a mohou se objevit jedna nebo dvě přeháňky .
izraelské děti se po válce v gaze vrací do školy
tisíce izraelských dětí z oblastí v blízkosti pásma gazy se v pondělí vrátily do školy poté , co strávily léto v protibombových krytech , zatímco během padesátidenní války mezi izraelem a hamásem na jejich domovy útočily rakety a minomety . školy v gaze však zůstávají zavřené , zatímco se území vzpamatovává z bojů .
začátek školy přinesl do komunit na jihu izraele poznamenaných útoky pocit radosti a vzrušení , ale známky bojů jsou stále patrné .
v ašdodu , městě na jihu země , zaměstnanci školky , kterou zasáhla raketa , odstranili ze zdi pozůstatky po střepinách a pozvolna očekávají návrat dětí .
„ máme trochu strach , ale jinak se těšíme , “ řekla ronit bartová , obyvatelka kibucu saad a učitelka angličtiny na místní škole .
hodně dětí z této oblasti se už opravdu potřebuje vrátit ke každodenní rutině .
její jedenáctiletá dcera shani bartová prozradila , že „ je to trochu zvláštní “ chodit najednou znova do školy .
„ prožili jsme si pár těžkých chvil a vůbec jsme neopustili dům , “ řekla .
kibuc , který se nachází blízko hranic s gazou , navštívil prezident reuven rivlin , aby obyvatelům nabídl svou podporu .
dokud zastavení palby minulý týden válku neukončilo , tisíce obyvatel hraničních osad jako je saad zůstaly uvnitř svých domů nebo své domovy opustily a vydaly se do bezpečnějších oblastí dál od gazy , aby unikly raketám a minometům .
mnoho obyvatel nachal oz , vesnice blízko hranice s gazou , ve které střela z palestinského minometu zabila čtyřletého chlapce , s návratem váhá .
ministr školství uvedl , že asi dvanáct rodin se stále nevrátilo .
jejich děti byly dočasně umístěny do náhradních škol .
předseda vlády benjamin netanjahu navštívil školu v sderotu , městě na hranici s gazou , které bylo palestinskou palbou silně zasaženo .
nabádal děti , aby pilně studovaly , a dodal : „ zajistíme vám vzdělání a bezpečí . “
izrael a hamás se minulé úterý dohodly na časově neomezeném míru .
zastavení palby sice vedlo k okamžitému ukončení bojů , nevyřešilo však klíčové problémy jako požadavek hamásu na ukončení izraelsko-egyptské blokády gazy a znovuotevření letišť a přístavů v gaze .
izrael požaduje odzbrojení hamásu a navrácení těl dvou vojáků padlých ve válce .
očekává se , že nové kolo nepřímých jednání začne později v tomto měsíci v egyptě .
podle odhadů palestinců a osn ve válce zemřelo více než 2 100 palestinců , z nichž tři čtvrtiny tvořili civilisté a nejméně 494 dětí .
izrael tato čísla zpochybňuje a odhaduje , že alespoň polovina zabitých byli radikálové , přestože pro tato tvrzení nemá jasné důkazy .
na izraelské straně zemřelo 66 vojáků a šest civilistů včetně thajského dělníka .
hamás a další radikálové z gazy vystřelili během bojů na izraelská města především na jihu země 4 591 raket a střel z minometů .
izraelská armáda zase podnikla víc než 5 000 vzdušných náletů a dalších útoků .
izraelské útoky poškodily nebo zničily tisíce domů v gaze a odhadem 250 000 lidí se ukrylo ve stovce škol osn , které se přeměnily v provizorní přístřeší .
kvůli desítkám tisíc lidí , které stále zůstávají v úkrytech , a kvůli trvajícím bojům odložili minulý týden školští úředníci začátek školního roku .
„ doufám , že školu brzo otevřou , abychom si mohli dokončit vzdělání stejně jako židovské děti a ostatní děti na světě , “ řekl mohammad amara , třináctiletý chlapec ze školy v největším městě gazy .
vrba na srazu : za váchou si stojím .
a lafatu trápí teplota
česká fotbalová reprezentace se dnes před polednem v praze sešla před středečním přípravným zápasem s usa a následným úvodním utkáním kvalifikace mistrovství evropy proti nizozemsku .
z třiadvacetičlenného kádru má problémy sparťanský útočník david lafata , kterého trápí teplota .
david tady ještě není , ale sparta měla minulý týden nějaké problémy , šlo o více hráčů a david ještě asi trošku ty problémy má .
ale chceme , aby tady byl a byl co nejdříve v pořádku , &quot; řekl novinářům trenér pavel vrba .
&quot; jestli to budou dva nebo tři dny , nebo už zítra bude fit , to se uvidí podle jeho zdravotního stavu , o kterém rozhodne náš doktor , &quot; dodal .
ostatní hráči jsou v pořádku .
&quot; samozřejmě někdo má nějakou bolístku , ale není to takové , že by nemohli trénovat nebo se zúčastnit zápasu ve středu s usa , &quot; prohlásil český trenér .
v neděli večer vrba povolal jako posledního hráče sparťanského záložníka lukáše váchu .
připustil , že to nebylo snadné rozhodování , v úvahu připadali i jiní středopolaři .
rozhodl jsem se na základě toho , že lukáš je perspektivní hráč , kterému je 25 let .
rozhodování to bylo hodně složité , ale já si za tím stojím , &quot; podotkl vrba k váchovi .
a co šural ?
uvidíme , co bude s latatou
není vyloučeno , že v případě zdravotních problémů by se nominace ještě mohla změnit .
o víkendu se skvělým výkonem blýskl například liberecký josef šural , který dal hattrick .
samozřejmě jsou hráči , kteří v poslední době ukazují formu .
uvidíme , jak na tom bude david lafata .
v případě , když nebude moci ve středu být k dispozici , netvrdím , že nemůžu donominovat někoho z hráčů , kteří v české lize zaujali , &quot; podotkl vrba .
dnes odpoledne čeká reprezentaci trénink na strahově , v úterý pak klasický předzápasový trénink před duelem s usa na letné , který bude otevřený pro fanoušky a po němž bude následovat autogramiáda .
utkání s američany se hraje ve středu od 20 : 15 a národní tým v něm bude usilovat o premiérové vítězství pod vrbou .
v předešlých třech přípravných zápasech uhrál dvě remízy a jednou prohrál .
kvalifikační souboj s nizozemskem je pak na programu 9. září od 20 : 45 .
pešice jede na nizozemce do itálie
vrba je rád , že má na rozdíl od předešlých srazů více času na trénink .
je výhoda , když máte hráče osm dní a můžete s nimi nacvičovat určité věci , na které jsme třeba předtím neměli tolik času .
teď se budeme moci soustředit jen na to , abychom se co nejlépe připravili na nizozemsko , &quot; pochvaloval si vrba .
nizozemci se ještě před utkáním v praze představí ve čtvrtek v itálii a duel bude osobně sledovat bývalý dočasný reprezentační kouč josef pešice .
dá nám informace , které ze zápasu jsou .
ale nebude to jen o něm , budeme mít zápas i natočený a budeme si ho rozebírat .
k nizozemsku přichází nový trenér , uvidíme , jaké změny tam budou , &quot; řekl vrba k bronzovým medailistům z nedávného světového šampionátu .
podle velmi sledovaných statistik ceny bytů v zimním období vzrostly nejvíc za posledních sedm let .
podle indexu hodnoty bytů v australském hlavním městě rp data corelogic hedonic vzrostly v srpnu ceny bydlení o 1,1 % , uvedla v pondělí agentura .
zvýšení vedlo k celkovému nárůstu za červen , červenec a srpen na 4,2 % , nejvyšší zvýšení za zimní měsíce od roku 2007 .
roční nárůst cen se vyšplhal na 10,9 % , více než dvojnásobek za jeden rok do srpna 2013 , zisk však nebyl v zemi rovnoměrně rozložen .
ředitel výzkumu rp data tim lawless uvedl , že na trhu vedou sydney a melbourne .
čísla rp data ukazují , že ceny bytů v sydney minulý rok vzrostly o 16,1 % , zatímco ceny v melbourne o 11,7 % .
mezi další nejsilnější trhy patřily adelaide , brisbane a darwin s nárůstem cen v průměru mezi pěti a šesti procenty .
na druhé straně stupnice se umístila canberra , kterou poškodilo státem nařízené snížení výdajů a kde ceny během roku vzrostly pouze o 1,4 % .
lawless řekl , že když nyní začalo jaro , zvýší se v následujících měsících počet nemovitostí na prodej , což bude pro trh „ opravdovou zkouškou “ .
„ vzhledem k přetrvávající vysoké míře aukčních výprodejů , obecně vysoké rychlosti prodeje a nízké úrokové míře , je pravděpodobné , že hodnota bydlení se během příštích tří měsíců ještě zvýší , “ uvedl .
lenny henry : můj otec mě nikdy neobjal .
nikdy mi neřekl „ mám tě rád “
henry se v roce 1958 narodil jako jedno ze sedmi dětí jamajských přistěhovalců v dudley v midlands .
se svým otcem , který zemřel , když bylo henrymu 19 , a který pracoval v továrně , měli chladnější vztah .
henry zkouší komedii , rudy &apos; s rare records , která se částečně zakládá na imaginárním rozhovoru s jeho otcem a která je součástí sérií radio 4 .
soundtrack je směsicí reggae a rapu a melodie je optimistická .
henry si ale musel poradit s několika nepříjemnými vzpomínkami z dětství .
po smrti matky si henry prošel „ důkladnou “ terapií a teď přemýšlí o svém vztahu s otcem .
věděl toho o něm hrozně málo .
nikdy jste neviděli jeho obličej , jenom jste slyšeli jeho hlas : „ přestaň s tím rámusem .
nech sestru na pokoji .
uhni !
chci se dívat na kriket .
mí starší bratři seymour a hilton - když jsem byl dítě , byli už dospělí - s ním chodili do baru a probírali věci jako je tvar sklenice s pivem nebo krása úderu v kriketu .
já jsem s ním nikdy takhle nemluvil .
většinu mého života to byl vážný chlápek v koutě , co si čte noviny .
nedávno henry navštívil v dudley slévárnu , a přestože podmínky byly lepší než v otcově době , nahlédl do toho , jaký pro něj musel život být .
dneska už je tam o něco víc světla , ale pořád je to temný , zakouřený , pochmurný labyrint , kde vybuchují plameny a je tam hodně kouře a sazí .
táta si vždycky vlezl do vany a jenom tam ležel , pak bylo slyšet , jak si pomalu začíná zpívat pro sebe , protože ze sebe smývá slévárnu .
když jsem šel kolem , uvědomil jsem si , že tohle roky dělal , aby uživil rodinu , a začal jsem si ho víc vážit .
i přesto henry prožil dětství bez rodičovské lásky .
táta nikdo nikoho neobjal , neřekl „ mám tě rád . “
až když byla máma nemocná a umírala , začali jsme si říkat „ mám tě rád , mám tě rád , mám tě rád . “
jeho dcera billie , kterou má s dawn frenchovou , mu umožnila zažít lásku , která mu jako dítěti chyběla .
můžeš už přestat s tím „ mám tě rád “ ?
neobjímej mě pořád !
tati , je mi 22 !
s dawn frenchovou .
proč bychom neměli být přátelé ?
je to skvělá máma
s frenchovou , se kterou byl ženatý 25 let , jsou stále dobří přátelé .
dawn je hodná .
proč bychom s dawn neměli být přátelé ?
je to skvělá máma .
henryho vlastní matka měla cukrovku .
byla to jedna z věcí , která ji zabila .
takže když jsem měl hodně , hodně velkou nadváhu a začínaly se projevovat příznaky cukrovky , doktor mi řekl : „ musíš udělat radikální změnu . “
takže jsem začal chodit do velkého fitness centra a taky jsem musel držet drastickou dietu , abych se zbavil příznaků .
je to hodně těžké .
a únavné .
nikdo nechce jíst samou mrkev .
změna ve směru ubírání henryho kariéry se možná odráží v jeho elegantní , nakrátko ostříhané bradce .
poté , co se mu dostalo uznání od kritiky za jeho othella , ponořil se do divadla .
následovala komedie plná omylů a ploty augusta wilsona .
je to jiná zkušenost než sitcomy a komedie , které vyplňovaly jeho hektický pracovní život .
začínal , když mu bylo 16 a pracoval v továrně .
dj si ho všiml na pódiu , jak někoho paroduje , a napsal o něm do talentové soutěže new faces .
jeho televizní kariéra začala v polovině 70. let : „ dlouho jsem byl jediný černošský imitátor / komik v televizi . “
učil se za pochodu .
kromě toho , že si mě musela všimnout veřejnost , musel jsem se taky mezi lety 1975 a 1985 naučit , jak vymýšlet fungující vtipy , být hvězda a vystupovat v televizi a to bylo opravdu těžké .
lenny v new faces v roce 1975
vzhledem k tomu , že jeho manažer vlastnil práva k jevištní produkci the black and white minstrel show , zábavnímu programu , ve kterém se herci převlékali za černochy , henry v něm se svou komedií nakonec vystupoval pět let .
moje rodina kvůli tomu už byla nesvá .
trochu si přeju , aby se to nikdy nestalo , ale nelituju toho .
i když to byla zvláštní a trapná pozice , pracoval jsem na velkých scénách a učil se , jak pracovat s davem .
to , co byl „ roky a roky oceňovaný hlavní produkt britské televize “ , ale byla zároveň také „ groteskní parodie černochů . “
v 80. letech henry pracoval v alternativních komediálních kruzích a představil postavy , které zároveň zesměšňovaly i oslavovaly britskou černošskou kulturu .
první série the lenny henry show se začala vysílat v roce 1984 a v 90. letech byl mimo jiné známý jako šéfkuchař gareth blacklock v komediálním seriále chef ! .
další desetiletí mu zabraly reklamy , dokumenty , televizní seriály a role ve filmech , ale po odvysílání jeho seriálu lennyhenry.tv na bbc v roce 2008 , si řekl : „ tak co budeš dělat teď , lene , trochu to totiž vypadá , že ses zaseknul na jednom místě , nebo trochu scházíš z cesty . “
další na řadě byl dokumentární pořad na radio 4 nazvaný what &apos; s so great about ... ? / co je tak skvělého na ... ?
první byl shakespeare .
na shakespeara jsem měl vážně alergii .
ve škole jsme se ho pořádně neučili a myslel jsem , že je to něco pro bílou střední třídu .
takže jsem z toho měl strach .
všichni , s kým jsme v pořadu dělali rozhovor , peter hall , trevor nunn , adrian lester , judi denchová , říkali : „ měl bys to zkusit . “
nenavážej se do toho , když nevíš , o čem mluvíš .
zkus si pár slov a uvidíš , proč všichni máme shakespeara tak rádi .
henry pro dokument přednesl dvacet řádků z othellovy závěrečné řeči a už v tom jel .
dalo mi to pocit , že to dokážu .
jako kdyby mi to dodalo odvahu .
„ o tom to je . je to vážná věc , ber to vážně , nauč se text , něco si o tom zjisti .
takže zkoušení bylo tvrdé a předtím jsem tu hru četl měsíce a měsíce .
a byl to úspěch .
vypadalo to , že čekají průšvih , což se nestalo .
brzy začal hrát v komedii plné omylů .
najednou jsem byl v národním divadle . nemohl jsem tomu uvěřit .
v jednu chvíli jsem si pomyslel : „ změnil ses . “
došlo k technické závadě a henry instinktivně cítil , že musí převzít zodpovědnost za zabavení publika .
„ hlásek v hlavě mi řekl : ‚ než spraví počítač , musíš je teď deset minut bavit . ‘ “
místo toho divadelní režisér oznámil , že představení bude pokračovat , jakmile se problém vyřeší .
odešel jsem z jeviště a něco ve mně říkalo : „ hm , díky bohu . “
není to moje zodpovědnost .
může to za mě vyřešit někdo jiný .
„ hraješ , tak zůstaň v roli . “
henry v plotech v duchess theatre
naučit se text plotů byla výzva .
panika je docela dobrá , dodává odhodlání .
hra byla také dobře přijata , takže je to jako boží znamení , které říká : „ tohle bys měl dělat . “
samozřejmě to říká zvučným hlasem .
takže u toho zůstávám .
mám to fakt rád .
jsem rád ve zkušebně .
henrymu přesto zůstává mozek komedianta - celou dobu náš rozhovor přerušuje humornými vystoupeními , kdy vstupuje a vystupuje z role imitátora .
rozhodl jsem se nedělat stand-upy , protože mít uspokojení z místnosti plné cizinců je trochu nebezpečné , řekl bych .
když pořád něco hledáte , můžete se dostat do slepé uličky .
někdy , když chci , dělám live at the apollo , ale už mě to netěší jako dřív .
zeptal jsem se , jestli ještě někdy zorganizuje nějaké stand-up turné .
radost z toho sedět v jedné místnosti s režisérem , který pomáhá dávat obrysy začátku , prostředku a konci cesty - nemyslím , že bych se toho chtěl někdy vzdát .
takže vaše nová inkarnace ?
myslím , že ano .
herectví mě baví .
je to zábava .
pořád vyprávíte příběhy , což je skvělé .
miluju příběhy .
lidé milují příběhy .
keňa registruje státní úředníky , aby si posvítila na neexistující zaměstnance
keňa začala s biometrickou registrací všech svých státních úředníků , aby se pokusila odstranit z výplatní listiny vlády neexistující zaměstnance .
podle prohlášení vlády přestanou zaměstnanci , kteří se v následujících dvou týdnech neregistrují , dostávat výplatu .
vláda se domnívá , že tisíce lidí dostávají plat i poté , co státní službu opustily .
poté , co se v roce 2013 ujal úřadu , přislíbil prezident uhuru kenyatta , že zamezí korupci ve státní správě .
audit provedený v tomto roce ukázal , že stát měsíčně přichází při nejmenším o jeden milion dolarů ( 700 000 liber ) na výplatách neexistujících zaměstnanců a pří dalším zneužití úřední moci .
vláda má podezření , že platy jsou nadále vkládány na bankovní účty i po úmrtí zaměstnance nebo poté , co zaměstnanec státní správu opustí , uvedl reportér bbc z hlavního města nairobi , wanyama chebusiri .
všichni státní úředníci se musí během příštích dvou týdnů dostavit do identifikačních center , kde budou jejich údaje biometricky zaznamenány , uvádí se v prohlášení vlády .
dále říká , že každý , kdo se bez dostatečné omluvy nedostaví , bude vyřazen z výplatní listiny .
„ určením skutečných zaměstnanců veřejné služby toto opatření významně přispěje k jejímu zhospodárnění a také bude použito k pročištění výplatní listiny na obou úrovních vlády , a vyřeší tak problém neexistujících zaměstnanců , “ řekla anne waiguru , tajemnice ministerstva pro rozvoj a plánování .
desítky tureckých policistů zatčeny kvůli „ spiknutí “ proti vládě
místní média uvádí , že v turecku bylo zadrženo kvůli podezření ze „ spiknutí proti vládě “ celkem 33 policistů .
policejní úřad zatím případ nekomentoval .
podle hurriyet dail news bylo mezi zadrženými čtrnáct vysoce postavených úředníků .
někteří z nich byli zapleteni do prosincového vyšetřování korupce , které se zaměřilo na úředníky vlády včetně čtyř ministrů .
v červenci bylo několik tureckých policistů zatčeno pro údajné organizování zločineckého gangu a telefonního odposlouchávání .
turecký prezident recep tayyip erdogan ( v té době předseda vlády ) označil jejich jednání za součást působení islámského duchovního fethullaha gülena proti němu a dalším lidem u moci .
ne všechny děti se na ukrajině vrátily do školy
většina škol na ukrajině se v pondělí ( 1. září ) po letních prázdninách znovu otevřela .
tento den je pro rodiny tradičně důležitý a jako tisíce dalších ukrajinských rodičů i předseda vlády arsenij jaceňuk odvedl svou dceru do školy .
při této příležitosti sdělil přítomným novinářům , že ne všechny školy se znovu otevřely , ale že je rozhodnutý zemi bránit pro příští generace :
ne na všech školách se uskutečnila tradiční ceremonie k 1.září.
ne na celé ukrajině je mír .
musíme za mír bojovat .
celá ukrajina , spojená ukrajinská fronta , musí bojovat za mír .
alexan pastukhov , učitel ve škole ve slavjansku , kterou navštěvuje jaceňukova dcera , promluvil v ruštině .
doufáme , že zde bude konečně dosaženo míru a že děti získají vědomosti , které jim budou v budoucnu užitečné .
první den školy se tradičně slaví tak , že děti si oblečou vyšívané košile , přinesou balonky a učitelům dávají květiny .
v roně fairheadové možná bbc našla šéfku pro těžké časy
nese si s sebou oblaka slávy ze světa bankovnictví , media managementu a interní konkláve konzervativní strany .
sama má zkušenosti z předních linií .
kariéru začala v konzultantské společnosti bain and co , poté pokračovala přes morgan stanley , bombadier , ici a do mediálního světa pearsons .
sedm let byla výkonnou ředitelkou financial times . na funkci rezignovala , když nejvyšší funkci v mateřské společnosti pearson &apos; s obsadil její mladší kolega .
říká se , že její odstupné se blížilo milionu liber .
její politické portfolio je také rozsáhlé .
davidu cameronovi byla doporučena lordem browne , bývalým ředitelem bp , když cameron ve whitehallu potřeboval soukromou expertízu : stala se poradkyní úřadu vlády .
její manžel je bývalý člen městské rady .
v květnu jsem popsal práci ředitele jako kalich s jedem .
nejen , že je bbc rozsáhlá a spletitá entita v centru veřejného života , ale v její struktuře existuje také vnitřní paradox .
korporace se obrací dvěma směry : dovnitř na vrchní vrstvu hierarchie vlastního vedení bbc , ale také ven na hlas veřejnosti v dobách neklidu , když věci nefungují .
jedná se o téměř neudržitelný monopol , který si žádá důkladnou reformu .
který ředitel by ale riskoval , že přijde do firmy složité jako čínská dynastie , rozloží ji a tím sám sebe připraví o práci .
je to těžká výzva .
kdyby to tak těžké nebylo , hodně lidí by rádo vidělo , jak se bbc zmenšuje - její moc , její finance - a jak se reviduje její status .
s tím , jak se rozšiřuje okruh konkurence a nová technologie zpochybňuje staré jistoty , nese s sebou bezprostřední jednání o koncesionářských poplatcích pro bbc velké nebezpečí .
za skromnou částku 145,50 libry ročně si britská veřejnost kupuje podíl v něčem , co je jistě největší mediální podnik na světě .
bbc vypráví dobrou historku : tvrdí , že její produkce dosahuje 96 % domácností a každou přitom stojí jen 40 pencí denně .
navíc obliba bbc očividně stoupá : na 53 % příznivců oproti 31 % před deseti lety .
modely používání služeb bbc se změnily : dnes se mi novinové titulky zobrazují na mobilním telefonu a na pořady , které jsem prošvihl , se můžu podívat na iplayeru .
ale bbc i nadále zůstává velmi milovanou a úžasnou institucí .
potřebuje úžasného ředitele - doufám , že jednoho našla .
texaský guvernér perry tvrdí , že urážlivý tweet neschválil
tweet z oficiálního twitterového účtu texaského guvernéra ricka perryho , který byl zveřejněn v neděli , obsahoval urážlivý obrázek demokratické státní zástupkyně , která iniciovala trestní obvinění perryho ze zneužití pravomoci .
tweet byl později smazán a na perryho účtu byl uveřejněn další , který se od předchozího distancoval .
z mého účtu odešel tweet , který nebyl autorizován .
„ s tweetem nesouhlasím a stáhl jsem ho , “ uvedl v dalším postu .
perryho asistenti neodpověděli na zprávy s dotazy ihned .
přestože tweety byly poslány z perryho oficiálního účtu , není jasné , kdo je ve skutečnosti zodpovědný za jeho správu .
předchozí tweet zveřejnil nelichotivý , humorný obrázek státní zástupkyně travis county rosemary lehmbergové , která byla v dubnu 2013 odsouzená za řízení v opilosti .
když odmítla rezignovat , perry zamítl vyplácení prostředků pro její kancelář , což perryho , možného kandidáta na prezidenta ve volbách 2016 , tento měsíc přivedlo před velkou porotu v austinu .
na popisku v tweetu stálo : „ ne vždycky řídím s třikrát vyšší hladinou alkoholu v krvi než je povolený limit ... ale když už ano , tak zažaluju guvernéra perryho , že mě za to vyzývá k odpovědnosti . “
jsem nejopilejší demokratka v texasu .
vyšetřování proti perrymu nevedl úřad lehmbergové .
na starosti ho měl michael mccrum , zvláštní prokurátor ze san antonia , který byl určen republikánským soudcem .
perry byl shledán nevinným a obvinění nazval taktickým , politickým manévrem .
jeho kvalifikovaný právnický tým požádal soudce dohlížejícího na případ , aby obvinění zamítl , protože využití zákonů k soudnímu stíhání nejdéle sloužícího guvernéra v texaské historii je protiústavní .
perry přerušil vyplácení 7,5 milionu dolarů ze státního fondu pro oddělení hájení veřejného zájmu , které má sídlo v travis county a stíhá korupci v texasu , poté , co lehmbergová odmítla rezignovat .
zamítnutí vyvolalo formální stížnost levicově orientované skupiny občanských aktivistů .
perryho oficiální účet je aktivní - a někdy se i proslaví .
poté , co v iowě během své prezidentské kampaně v roce 2012 skončil na pátém místě ve výboru své strany , odpověděl perry na spekulace o tom , že by už mohl skončit , tweetem s vlastní fotkou , jak běhá poblíž jezera , a se slovy : „ tady jsem , jižní karolíno ! “
podle berkeley se trh s bydlením vrací „ do normálu “
jedna nejprominentnějších londýnských developerských společností varovala , že trh s bydlením se v jihovýchodní anglii „ vrátil “ k normální úrovni činnosti .
bydlení v hlavním městě bylo předmětem vysoké poptávky a vzrůstajících cen a rozšířené obavy z úvěrové bubliny přiměly v červnu bank of england k zavedení limitů na hypotéky .
tony pidgley , zakladatel a předseda developerské společnosti pro náročné klienty berkeley , v pondělí řekl : „ od začátku aktuálního rozpočtového roku se trh z vrcholného bodu v roce 2013 vrátil na normální úroveň transakcí . “ dodává , že to poskytuje „ stabilní prostředí pro fungování . “
londýnskému trhu s bydlením se během poklesu dařilo dobře , protože do hlavní město zaplavili kupci ze zahraničí .
podle dat katastrálního úřadu jen v minulém roce ceny ve městě vyskočily o 18,5 % , čímž dalece předehnaly průměr 6,7 % v anglii a v celém walesu .
průměrné prodejní ceny soukromého , cenově dostupného a studentského bydlení od berkeley se minulý rok zvedly asi o pětinu a na konci dubna se vyšplhaly na 423 000 liber .
nicméně kvůli posilující libře nejsou v posledních měsících pro zahraniční kupce londýnské nemovitosti tak atraktivní - některé z nich také zastrašilo zavedení nových daní z nemovitosti a řeči o možné „ sídelní dani “ , se kterými přišli politici před parlamentními volbami příštího května .
londýnská realitní kancelář foxtons minulý týden varovala , že dubnová revize trhu s hypotékami , která představila přísnější pravidla pro půjčky , zpomalí během druhé poloviny roku také tempo růstu trhu u prodeje nemovitostí i cen .
nová data bank of england v pondělí ukázala pokles v množství schválených hypoték za měsíc červenec , což naznačuje , že trh s bydlením se zklidňuje .
hamptons international , další realitní kancelář , snížila na základě toho , že ceny domů již začaly klesat , svou předpověď růstu cen londýnských nemovitosti na rok 2015 na 3 % .
objem transakcí se podle realitní kanceláře wa ellis mezitím v londýnských nejdražších čtvrtích jako chelsea , mayfair a kensington každý rok snížil o čtvrtinu .
přesto byla poptávka po bydlení v hlavním městě pro berkeley požehnáním , protože zvýšila hotovost za forwardový prodej na více než 2,2 miliard liber .
pidgley dodal : „ poptávka po tom správném , dobře vypadajícím bydlení v dobré lokalitě zůstala stejná a díky tomu se forwardový prodej udržel . “
v červnu firma ohlásila , že od začátku roku do konce dubna prodala 3 742 nemovitostí , téměř o třetinu víc než před vrcholem krize v roce 2007 .
roční zisk před zdaněním se zvýšil o 40 % na 380 milionů liber , výnosy o 18 % na 1,6 miliard liber .
v pondělí před výroční schůzí společnosti pidgley řekl , že se předvídá , že roční výnosy berkeley budou v souladu se současným tržním očekáváním .
analytici se shodují , že roční zisk před zdaněním bude 450 milionů liber .
akcie berkeley se odpoledne na londýnské burze zastavily na 23,96 librách .
hacker na internetu zveřejnil fotky nahé jennifer lawrencové
jennifer lawrencová přijíždí na 85. ročník cen akademie .
fotky držitelky oscara jennifer lawrencové unikly na internet kvůli hackerovi , který tvrdil , že má „ seznam “ fotek další stovky začínajících hereček .
mluvčí hvězdy filmů „ hunger games “ potvrdil , že fotky lawrencové jsou pravé a hackera kritizoval za „ zjevné porušení soukromí . “
úřady již byly kontaktovány a budou stíhat každého , kdo ukradené fotky jennifer lawrencové zveřejní .
hacker fotky , které byly původně zveřejněny na serveru pro sdílení obrázků 4chan , údajně získal díky mezeře v systému internetového úložiště applu icloud . údajný seznam fotek hacknutých obětí podle buzzfeed zahrnuje jména desítek hvězd včetně rihanny , kim kardashianové , mary elizabeth winsteadové a mary-kate olsenové .
není jasné , kolik fotek je autentických , nicméně hvězda filmu „ scott pilgrim proti zbytku světa “ winsteadová na twitteru také čin kritizovala .
„ doufám , že ti z vás , kteří si prohlíží fotky , které jsme si před lety s manželem pořídili v soukromí domova , jsou se sebou spokojení , “ napsala winsteadová na twitteru .
victoria justice známá ze seriálů kabelové televize nickolodeon „ icarly “ a „ victorious “ však popřela , že by fotky byly pravé . na twitteru sdělila : „ tyhle mé údajné nahé fotky jsou podvrh , lidi . “
lepší utnout to ještě v rozpuku . * záměrná slovní hříčka * .
buzzfeed v neděli večer oznámil , že mluvčí popové hvězdy ariany grande popřel , že by údajné fotografie byly pravé .
mimořádná ukázka z vychvalovaného nového románu howarda jacobsona o lásce a písmenu „ j “
rozpustili se , to je ten nejlepší způsob , jak to popsat , postupně se rozložili jako kartonová krabice , kterou někdo nechal na dešti .
jenom času od času mu nějaká žena řekla , že je příliš vážný , složitý , prudký , izolovaný a možná trochu popudlivý .
a pak mu potřásla rukou .
popuzeně si to připustil .
uměl píchat , jako ježek , ano .
poslední oběť této jeho schopnosti byla počínající milostná pletka , která více než obvykle slibovala , že mu uleví od osamělé životní nudy a možná mu i poskytne nějaké uspokojení .
ailinn solomonsová byla křehká kráska s divokou hřívou vlasů a přelétavým srdcem z vesnice na severním ostrově , která byla ještě odlehlejší a nehostinnější než port reuben .
na jih přišla se starší společnicí , o které se kevern domníval , že je její teta , která zdědila majetek ve vlhkém , ale nádherném údolí nazývaném , příhodně , rajské údolí .
v domě několik let nikdo nežil .
trubky prosakovaly , ve vanách byly mrtví pavouci , slimáci se oslizle podepsali na okna , jako kdyby si mysleli , že jim to místo patří , zahrada byla zarostlá a plevel připomínal obrovské hlávky zelí .
dům vypadal jako chaloupka z dětských příběhů , děsivá a zároveň okouzlující , se zahradou plnou tajemství .
profil autora : howard jacobson , jehož román „ j “ je na předběžném seznamu nominací na man booker prize 2014 .
užší výběr bude oznámen příští týden .
kevern s ailinn seděli na rozkládacích křeslech v dlouhé trávě a drželi se za ruce , užívali si nečekaně teplého jarního odpoledne , nepřítomně naladili veřejnou stanici , která kraj zásobovala útěšnou hudbou a uklidňujícími zprávami , když v tom mu pohled na její opálené překřížené nohy připomněl starou písničku dlouho zapomenutého černošského komika , kterého se zataženým roletami rád poslouchal jeho otec .
máš moc velké nohy .
kvůli jejich přirozené agresivitě už takové písničky v rádiích nehráli .
nebyly zakázané - skutečně zakázané nebylo nic - prostě se nehrály .
pomohli jim dostat se do desuetuda , stejně jako samotné slovo desuetudo .
lidový vkus dokázal to , co by nikdy nedokázaly předpisy a postavení mimo zákon , a stejně jako si lidi , co týče knih , vybírají memoáry , ve kterých se z chudáka stane boháč , kuchařky a milostné romány , tak v hudbě se vybírají balady .
kavern se nechal strhnout dnem a začal hrát na imaginární piáno a hrubým , komickým hlasem zpíval serenádu aillininým velkým chodidlům .
ailinn nechápala .
„ to byla oblíbená písnička od jazzového pianisty fatse wallera , “ řekl a automaticky si přiložil dva prsty ke rtům .
to vždycky dělal jeho otec , když chtěl potlačit písmeno j , než mu vyjde z úst .
začalo to jako hra , když byl ještě malý .
otec mu řekl , že hru hrál i se svým otcem .
když jste si u slova , co začínalo na j , nedali před pusu dva prsty , stálo vás to penci .
už tenkrát to nebylo moc vtipné a vtipné to nebylo ani teď .
jenom věděl , že se to od něj očekává , to bylo celé .
musel vysvětlovat , co je to jazz .
ailinn nikdy žádný neslyšela .
ani jazz , i když nebyl přímo postaven mimo zákon , nehráli .
improvizace vyšla z módy .
v životě bylo místo jenom pro jedno „ kdyby “ .
když začala hrát melodie , lidi chtěli vědět , kde přesně skončí .
to samé u humoru .
jeho nepředvidatelnost šla lidem na nervy .
a jazz byl humor vyjádřený písní .
přestože až do deseti let neslyšel o sammy davisu juniorovi , znal kevern jazz z otcovy polotajné sbírky starých cd .
aspoň ale nemusel aillin říct , že fats waller byl černoch .
vzhledem ke svému věku si nemohla pamatovat dobu , kdy oblíbení zpěváci nebyli černoši .
taky bez zákonů nebo nátlaku .
povolná společnost je taková , ve které každá její část s vděčností - s vděčností těch , jež byli šťastnou náhodou ušetření - souhlasí s principem skupinové vděčnosti .
lidé afro-karibského původu se temperamentem a konstitucí hodili pro bavení a atletiku , a tak zpívali a běhali .
lidé původem z indického subkontinentu , jakoby přírodou nadaní pro elektroniku , převzali odpovědnost za to , že žádná rodina nebude bez funkčního telefonu .
poláci , co zůstali , byli instalatéři , řekové , co zůstali , myli nádobí .
ti ze států perského zálivu a levanta , jejichž prarodiče rychle neopustili zemi , zatímco se dělo to , co se stalo , kdyby se to stalo - báli se , že by je obvinili , že přiložili do ohně , vlastně se báli , že ten oheň příště stráví je - otevřeli si restaurace , kde se prodával labneh a kouřily vodní dýmky , neupozorňovali na sebe a nečinnost je pomalu stravovala .
každému podle jeho talentu .
vzhledem k tomu , že poslouchala jenom balady , ailinn těžko chápala , jak by ze sprostých slov , která jí kavern právě zazpíval , mohla vzniknout muzika .
hudba byla vyjádřením lásky .
„ ve skutečnosti nejsou sprostá , “ řekl kevern .
možná jenom pro lidi , co mají moc velké nohy .
můj otec nikdy nikoho neurazil , ale tuhle písničku měl rád .
mluvil příliš , ale zanedbaná zahrada dodávala iluzi bezpečí .
zpoza zvukotěsných listů nemohlo uniknout ani slovo .
ailinn pořád nechápala .
proč by se tvému otci něco takového líbilo ?
chtěl říct , že to byl vtip , ale zdráhal se dát si v její přítomnosti zase dva prsty k ústům .
už si myslela , že je divný .
„ zdála se mu vtipná , “ řekl nakonec .
nevěřícně potřásla hlavou a zastínila kevernovi výhled .
na celém širém světě nebylo vidět nic jiného než změť jejích havraních vlasů .
nic jiného vidět nechtěl .
„ když myslíš , “ řekla pochybovačně .
to ale pořád nevysvětluje , proč mi ji zpíváš .
vypadala skutečně rozčilená .
mám moc velké nohy ?
podíval se znova .
chodidla tak úplně ne .
možná trochu kotníky ...
tvrdíš , že mě nesnášíš , protože mám moc tlusté kotníky ?
nesnáším ?
to není pravda .
je to jenom hloupá písnička .
mohl jí říct „ miluju tě “ , ale na to bylo moc brzo .
„ tvoje tlustý kotníky mě právě přitahují , “ zkusil to .
jsem tak trochu úchylný .
to se nepovedlo .
chtěl být vtipný .
když chtěl být vtipný , často ho to dostalo do potíží , protože , stejně jako jeho otec , postrádal kouzlo nutné k tomu , aby dokázal zkrotit krutost , která ve vtipech číhala .
možná byl jeho otec krutý úmyslně .
možná byl úmyslně krutý kavern .
navzdory laskavým očím .
ailinn solomonsová zrudla a zvedla se z lehátka , shodila rádio a rozlila nedopité víno .
bezinkové víno , takže pití za to nemohlo .
vypadala , že se ve svém rozrušení třese jako palmové listy v bouři .
„ mě zvráceně přitahuje , že jsi blbec , “ řekla ...
až na to , že mě to nepřitahuje .
bylo mu jí líto , jak kvůli svým nelaskavým slovům , tak kvůli strachu , který měla v očích ve chvíli , kdy se proti němu postavila .
myslela si , že ji uhodí ?
nemluvila s ním o životě na chladném severním poloostrově , kde vyrůstala , ale nepochyboval , že v základech to tam bylo stejné jako tady .
tříštil se o ně stejný širý a ledový oceán .
stejní pomatení muži , potom , co se stalo , dokonce ještě nedůtklivější a mrzutější než jejich předci , pašeráci a kazisvěti , naštvaně bloumali od hospody k hospodě , připravení vztáhnout ruku na kteroukoliv ženu , která by se opovážila je odmítnout nebo se jim vysmát .
blbec ?
jestli si nebude dávat pozor , předvedou jí svoje pěsti !
nejdřív ji pomazlit - pomazlit se stalo nejběžnějším výrazem pro erotické dráždění mezi mužem a ženou : protilátka mdlých balad o lásce , které rádio chrlilo - nejdřív ji pomazli , pak jí jednu vraž .
podle kevernova názoru přílišná kultivovanost , protože mazlení bylo samo o sobě aktem násilí .
ailinn solomonsová mu neverbálně naznačila , aby odešel .
zvedl se z lehátka jako stařec .
sama se cítila rozmrzelá , ale tíha jeho smutku ji překvapila .
nebyl to přece konec světa .
skoro se neznali .
dívala se , jak odchází - jako kdyby ho pozorovala z okna v patře - muže , kterého dohnalo , co sám způsobil .
adam opouštějící zahradu , pomyslela si .
srdce se jí sevřelo kvůli němu i kvůli všem mužům obecně bez ohledu na to , že pár jich ji zbilo .
muž se od ní odvrátil , ramena svěšená , zahanbený , poražený , veškerá bojovnost ho opustila - proč jí připadalo , že tenhle pohled dobře zná , i když si nedokázala vybavit jediný moment , až dnes , že by to už někdy viděla ?
ailinn solomonsová , zase sama , se podívala na své nohy .
asi dvacet let po těchto událostech esme nussbaumová , inteligentní a nadšená dvaatřicetiletá výzkumnice pracující v ofnow , nestatutárním monitorovacím systému veřejné nálady , připravila krátký článek o přetrvávání lehkých a středně těžkých násilných činů v oblastech země , kde se jeho zmírnění nebo přímo zastavení , nejvíce očekávalo , kdyby na jeho odstranění bylo vynaloženo dostatek peněz a energie .
„ udělalo se toho hodně a hodně se toho ještě udělat musí , “ napsala , „ aby se uklidnila vrozená agresivita lidí , kteří bojovali v mnoha bitvách a většinu z nich vyhráli , a to především v zasutých , těžko dostupných místech země , kde se i přes špičky kostelních věží vystupujících nad živými ploty nádech lidské laskavosti historicky objevoval jen zřídka . “
některé věci jsou však nenahraditelné .
mohlo by se zdát , že čím vyšší je kostelní věž , tím nižší jsou pudy .
obyvatelé vzdychají nad sentimentálními baladami , hltají nešťastné příběhy a prohlašují , že pevně věří v hodnotu manželství a rodinný život , ale nejen , že v rurálních oblastech se stará brutalita drží stejně tvrdošíjně jako v městských aglomeracích , ale důkazy také ukazují , že doma , na pracovišti , silnicích a dokonce na sportovních hřištích se objevuje nová a útočná nesnášenlivost .
„ bohužel máte tendenci k příliš květnatému stylu , “ řekl její nadřízený .
navrhoval bych vám , abyste četla méně románů .
esme nussbaumová sklonila hlavu .
také se musím zeptat : jste ateistka ?
„ mám dojem , že na to nemusím odpovídat , “ prohlásila esme nussbaumová .
jste lesba ?
esme se znova ohradila svým právem na soukromí a mlčení .
feministka ?
další ticho .
„ neptám se proto , “ řekl nakonec rabinowitz , „ že bych měl něco proti ateistům , lesbám nebo feministkám .
na tomhle pracovišti předsudky nemáme .
sloužíme nepředpojaté společnosti .
ale jistý druh přecitlivělosti , který je sám o sobě naprosto přijatelný a chvályhodný , může někdy zkreslovat úsudek tak , jak jste to předvedla vy .
očividně vy sama jste předpojatá vůči církvi - věci , které nazýváte „ kruté “ a „ brutální “ by jiní mohli interpretovat také jako vyjádření přirozené síly a energie .
pořád řešit co se stalo , kdyby se to stalo , jako kdyby se to stalo , kdyby se to stalo , včera , připravuje zemi s její základní životní sílu .
zatímco rabinowitz mluvil , esme nussbaumová se rozhlížela kolem .
za hlavou mu na světelné tabuli růžově blikalo doporučení , které ofnow vysílalo do světa poslední čtvrtstoletí nebo víc .
usmívejte se na souseda , pečujte o svého partnera , poslouchejte balady , choďte na muzikály , používejte svůj telefon , konverzujte , vysvětlujte , dohodněte se , omluvte se .
mluvit je lepší než mlčet , zpívané slovo je lepší než psané , ale není nic lepšího než láska .
„ naprosto chápu vaše výhrady , “ odpověděla tiše esme nussbaumová , když si byla jistá , že její nadřízený skončil , „ a už netvrdím , že se rána nezhojila tak , jak si namlouváme , že se zhojila .
mojí obavou především je , že pokud na to nebudeme s předstihem upozorněni , zopakujeme stejnou chybu , která vedla k tomu , co se stalo , kdyby se to stalo .
tentokrát si ale vztek a nedůvěru nebudeme ventilovat na ostatních .
luther rabinowitz spojil konečky prstů .
to mělo značit nekonečnou trpělivost .
„ zacházíte příliš daleko , “ řekl , „ když kroky , které možná udělali a možná neudělali vaši prarodiče , popisujete jako chyby .
příliš daleko zacházíte i v tom , že mluvíte o tom , že si ventilovali svůj „ vztek “ a „ nedůvěru “ na „ ostatních . “
neměl bych někomu na vašem místě připomínat , že v chápání minulosti a v ochraně přítomnosti nemluvíme o „ nás “ a o „ nich . “
nebylo žádné „ my “ a nebyli žádní „ oni . “
víme jenom to , že se jednalo o chaotické časy .
„ během kterých , pokud k sobě budeme upřímní , “ sebrala esme odvahu , „ nikdo nejsme bez viny .
nikoho neobviňuju .
ať už to bylo spravedlivé nebo ne , co se stalo , stalo se .
to bylo předtím .
k tomu není , co dodat - v tomhle spolu souhlasíme .
a stejně jako neexistuje žádná vina , která by se dala na někoho svést , neexistují ani věci , které by se měly napravit , ani kdyby náprava byla vhodná a možná .
ale k čemu jinému je minulost , než k tomu , abychom se z ní poučili -
minulost existuje , abychom na ni zapomněli .
jestli k tomu můžu něco dodat -
luther rabinowitz rozpojil konečky prstů .
„ vaši zprávu vezmu v úvahu , “ řekl a propustil ji .
den na to , když šla jako obvykle do práce , ji srazil motocyklista , který najel na chodník způsobem , který kolemjdoucí popsali jako „ brutální a zuřivý . “
náhody se dějí .
armáda lesothského království tvrdí , že žádný puč neplánuje - předseda vlády zůstává v jižní africe
vojenští důstojníci lesothského království popřeli , že by organizovali puč za účelem svržení vlády , a tvrdí , že jednali proti policii podezřelé z pokusu o vyzbrojení politických fanatiků .
předseda vlády thomas thabane utekl ze země a říká , že armáda obklíčila jeho oficiální sídlo a obsadila vládní budovy v hlavním městě maseru .
poté , co prohlásil , že mu vyhrožují smrtí , odjel premiér se svou rodinou do sousední jihoafrické republiky .
mluvčí armády major ntlele ntoi k tomu řekl , že ve skutečnosti se nejednalo o puč , ale odpověď armády na výhrůžku „ politických fanatiků “ , které se policie pokoušela vyzbrojit .
„ dnes ráno velení obranných složek království lesotha jednalo poté , co obdrželo několik zpráv informační služby , že v řadách policie se vyskytuje několik skupin , které plánují vyzbrojit některé radikální , politické fanatiky , kteří se chystali nadělat v zemi spoušť , “ řekl hlasu ameriky .
mluvčí jihoafrické vlády clayson monyela řekl , že vojenské akce vypadaly jako pokus o svržení vlády .
„ přestože nikdo neprohlásil , že se chopil vládní moci pomocí síly , podle všeho nesou akce lesothských obranných složek známky státního převratu , “ uvedl .
vojenští představitelé lesothského království řekli , že vojáci se v neděli vrátili do svých kasárna a v hlavním městě byl klid .
během thabanovy nepřítomnosti bude za vládu zodpovědný vicepremiér mothetjoa metsing .
thabane prohlásil , že podle jeho názoru je terčem útoku kvůli svým snahám bojovat proti korupci v zemi .
od června , kdy thabane pozastavil zasedání parlamentu kvůli vnitřním sporům , panuje v lesothu napětí .
prohlásil , že i přes opačná tvrzení , nepodkopává jeho jednání vládu .
výroba v eurozóně je na třináctiměsíčním minimu
růst výroby se podle bedlivě sledovaného průzkumu v srpnu v eurozóně zpomalil na třináctiměsíční minimum .
závěrečný index nákupních manažerů v eurozóně ( pmi ) z červnových 51,8 klesl v srpnu na 50,7 .
číslo vyšší než 50 značí expanzi .
ubylo nových objednávek a továrny poškodilo rostoucí napětí mezi eu a ruskem kvůli ukrajině .
čísla pocházejí ze čtvrtečního setkání evropské centrální banky ( ecb ) .
trhy budou chtít od banky jasný plán , jak se vypořádat s oddalovaným ozdravením eurozóny i s hrozbou deflace s inflací stagnující na 0,3 % .
objevily se spekulace , že ředitel ecb mario draghi možná tento týden naznačil , že zvažuje kvantitativní uvolňování eurozóny , podobné tomu , k jakému během finanční krize přistoupily spojené království a usa .
„ přestože alespoň nějaký růst je lepší než žádný růst , brzdný efekt , který má rostoucí ekonomika a geopolitická nejistota na výrobce , je stále viditelnější , “ řekl rob dobson , hlavní ekonom markit .
výrobní pmi německa , největšího obchodního partnera ruska v eu , spadl na jedenáctiměsíční minimum 51,4 .
v druhé největší ekonomice zóny , francii , spadl pmi na 46,9 .
znepokojení panuje ohledně francie , itálie zase přešla z expanze to stagnace .
známky toho , že hnací síla růstu v nejdůležitějších průmyslových oblastech v německu , španělsku a také nizozemí zmizela , také není příliš uklidňující , “ řekl dobson .
zpomalení průmyslu pravděpodobně přilije olej do ohně analytikům očekávajícím implementaci dalších měnových nebo daňových stimulů .
jedna pozitivní zpráva přišla z irské republiky , kde pmi vzrostl na 57,3 , nejvyšší úroveň od konce roku 1999 .
howard archer , hlavní ekonom v ihs global insight , řekl : „ to nejlepší , co se dá o výrobním přehledu nákupních manažerů za srpen říct , je , že ukazuje , že sektor stále roste . “
dodal : výrobci v eurozóně mají v současné době život velmi složitý , protože zvyšující se geopolitické napětí - především mezi ruskem a ukrajinou - přidává ke stále náročným podmínkám v mnoha zemích ještě více nejistoty .
tato zvyšující se nejistota obchod prokazatelně zasáhla - a to především důvěru spotřebitelů , což pravděpodobně způsobí , že některé objednávky budou odloženy nebo dokonce zrušeny , hlavně ty nákladné .
uvedl , že jako „ ještě více pravděpodobné “ se jeví , že ecb nakonec bude muset provést nějakou formu kvantitativního uvolňování , „ ačkoliv očekáváme , že bude jen omezená . “
deset let pekla přeživších z beslanu : deset let od hrůz z obsazené školy děti stále trpí
před deseti lety bylo čečenskými radikály ve škole v beslanu v jižním rusku jako rukojmí zadrženo tisíc lidí
během utrpení , které trvalo tři dny a které šokovalo svět , bylo zabito více než 330 lidí , z nichž více než polovina byly děti
vrátili jsme se do beslanu , abychom vyhledali některé z obětí , které během zvěrstva ve škole unikly smrti
přesně deset let po děsivém obsazení školy v beslanu , při kterém zahynulo 334 lidí včetně 186 dětí , varovali včera večer přeživší hrdinové před novou apokalypsou na ukrajině .
když 1. září 2004 , na začátku nového školního roku , zajali a zavraždili fanatičtí teroristé děti a rodiče , vypadalo to jako nejhlubší dno pekla .
odpor nad tragédií spojil východ a západ , což v tomto katastrofálním neštěstí vedlo k jednání a budoucnosti .
po deseti letech jsme se do beslanu v jižním rusku vrátili , abychom vyhledali některé z obětí , které během zvěrstva ve škole unikly smrti .
našli jsme úžasné mladé lidi , kteří vzdorovali neštěstí , i když vzpomínka na peklo způsobené teroristy v nich bude žít dál .
jaké je jejich největší přání ?
aby válka , která nyní ničí ukrajinu - a ve které děti jako byli oni umírají - už skončila .
dívka pokoušející se vlézt zpátky do zničené školní tělocvičny
byla zachycena předním ruským fotografem dimitrijem beliakovem , jak se pouze ve spodním prádle snaží vlézt zpátky do rozbombardované školní tělocvičny poté , co v ní explodovala bomba .
zmatená aida zoufale hledala svou matku larissu , které je nyní čtyřicet .
panovaly obavy , že obě jsou mrtvé , ale ve skutečnosti přežily .
„ nějaká žena mi řekla , ať utíkám a zachráním si život , ale nemohla jsem , “ řekla tenkrát aida .
nohy jsem měla od krve .
vstala jsem a vlezla zpátky , abych našla maminku .
zachránil ji voják .
po několika operacích si myslela , že se už plně uzdravila , ale včera řekla : „ před třemi měsíci se bolesti vrátily .
bojím se , že budu muset na další operaci .
v koleni mi zůstaly kousky střepin .
jejím cílem je stát se zubařkou , aby mohla pomáhat lidem tak , jako lékaři pomohli jí .
„ tahle tragédie mi změnila život , ale rozhodně ho nezničila , “ řekla odhodlaně .
„ prostě se mi to stalo a to se nedá změnit .
jednou ročně chodím do tělocvičny , abych si připomněla ty , kteří tam zůstali .
jinak se o tom snažíme s přáteli nemluvit .
ta bolest je moc velká .
moji nejlepší kamarádku a budoucí spolužačku ze třídy džeru gapoevu tam zabili .
jako malé jsme si spolu hrály a představovaly jsme si , jak spolu budeme chodit do školy .
„ nechci se vdát , dokud nedokončím školu a nezačnu kariéru .
o rodině budu přemýšlet později .
říká , že na zajetí nezapomněla , ale vzpomínky každým rokem trochu blednou .
jsem ráda , že tolik lidí na celém světě si pořád pamatuje , co se stalo , a jsme moc vděční za pomoc , kterou jsme dostali z británie a z dalších zemí .
když se na internetu dívám na svoji fotku , jak lezu školním oknem , říkám si , že spousta lidí ji uvidí poprvé , pochopí tu katastrofu a zabrání tomu , aby se opakovala .
chlapec , který unikl deštěm kulek a věřil , že jeho matka je mrtvá
byl to jeho první školní den ( v rusku děti školu začínají v sedmi letech ) a přežil třídenní obléhání školy v objetí své matky tamary .
v té době sedmiletý řekl : „ mamka mi řekla , že kdyby nastala exploze , mám si lehnout na zem a držet ji za ruku . “
po explozi si myslel , že matka umírá .
řekla mu : „ utíkej . “
bál se , že je mrtvá , utíkal a cestou uviděl plačící batole , popadl dítě za ruku a utíkali sprškou kulek .
jeho otec vladimir , který ho venku chytil , řekl : „ damir mi řekl , že jeho matka je mrtvá . “
povídá : „ nemohl jsem ji zachránit . “
ve skutečnosti se tamara dopotácela na svobodu a ležela v nemocnici se zraněnou nohou a naopak si myslela , že její syn zemřel .
poté , co se znova setkali , řekla : „ plakala jsem štěstím .
nemohla jsem tomu uvěřit .
přiběhl dovnitř a objal mě .
damir poté odletěl do londýna ( podle zaniklých novin news of the world ) , kde byl tehdejším premiérem tony blairem a jeho ženou cherie prohlášen vítězem bernardo &apos; s children .
„ ta hrůza se každý den vrací , ale přál bych si , abych na to mohl přestat myslet , “ řekl včera .
můžu ale říct , že vzpomínky už blednou .
pamatuju si , že hned potom jsem zahodil všechny svoje pistole na hraní .
dneska ale můžu hrát počítačové hry , ve kterých se střílí , a nemám s tím problém .
„ nebojím se jít zpátky do tělocvičny , ale nemyslím na sebe .
vzpomínám na děti , se kterými jsem si hrál na dvoře a které se ven nedostaly .
nikdy neřekneme , že je zabili nebo že zemřely .
říkáme , že zůstaly v tělocvičně .
na výlet do londýna si pamatuju dobře , hlavně na to , jak jsem si v hračkářství mohl vybrat cokoliv jsem chtěl , a jak jsem jel kabrioletem .
teď se ale obává o místa jako je ukrajina , kde kvůli válce trpí stejně jako trpěl on a jeho přátelé .
ta hrůza se každý den vrací , ale přál bych si , abych na to mohl přestat myslet
„ je mi hrozně líto každého , kdo si takovou hrůzou musí projít , “ říká damir , který se minulý týden zúčastnil dobrovolnické činnosti v klášteře .
chci hrozně moc pomáhat .
jednou chci pracovat u policie a doufám , že mě příští rok přijmou na akademii .
jeho matka tamara , 48 , říká : „ zabili 37 dětí z našeho sousedství , dokážete si to představit ?
pamatuju si na to ticho hned po útoku . nikde nebyly žádné děti , které by tady křičely a běhaly , a to ticho trvalo několik měsíců .
živě si pamatuje na cestu s damirem do londýna .
když jsem náš příběh v londýně vyprávěla , lidé plakali .
pak jsem si uvědomila , jak lidi na druhé straně světa dokáží pochopit naše pocity a jak umí vyjádřit svou podporu .
byla vděčná cherie blairové a její nadaci za udělenou cenu a za možnost jet na podzim 2004 do londýna .
přeju si , abych mohla cherie zavolat a osobně říct , že i když je to už deset let , pořád si pamatuju na setkání s ní a jejím manželem v londýně a jak mně a damirovi pomohli .
vzpomínám si , jak měl damir chuť na boršč , a tak obvolali všechny ruské restaurace .
taky si pamatuju , jak si v restauraci hrál s číšníky , damir na ně střílel z vodní pistole a oni utíkali a hráli si s ním .
a to bylo jen měsíc od té hrůzy .
byla jsem překvapená , jak se s námi britové chtěli podělit o naši bolest a jak nás podporovali .
řekla : „ pořád si myslím , že svět se za těch deset let nezměnil k lepšímu .
teď je válka na ukrajině , každý den umírají lidé a myslím , že bylo a ještě bude zabito i hodně dětí .
jsou to stejné děti jako ty naše .
myslím , že pro hodně lidí je válka jenom něco ve zprávách , které si poslechnou , když se nudí nebo zatímco dělají něco jiného .
já vím , co ti lidé prožívají , co je to za hrůzu .
pořád to cítím .
nic se nezměnilo , lidé se pořád chtějí navzájem vraždit , je to tak smutné .
damir vyrostl a je z něj milý a tichý kluk , není vůbec agresivní nebo vzteklý .
například netouží po pomstě , tohle ho vůbec nezajímá .
vím , že na to nerad vzpomíná , ale má hodně blízko k šesti spolužákům a čas od času chodí do tělocvičny a zapalují tam svíčky .
když byl menší , měl s tím problémy - vzpomínám si , jak si někdy lehl na gauč s obličejem odvráceným od nás a někdy tak ležel hodiny .
nespal , měl otevřené oči .
taky si pamatuju , že vyhodil všechny svoje pistole nebo jiné zbraně na hraní . damirovi je dneska 17 , je vyšší než já , hezký , chytrý a zdravý .
stěží můžu uvěřit , že jsem si několik hodin byla jistá , že je mrtvý a že už ho nikdy neuvidím .
když jsem se po explozi vzpamatovala a zvedla se na nohy , podívala jsem se kolem a uviděla to peklo , všude ležely kusy lidských těl .
byla jsem si naprosto jistá , že můj chlapeček neměl tohle peklo šanci přežít .
„ pamatuju si , jak jsem křičela ‚ damire , utíkej , utíkej ! ‘ , ale byla jsem přesvědčená , že mě neslyšel .
ale slyšel ji a utekl .
takže náš život jde na rozdíl od jiných dál .
grigorij ilyin , 17
chlapec , jehož pořízená fotka po útoku se stala symbolem hrůz v beslanu
útěcha : přeživší z beslanu grigorij ilyin se svou matkou fatimou po útoku v roce 2004 , napravo grigorij dnes
když utíkal o život poté , co čečenský terorista zastřelil jeho spolužáky , byl do jeho zakrváceného obličeje vrytý strach .
jeho fotka byla jedním z nejvíce šokujících symbolů zvěrstva v beslanu .
jeho matka fatima , 54 , lékařka , ho jeho první den vysadila u školy a spěchala odvézt svého staršího syna vladimira na univerzitu .
„ odjela jsem dvě minuty předtím , než teroristé vtrhly na dvůr , takže můj chlapeček tam tři dny zůstal sám , “ vzpomínala .
ne úplně sám , protože jsme tam měli příbuzné , ale všichni tam zemřeli .
přežil jenom můj grigorij .
jak se to datum blíží , je pořád těžší o tom přemýšlet a mluvit .
neuplyne ani jediný den , abychom na tu tragédii nevzpomínali .
nepřipadá nám , že se to stalo už dávno , mám pocit , že to bylo včera , některé okamžiky se mi pořád vrací .
slibuju , že nikdo nikdy nezapomene .
stále se vracející vzpomínky : fotka grigorije ( vlevo ) byla jedním z nejvíce šokujících obrázků útoku a byla zvěčněna jako socha ( vpravo )
vzpomínám si , jak se ten den grigorij hrozně těšil do školy , říkal , že chce obejmout svoji učitelku .
že je živý , jsem se dozvěděla , když jsem ho viděla v televizi .
v san marinu je dokonce socha plačícího grigorije .
grigorij se na tu fotku dívá nerad a doma ji máme schovanou v knihovničce .
chápu to , ale taky si myslím , že díky tomu obrázku lidé na celém světě vědí , jakou bolest cítíme .
dnes grigorij říká : „ důležité je , aby se tohle už neopakovalo .
„ pochybuju , že se někdy dozvíme pravdu .
podobné tragédie se pořád vyšetřují , ale pravdu nikdo nikdy nezjistí .
teď vyšetřují tu havárii boeingu na ukrajině .
dozvíme se někdy , co byla příčina ?
tenhle svět čeká něco moc špatného .
„ nechápu , proč se to děje , protože když se lidí zeptáte , tak válku nikdo nechce , tak jak je to možné ?
deset let není pro takovou bolest nic .
abychom aspoň trochu zapomněli , potřebuje desítky let .
mělo to vliv na moje zdraví , pořád to cítím .
tři nebo čtyři roky jsem měl kvůli útoku noční můry , ale pak se to zlepšilo .
když jsem se pak v roce 2004 vrátil do školy , každý den jsem byl vyděšený .
myslel jsem na svoje přátele a spolužáky , které zabili .
proto , když se blíží 1. září , chodím do tělocvičny .
chci uctít památku přátel z dětství .
je pro mě těžké do té tělocvičny vstoupit , ale musím .
necítím se jako oběť , tenhle příběh je minulostí .
nezapomenu na to , ale nelituju se .
můj život jde dál .
letos jsem dokončil školu a začal studovat medicínu na univerzitě ve vladikavkazu .
chci být kardiochirurg .
nejdřív jsem chtěl vstoupit do armády .
chtěl jsem být voják , ale kvůli zdraví jsem nemohl .
chtěl jsem bojovat za svou zemi , ale nepůjde to .
grogorij farniyev , 20
chlapec , který přežil , přestože ho drželi u nohou vraždícího teroristy
zázrak : gregorij farniyev byl během útoku držen u nohou vraždícího teroristy , přesto však dokázal přežít
když byl útok v plném proudu , byl zachycen uvězněný v tělocvičně , jak sedí vedle bomby u nohou vraždícího teroristy .
je to opravdový zázrak , že přežil .
„ připadá nám to , jako kdyby to bylo včera , “ řekl gregorij , který se chtěl stát agentem federální služby bezpečnosti , ale kvůli zraněním , která utrpěl během útoku , nemohl .
pořád je to se mnou , není to něco , co jsem hodil za hlavu .
teď už jsem starší a říká se , že děti se se špatnými zážitky dokáží vypořádat líp - musím říct , že to není pravda .
„ v roce 2006 jsem chodil k psychologovi a bylo mi pak trochu líp , ale nemůžu zapomenout .
a zapomněl bych rád .
v roce 2005 - rok nato - to bylo poprvé a naposledy , co jsem do tělocvičny znova vstoupil .
omdlel jsem .
už tam nikdy znova nepůjdu a nechtějte po mně prosím , abych vám ukázal , kde na tom dobře známém obrázku sedím .
přeživší : gregorij farniev dnes , na notebooku se svou fotografií pořízenou v nemocnici po útoku
ta bolest je obrovská a nesu si ji s sebou každý den .
přátelé vědí , že o tom nerad přemýšlím nebo mluvím a nikdy se mě na školu neptají .
co se týče fyzického zdraví , jsem v pořádku .
musím být opatrný na svoje koleno , které jsem si poranil , ale už chodím normálně .
ale i tak jsem kvůli zdraví nemohl nastoupit a studovat na akademii fbs v petrohradu , jak jsem chtěl .
poslal jsem jim svoje dokumenty včetně lékařských zpráv a odpověděli mi , že to není možné .
mojí další zálibou jsou zvířata , tak jsem nastoupil na veterinu .
dodělal jsem tam druhý rok .
učí se , jak léčit všechna zvířata od „ koček po krávy “ .
řekl : „ vím , že svým dětem o tom nikdy vykládat nebudu .
není to něco , o čem by děti měly vědět a už vůbec ne něco , co by měly zažít .
jeho matka marina , 42 , uvedla : „ ta bolest tady bude pořád .
je uvnitř a zhoršuje se s blížícím se výročím .
zúčastním se připomínkových ceremonií .
vím , že grigorij nepůjde .
musí to být pro něj ještě silnější , protože tam na rozdíl ode mě byl .
já jsem na něj čekala doma a nemohla jsem mu pomoct .
jsem bohu tak vděčná , že mi ho vrátil . tady v beslanu jsou stopy všude .
zůstává to s námi .
gregorij je dneska dospělý , ale tu hrůzu si nese dál .
je těžké přijmout , když se vám stane něco tak strašně nespravedlivého .
je to kluk , má rád sport , ale nemůže ho dělat kvůli svému koleni .
podstoupil několik operací , může chodit , ale nemůže cvičit .
řekla bych , že tak z 50 % už ten děs překonal , ale překonat to úplně a zapomenout nejde .
tahle strašná zkušenost s námi bude pořád .
během útoku zabili hodně našich přátel a sousedů a to bolest jenom zhoršuje .
ztratila jsem hodně lidí , které jsem měla ráda a kteří mi byli blízcí .
můj syn je se mnou a to je ten největší dar , jaký mi bůh mohl dát , ale bolí mě ztráta zabitých .
znám rodiny , ve kterých se narodily další děti , ale také vdovy , které už se znova nevdaly .
je těžké přijmout , že život jde dál , i když nechcete .
nikdy nezapomenu , jak mi srdce málem vyskočilo z hrudníku , když jsem ho uviděla v nemocnici .
teď pozoruju , co se na světě děje - války na jiných místech .
za co ti lidé bojují ?
proč se navzájem zabíjejí ?
válka se teď blíží k naší zemi , čemuž můžu stěží uvěřit .
v minulosti jsme byli jedna spřátelená země , tak jak jsme se dostali k tomu , že spolu teď bojujeme ?
lidé a děti trpí , jsem si jistá , že mnoho dětí na ukrajině bylo a ještě bude zabito .
kdybychom tak mohli všechny ty rebely sebrat a zahodit je - jak nejdál to půjde .
alyona tskaeva , 10
dítě , které odneslo do bezpečí speciální komando
zachráněna : alyonu tskaevu nese do bezpeční ruské speciální komando ( vlevo ) .
nyní je jí deset ( vpravo ) a na tragédii si vůbec nevzpomíná
svět v roce 2004 zalapal po dechu , když malou alyonu vynesl v náručí z beslanského zajetí ruský policista .
teroristé ji propustili , v zajetí ve školní tělocvičně si však ponechali její třicetiletou matku , desetiletou sestru kristinu a bratra makhara .
makhar , kterému v tu dobu byly tři roky , unikl , alyonina matka a sestra však při masakru zemřeli .
její bratr ruslan se znovu oženil a se svou novou ženou světlanou mají holčičku , kterou po mrtvé dceři pojmenovali kristina .
sousedé říkají , že alyona , které je nyní deset , si na útok vůbec nevzpomíná a vyrostla z ní bystrá a šťastná holčička .
blízký přítel prohlásil , že „ je to velká šťastná rodina a alyona a makhar jsou skvělé děti . “
ruslan je výborný otec a chce děti udržet daleko od vzpomínek , které desáté výročí připomíná .
dokážete pochopit proč .
muž obviněn ze sražení dívky na přechodu na znamení v obci fife
osmasedmdesátiletý muž před soudem za to , že na přechodu na znamení v obci fife srazil tříletou dívku .
gordon stewart údajně dívku srazil na přechodu v pittenween v east neuk .
žalobci tvrdí , že stewart neřídil své audi q3 s dostatečným ohledem a pozorností a dívku zranil .
stewart ( 78 ) z anstrutheru obvinění u soudu v dundee popřel .
soudce charles macnair stanovil datum stání na leden .
4 tipy , jak pod vodou pořídit lepší fotky a videa
pokud se zajímáte o focení nebo natáčení pod vodou , máte k dispozici velký výběr vybavení .
nejlevnější možností je kompakt jako například nikon coolpix aw120 nebo outdoorová kamera typu gopro hero3 + silver edition , které stojí okolo 300 dolarů .
tyhle fotky jsem pořídil na rodinné oslavě několika foťáky , všechny stály méně než 350 dolarů .
je jedno , jaké vybavení používáte , ale pro dosažení nejlepších výsledků platí několik pravidel .
překontrolujte si vybavení .
i když máte vodotěsný fotoaparát , ujistěte se , že baterie a další části jsou pevně uzavřené .
dále nastavte fotoaparát podle toho , jaký typ fotek nebo videí budete pořizovat .
některé fotoaparáty a videokamery mají scénický nebo natáčecí režim , který expozici optimalizuje na tmavé prostředí pod vodou .
a než se do toho pustíte , zjistěte si , jak hluboko se můžete se svým vybavením ponořit .
některé fotoaparáty jsou určeny jen do 5 stop , další do 50 až 60 .
přečtěte si našeho průvodce nákupem a hodnocení digitálních kamer v běžném i vodotěsném provedení .
dělejte vždy několik snímků - hodně z nich nevyjde .
kompaktní fotoaparáty mají lcd , které vám pomůže s kompozicí fotek , ale outdoorové ho nemají .
i když lcd máte , pod vodou bude špatně vidět a kompozice záběru bude nepředvidatelná .
takže vždy dělejte více snímků .
pokud má fotoaparát bracketingový režim , který dělá série snímků s mírně odlišným rozptylem expozice , využijte toho .
držte se blízko u hladiny .
s hlubším ponorem světla výrazně ubývá .
pokud je to možné , držte se při focení v bazénu , jezeře nebo moři blízko hladiny .
to vám také umožní zachytit na fotkách víc světla - čím hlouběji se potopíte , tím méně barev uvidíte .
dostaňte se blízko k fotografovanému objektu .
to je výborná rada , pokud fotíte na souši , ale pod vodou je ještě důležitější kvůli tlumenějšímu světlu .
je to obzvlášť důležité , pokud natáčíte s outdoorovou kamerou : taková zařízení mají obvykle pevný a široký úhel čočky , což znamená , že pokud chcete zaplnit fotorámeček , musíte se k objektům víc přiblížit .
andrew lawson byl člověk , jehož síla osobnosti dokázala měnit věci dokonce i v tak obrovské organizaci jako nhs .
jako anesteziolog svou kariéru zasvětil tomu , aby nemocným ulevoval od bolesti způsobené nemocí i léčbou .
jeho žena vzpomíná , že jeden z lidí , kteří vyhledali jeho pomoc , byl důstojník mi6 , který musel žít s následky mučení , které ho zmrzačilo .
lawson pochopil , že zatímco lékaři se soustředí na diagnózy a nemoci , léčené pacienty v drtivé většině zajímá úplně něco jiného : bolest .
jednoho dne v roce 2007 to však byl on , kdo začal trpět .
„ necítím se ve své kůži , “ napsal v květnu toho roku .
cítil jsem se bez energie .
potýkal se s příznaky chřipky a zjistil , že je netrpělivý a svou ženu juliet zahrnuje výčitkami .
poznamenal si : „ chci , aby se všechno dělo spíš dřív než později . “
když juliet na týden odjela na služební cestu , lawson byl nezvykle a nevysvětlitelně rozrušený .
něco nebylo v pořádku .
kolega mu udělal rentgen hrudníku .
jednom dva týdny předtím lyžoval ve francouzských alpách .
přišly výsledky rentgenu .
měl mezoteliom , nevyléčitelný nádor , který postihuje pohrudnici nebo-li výstelku plic .
u většiny druhů rakoviny je těžké určit , co bylo jejich příčinou .
přestože někteří kuřáci dostanou rakovinu plic , ne všichni pacienti s rakovinou plic kouřili .
mezoteliom je ale jiný .
téměř ve všech případech je příčinou vystavení azbestu - stavebnímu vláknitému materiálu , který byl dříve označován za „ zázračný “ , ale dnes se ví , že je smrtelně nebezpečný .
pro většinu z nás nebylo těžké mezoteliom ignorovat .
azbest , koneckonců , patří minulosti .
nejnebezpečnější typ azbestu se v británii nepoužívá od 60. let , kdy vstoupil v platnost zákaz používání azbestu v průmyslu .
i v době , kdy byl azbest používán , s ním do úzkého kontaktu přišly jen určité skupiny lidí , například pokladači izolace , stavbaři , tesaři a dělníci v loděnicích .
toxin používaný v průmyslu v jiné éře se dnes těžko jeví jako důvod k obavám .
taková samolibost ale není na místě .
jak se ukazuje , v británii dnes vrcholí mezoteliomová epidemie .
počet úmrtí na mezoteliom je zde vyšší než v jakékoliv jiné zemi na světě .
2 500 úmrtí na toto onemocnění ročně je dvakrát více než počet obětí automobilových nehod .
počet úmrtí na následky mezoteliomu ročně od roku 1980 a odhadovaná úmrtí v budoucnu ve velké británii
důvod , proč teprve teď pociťujeme jeho účinky , přestože je použití azbestu již roky nezákonné ( všechny druhy azbestu byly nakonec zákonem zakázány v roce 1999 ) , je , že obvykle trvá několik desetiletí , než se mezoteliom rozvine .
pohroma v podobě mezoteliomu ne netýká jenom veteránů stavebního průmyslu .
azbest byl , a v mnoha případech stále je , přítomný v domovech , ve kterých žijeme , v kancelářích , kde pracujeme , ve školách , kde se učíme , a v obchodech , ve kterých nakupujeme .
mezoteliom tedy nerespektuje sociální vrstvu , bohatství , povolání ani věk .
privilegované bašty od londýnských obchodních domů po veřejné školy nepředstavují úkryt .
i parlament je plný azbestu .
dokonce i nemocnice , ve kterých by nás měli léčit , jsou úložiště tohoto smrtelného karcinogenu .
andrew lawson nebyl starý .
ani nepokládal izolaci .
snažil se zjistit , kde mohl přijít do kontaktu s azbestem .
pak na to přišel .
„ je možné , že hodně azbestu bylo v suterénních chodbách guy &apos; s hospital , kde jsem strávil šest let na praxi , “ napsal .
všichni - studenti , sestry , lékaři a vrátní - chodby používali .
otázkou je , kolik z mých současníků dostane stejnou nemoc ?
bohužel to byla otázka , na kterou dokázal částečně odpovědět .
„ ze čtyř lékařů , kteří byli na praxi v guy &apos; s hospital a u kterých se poté v minulých pěti letech projevil mezoteliom , “ poznamenal v dopise v roce 2010 , „ jsem jediný pořád naživu . “
kolik z nás onemocní ?
andrew lawson byl s mezoteliomem diagnostikován , když mu bylo 48 .
když 17. února tohoto roku zemřel , bylo mu 55 .
přežívat s touto diagnózou tak dlouho není obvyklé .
55 procent lidí diagnostikovaných s mezoteliomem zemře do osmi měsíců od diagnózy .
nemoc je vždy smrtelná .
nyní tedy můžeme pouze zopakovat lawsonovu otázku : „ kolik z nás onemocní stejnou nemocí ? “
podle předního britského odborníka na mezoteliom profesora juliana peta nejlepší odhad je , že mezi lety 1970 a 2050 , kdy se azbestová epidemie v británii odehrává , zemře asi 90 000 lidí .
většina z nich v současné době nemá tušení , že zemře tímto způsobem .
azbestový důl v quebecu , kanadě
při zběžném nahlédnutí do spisů z archivů soudů , na které se postižení často obracejí a vyžadují vyrovnání , ukazuje , jak moc se mezoteliomická pohroma rozšířila .
například tento červen přiznala společnost marks &amp; spencer , že z nedbalosti vystavila azbestu janice allenovou .
pro řetězec pracovala devět let , od roku 1978 do roku1987 , kdy dohlížela ve dvou prodejnách na sekci s oblečením - jednou z míst byla vlajková loď společnosti , obchod na oxford street .
allenové bylo pouze 18 , když pro m &amp; s začala pracovat .
dnes má dvě děti , kterým je přes dvacet .
„ předtím , než se to stalo , “ říká , „ jsem o mezoteliomu nikdy dřív neslyšela , sotva jsem něco věděla o azbestu .
nikdy mě ani ve snu nenapadlo , že by se mě mohl nějak týkat .
není moc lidí , kteří o azbestu něco vědí .
ve skutečnosti není azbest jedna látka , ale skupina šesti minerálů .
jméno dostal díky své fibrózní struktuře , která mu dává sílu a ohebnost .
ze šesti minerálů byly ve stavebnictví používány tři .
nejčastěji je dnes v budovách možné nalézt chryzotil , běžně známý jako bílý azbest .
byl používán ve střešních panelech , podlahových dlaždicích , bojlerových těsněních a dokonce v brzdovém obložení .
není tak smrtelný jako jiné formy azbestu , eu a who ho přesto považují za „ velké zdravotní riziko “ , které může způsobit smrt .
nebezpečnější ale je hnědý azbest ( amosit ) a modrý azbest ( krokydolit ) .
británie byla kdysi největším světovým dovozcem hnědého azbestu a odborníci tvrdí , že „ existuje přesvědčivý , ale nepřímý důkaz , že to bylo hlavní příčinou neobvykle vysokého výskytu mezoteliomu &#91; ve spojeném království &#93; . “
zaměstnankyně marsk &amp; spencer byla azbestu vystavena ve vlajkové prodejně v oxford street v londýně
janice allenová se možná nepovažuje za typickou oběť mezoteliomu , ale práce juliana peta poukazuje na to , že její příběh vůbec není neobvyklý .
jeho studie pacientů tvrdí , že „ podstatná část případů mezoteliomu bez známé expozice azbestu v práci nebo doma byla pravděpodobně způsobena vystavením azbestu v prostředí . “
značná část této expozice je způsobena „ běžným využíváním a zvětráváním “ budov .
zdá se , že nikdo si nemůže být jistý , že je v bezpečí .
zpráva goddard consulting , která zkoumala westminsterský palác , ukazuje , že ani lidé ve středu vlády nemusí tušit , že jsou možná vystavováni azbestu .
v roce 2009 zveřejnil goddard zprávu , podle které jsou služební výtahy a potrubí za místnostmi parlamentního výboru kontaminovány azbestem , jehož smrtelná vlákna by mohla být porušena něčím tak neškodným jako je „ silný proud vzduchu . “
ministři jsou často obviňováni z toho , že se starají jen o své vlastní zájmy , v tomto případě ale může být opak pravdou .
přestože ředitelství služeb parlamentu trvalo na tom , aby westminsterský palác dostal „ kladné lékařské osvědčení “ , počítá se nyní s tím , že bude zapotřebí jednoho milionu liber a několika let práce , aby byl parlament důkladně prohlédnut , zmodernizovala se elektřina a odstranil azbest , a že po volbách v roce 2015 budou poslanci spíše než na zelených lavicích ve westminsteru sedět v prostorách konferenčního centra královny alžběty ii .
ve zprávě goddardu stojí , že „ přítomnost azbestu není v souladu s několika předpisy . “
není možné říct , zda tento nesoulad bude stát životy .
všichni nyní mohou jen čekat .
jedna z osob , které nikdy nebyly schopné určit , kdy u nich došlo k expozici azbestu , je graham abbott , lékař .
stejně jako andrew lawson má i abbott ( 50 ) podezření , že byl azbestu vystaven při práci v nemocnicích .
„ pracoval jsem v nemocnici , kde byla prokázána přítomnost azbestu , “ říká , „ ale ve svém případě to nemůžu prokázat .
je obtížné pamatovat si všechna místa , kde pracoval , a kdy tam pracoval .
jasně si ale pamatuje na den na začátku prosince 2009 , kdy ho zdolalo něco jako zimnice .
bylo mu 45 , byl večer a zrovna byl uprostřed operace .
najednou jsem se roztřásl .
přišlo to naráz .
bylo mi hrozně .
myslel jsem , že nedojedu autem domů .
protože byl doktor , věděl , že bolest vychází z pohrudnice , výstelky okolo plic .
ale stejně jako janice allenová neměl důvod domnívat se , že se jedná o mezoteliom .
nakonec strávil doma měsíc .
zmatení doktoři mu udělali rentgen hrudníku a zavedli mu hrudní katetr , aby mu z plic odstranili tekutinu , kterou poslali na rozbor .
přesto neurčili diagnózu .
jeho stav se pomalu zlepšil a vrátil se do práce .
čas od času se mu ale symptomy vrátily , často poté , co si zacvičil a zadýchal se .
v roce 2011 přišel na operační sál jeden z abbottových pacientů s podobnými příznaky a následně u něj byl diagnostikován mezoteliom .
ani tehdy si však abbott nic nespojil se svým vlastním případem .
konec konců , jeho pacient byl o několik desítek let starší a v práci se dostal do přímého kontaktu s azbestem .
v tomto případě byla spojitost jasná .
v září 2011 se abbottův stav opět zhoršil a jeho lékař zkonzultoval jeho snímky z ct a rentgenu s panelem odborníků .
v prosinci 2011 , přesně dva roky poté , co se abbott začal cítit špatně , mu byla do prostoru mezi výstelkou hrudní dutiny a výstelkou plic zavedena sonda vybavená kamerou .
jsem optimista .
mám tendence nic si moc nebrat , “ říká .
abych byl upřímný , moc jsem si s tím nedělal starosti .
ale rachel , moje žena , si starosti dělala .
výsledky biopsie dorazily mezi vánocemi a novým rokem : „ řekli mi , že je to mezoteliom . “
graham abbott : diagnostikován s mezoteliomem
abbott se začal scházet se sestrami z charitativní organizace macmillan a jedna mu poradila , aby kontaktoval právníka .
v tu chvíli si uvědomil rozsah epidemie .
„ ukázalo se , že azbest byl hojně používán , především ve velkých veřejných budovách , které mají často azbestovou tepelnou izolaci v potrubí , “ říká .
u lidí , kteří byli v těchto budovách azbestu vystaveni , se nyní začíná nemoc projevovat .
mezoteliom se tedy nyní začíná týkat mladších lidí , kteří nemají riziková povolání .
ty nejnebezpečnější trubky tepelně izolované azbestem se v nemocnicích nacházely v suterénu , bylo tedy nepravděpodobné , že by ohrozily pacienty .
ovšem členové personálu , kteří suterénními chodbami přecházeli mezi budovami ( jako andrew lawson ) nebo jedli v suterénních jídelnách ( jako často graham abbott ) zcela jistě do kontaktu s toxickou látkou přišli .
jak se nyní ukazuje , byly několik desítek let po válce nemocnice místem , kde mohli pacientům zachránit život , ale také místem , které mohlo ohrozit život doktorů , kteří je léčili .
azbest se odstraňuje dodnes .
žáci si bunsenův kahan stavěli na azbestové podložky
a nejde jenom o nemocnice .
azbest se často používal v kancelářích , obchodech , knihovnách a radnicích kvůli svým výborným izolačním a nehořlavým vlastnostem .
ve školách také .
ve skutečnosti bylo mnoho lidí azbestu vystaveno už ve škole .
někde si v nesčetných hodinách chemie studenti stavěli bunsenův kahan na azbestovou podložku .
vznikly webové stránky zabývající se otázkou azbestu ve školách .
neškodné věci jako podlahové dlaždice nebo střechy přístřešků na nářadí v našich domovech běžně obsahovaly azbest .
„ jedná se o průmyslový jed zabudovaný do velkého množství domů , “ poznamenává andrew morgan , právník , který zastupoval andrewa lawsona v jeho žalobě proti guy &apos; s hospital .
v jednom případě proběhl jediný kontakt s azbestem , na který si žena trpící mezoteliomem dokázala vzpomenout , v 70. letech při boření zahradního domku .
takže si dávejte pozor , jak boříte zahradní domek .
s vědomím , že nemoc je neléčitelná , je dopad diagnózy obrovský .
„ chvíli trvá , než vám to dojde , “ říká graham abbott .
vrátil jsem se do práce a snažil se pokračovat , ale zjistil jsem , že se nemůžu soustředit na to , co dělám .
na operačním sále jsem byl dva týdny .
pak jsem si uvědomil , že budu muset odejít a vypořádat se sám se sebou .
no , dalších vánoc se nedožiju .
jedna z nejtěžších věcí byl přechod z pozice lékaře na pozici pacienta .
jako nesčetné množství pacientů před ním i on si pamatuje , jak se cítil zmatený z množství informací , se kterými se musel vypořádat .
„ bylo těžké tomu všemu porozumět , “ říká .
„ zeptal jsem se svého lékaře : „ kolik času mi zbývá ? “
bylo mi řečeno , že dvanáct měsíců .
pamatuju si , jak jsem si říkal : „ no , dalších vánoc se nedožiju .
tak to je . “
mezoteliom je obzvlášť destruktivní , protože samotný mechanismus toho , co nás udržuje při životě - samotné dýchání - je to , co způsobuje rakovinu , která zabíjí .
většina případů mezoteliomu je způsobena vystavením azbestu .
azbest tvoří drobná vlákna .
když se azbest poruší a vlákna se vdechnou , mohou se usadit v pohrudnici , výstelce plic .
azbestová vlákna pohrudnici dráždí a mohou vyvolat mutaci buněk .
„ problém představují vdechnutá azbestová vlákna ve tvaru jehliček , “ vysvětluje profesor tom treasure , kardiochirurg , který v roce 2001 nastoupil do guy &apos; s hospital .
do stejné nemocnice , kde byl andrew lawson zřejmě vystaven azbestu a která je paradoxně vedoucím centrem v léčbě mezoteliomu .
treasure lawsona zná a léčil i další pacienty , kteří byli azbestu vystaveni pravděpodobně během praxe v nemocnici .
jehličky azbestu se dostávají do tkáně plic , říká treasure , a „ samotné dýchání je tlačí na okraj tam , kde se nachází výstelka .
svou povahou je od samého začátku invazivní .
na mezoteliom běžné léčebné možnosti používané u jiných typů rakoviny tolik nezabírají .
žhavě se diskutuje například o účinnosti operace .
podle některých by stála za pokus .
treasure nesouhlasí .
„ nemůžete odstranit pohrudnici , “ říká .
nedostanete kolem ní skalpel .
rakovina „ příliš neodpovídá na chemoterapii “ , která sice „ má nějaký efekt “ , ale neléčí .
„ občas se vyskytne někdo , kdo rakovinu plic přežije , “ říká treasure .
ale nakonec všichni zemřou .
naštěstí někteří pacienti žijí mnohem déle , než se očekávalo .
autor stephen jay gould zemřel 20 let po diagnóze .
dva a půl roku od své vlastní diagnózy graham abbott stále bojuje .
po zjištění mezoteliomu se abbott zkontaktoval s andrew lawsonem který se , čtyři roky od své diagnózy , stal individuální podporou a poradcem pro stejně postižené lidi .
když volali , vesele se představil : „ dobrý den , dovolali jste se na centrálu rakoviny . “
„ byl hodně pozitivní , “ říká abbott .
nemoc mu diagnostikovali před čtyřmi lety a byl pořád velmi aktivní .
na začátku abbottovi nabídli šest cyklů chemoterapie , které by trvaly čtyři měsíce , a pravděpodobně by mu život prodloužily jen o měsíc .
„ byl jsem zoufalý , “ říká .
chtěl jsem to vzdát .
lawson ale „ dokázal věci ukázat v optimističtějším světle . “
poté , co navštívil několik lékařů , se abbott rozhodl pokračovat v léčbě s profesorem loic lang-lazduskim z oddělení hrudní chirurgie v nemocnici guy &apos; s hospital .
„ měl jsem výhodu , že jsem nemusel čekat , až mě k němu pošlou , ale jenom jsem tam zavolal a oni mě prohlídli , “ přiznává graham .
normální pacient by musel dostat žádanku a museli by mu schválit úhradu .
aby se mohli dostat k nejlepší dostupné léčbě , je pro pacienty s mezoteliomem otázka peněz klíčová .
ale když různé léčby nakonec nevyhnutelně selžou , mnoho pacientů čelí dalším finančním starostem - o budoucnost rodiny , kterou tu zanechají .
a proto se obrací na soudy a chtějí kompenzaci .
andrew lawson kontaktoval andrew morgana z field fisher waterhouse llp .
„ od roku 1898 se vědělo , že azbest je zdraví škodlivý , “ říká morgan .
v 60. letech se ale zjistilo , že i jeho velmi malé množství může představovat zdravotní riziko .
a zde se setkáváme s nedbalostí firem .
andrew lawson a guy &apos; s hospital se nakonec vyrovnali , ale podle morgana to nebylo „ plnohodnotné vyrovnání “ , protože lawson nemohl definitivně prokázat , že mezoteliom byl následkem expozice azbestu v guy &apos; s hospital .
po vyšetřování případu však mluvčí guy &apos; s hospital potvrdil , že „ azbest v inkriminované suterénní části byl odstraněn v 90. letech . “
to bylo pro andrewa lawsona příliš pozdě .
jak odstranit azbest
svádět expozici smrtelného azbestu na jednu firmu nebo místo výkonu práce - obvykle desítky let poté , co se tak stalo - se pro pacienty s mezoteliomem usilující o kompenzaci ukázalo být obrovským problémem .
hodně bývalých pracovišť změnilo majitele nebo zkrachovalo .
evidence pojistek se ztratila .
a ti , kteří se nyní obviněním brání , mají na své straně čas , což jejich žalobci rozhodně ne .
v reakci na tento fakt byla tento rok schválena důležitá nová legislativa , díky které je pro pacienty s mezoteliomem jednodušší domáhat se vyrovnání , i pokud není možné jejich bývalého zaměstnavatele dohledat .
zákon vytvořil 350 milionovou finanční rezervu , kterou hradí pojišťovny a která je určena lidem diagnostikovaným po červenci 2012 , kteří mohou prokázat , že byli vystaveni azbestu , ale nemají koho žalovat .
v takovém případě postižení dostanou 80 % z částky , kterou by jim v normálním případě soud přiřkl jako vyrovnání - přibližně 120 000 liber .
každý rok se očekává 300 úspěšně vyřízených žádostí .
andrew morgan si stejně jako pacienti s mezoteliomem myslí , že 350 milionů liber je „ dobrá práce “ .
„ je to dohoda sepsaná pojišťovnami pro pojišťovny , “ říká a poukazuje na to , že suma je čtvrtina toho , co by pojišťovny musely zaplatit , kdyby nezasáhl čas a lidé s mezoteliomem by byli schopní dopátrat bývalé zaměstnavatele a normálním způsobem je zažalovat .
dokonce i mike penning , bývalý ministr práce a sociálních věcí , přiznal , že zákon „ měl mezery . “
ale penning i morgan připouštějí , že vzhledem k sedmi úmrtím každý rok bylo nutné rychlé jednání .
„ lidé příliš trpí a pomoc potřebují hned , “ řekl penning v prosinci minulého roku během druhého čtení zákona týkajícího se mezoteliomu .
graham abbott byl v péči profesora loic lang-lazdunskiho 19 měsíců .
po počátečních konzultacích doporučil lang-lazdunski operaci , o které si na rozdíl od toma treasura myslel , že má pozitivní efekt .
po operaci následovala radioterapie a chemoterapie - trojitá léčba , u které se lang-lazdunski může chlubit mírou přežití pět let až u 40 % pacientů .
abbotta to posílilo .
„ to samozřejmě není ta nejdůležitější věc , “ říká abbott .
u pacientů to vidíte pořád .
existuje něco , co vás pohání .
když se vzdáte , může se váš stav velmi rychle zhoršit .
graham abbott podstoupil v březnu 2012 operaci .
koncem srpna dokončil poslední z šesti cyklů chemoterapie .
kontrolní prohlídky neukázaly žádné příznaky nemoci .
na další kontrolu jsem šel v březnu &#91; 2014 &#93; .
v hrudníku jsem měl rozesetých několik skvrn &#91; rakoviny &#93; .
zrovna se blížily moje padesáté narozeniny .
neohrožuje to život .
bere ho to .
abbott znovu podstoupil šest cyklů chemoterapie .
v současné době nejsou v jeho těle žádné stopy nádoru .
je to ale fyzicky i emočně vyčerpávající proces .
musíte myslet na praktické věci - na finanční zajištění , až umřu , nebo na to , abych ukázal ženě , jak funguje budík na kotli .
když se dozvíte špatné zprávy , začnete být negativní .
musíte se dívat dopředu .
jako pro otce ellie ( 16 ) a tamsin ( 14 ) to není vždycky jednoduché .
„ pro rodiče je to těžké , “ říká .
je těžké rozhodnout se , co říct a kolik toho říct .
po diagnóze jsem holkám řekl , že můj stav znamená , že nikdy nebudu starý .
jejich reakce byla odlišná .
tamsin je hodně společenská a divoká .
řekla to kamarádům a najednou nám začalo volat hodně lidí .
ellie byla zdrženlivější .
moc toho neřekla .
takovým rozhovorům musí čelit všichni pacienti s rakovinou .
u pacientů s mezoteliomem ale takové rozhovory nejsou odlehčeny nadějí nebo jen náznakem šance na přežití .
nemoc s sebou přináší ( a nakonec přinesla i stephenovi jay gouldovi ) neradostnou jistotu .
jak říká andrew morgan , „ mezoteliom život neohrožuje . “
těla nabalzamovaných faraonů se balí do azbestového plátna .
azbestová vlákna se používají ke zpevnění hrnců na vaření a zvyšují odolnost proti žáru .
plinius starší popisuje azbest .
byla vynalezena tkanina , která je nehořlavá .
viděl jsem z ní vyrobené ubrousky , které zářily v krbech na hostinách
v itálii se azbest začíná objevovat v komerčním využití , používá se k výrobě papíru ( dokonce bankovek ) a tkanin .
velké azbestové doly se otevírají v kanadě a jižní africe , brzy poté pak v americe , itálii a rusku .
během průmyslové revoluce je to výborná izolační látka v parních motorech a turbínách .
světová produkce azbestu se zvyšuje na více než 30 000 tun ročně .
statistici pojišťovny prudential zjišťují u lidí pracujících s azbestem vyšší úmrtnost a těm jsou potom zamítány životní pojistky .
v rochdale umírá nellie kershawová .
doktor william cooke potvrzuje , že částice azbestu v jejích plicích „ byly bezpochyby příčinou jejího úmrtí . “
jedná se o první případ tohoto druhu .
zaměstnavatelé kershawové , turner bros asbestos , odmítají odpovědnost .
nezaplatí žádné vyrovnání .
během 2. světové války se intenzivně stavějí lodě , práce v loděnicích představuje nejvyšší riziko vystavení azbestu .
zákaz dovozu modrého azbestu
odvolací soud potvrzuje první úspěšnou žalobu za újmu na zdraví následkem expozice azbestu v británii .
světová produkce azbestu se zvyšuje na více než 4 213 000 tun ročně .
spojené království dováží 139 000 tun .
britský ústav pro zdraví a bezpečnost vyžaduje , aby všichni dodavatelé azbestu měli licenci .
dovoz a použití modrého a hnědého azbestu jsou v británii zákonem zakázány .
v británii je zakázáno použití všech druhů azbestu .
ve spojeném království vstupuje v platnost zákon o mezoteliomu .
je spuštěn 350 milionový kompenzační program .
azbest je zakázán ve více než 50 zemích , v mnoha částech světa se však bílý azbest nadále používá jako levný stavební materiál .
světová produkce se drží na dvou milionech tun ročně .
čína odmítá dát hongkongu pravomoc zvolit si vedení - demonstranti slibují pomstu
čínský parlament se navzdory množícím se diskuzím o demokratické reformě v neděli rozhodl neumožnit voličům v hongkongu nominovat kandidáty do voleb v roce 2017 .
je pravděpodobné , že tento krok vyvolá dlouho slibované protesty v obchodní čtvrti hongkongu , neboť aktivisté se začali organizovat a chystat jen několik hodin po tomto oznámení .
čínský lidový kongres v podstatě povoluje komunistickým lídrům vyřadit jakéhokoliv kandidáta , který není loajální k pekingu .
„ sice nás to nepřekvapilo , ale rozzuřilo nás to , “ řekla zákonodárkyně emily lau , předsedkyně demokratické strany .
to není to , co peking slíbil .
lidem v hongkongu lhali .
a je jasné , že máme co do činění s autoritativním režimem .
na obranu čínského rozhodnutí řekl náměstek generálního tajemníka stálého výboru národního lidového kongresu li fei , že umožnit veřejné nominace ve volbách vedení hongkongu by způsobilo „ chaos “ .
od roku 1997 , kdy británie vrátila číně správu hongkongu , slibuje peking , že počínaje rokem 2017 budou moci obyvatelé volit výkonnou moc .
čínští lídři prezentovali nedělní rozhodnutí jako demokratický průlom , protože hongkongu umožňuje přímé hlasování , rozhodnutí ale také jasně dává najevo , že čínští vedoucí představitelé drží pevně v rukou proces nominování výboru , který je přísně kontrolován pekingem .
a podle nové klauzule budou přípustní pouze kandidáti , kteří „ milují zemi a hongkong “ .
rozhodnutí přišlo po letních měsících , které zaznamenaly jedny z největších a nejsledovanějších protestů v hongkongu za několik let .
za většinou pro-demokratických protestů v hongkongu stojí hnutí okupace centrálu s láskou a mírem , jehož organizátoři pohrozili uzavřením finanční čtvrti , pokud jim peking neudělí všeobecné hlasovací právo .
v neděli večer , jen několik hodin po oznámení , se stovky příznivců hnutí okupace v dešti shromáždily před sídlem vlády hongkongu .
na demonstraci organizátoři sdělili , že jejich hnutí vstupuje do nové fáze občanské neposlušnosti a že v nadcházejících týdnech zahájí vlny protestů .
neposkytli však žádné další detaily , očividně se chtěli vyhnout problémům s úřady .
ve svém internetovém prohlášení organizátoři řekli , že hnutí „ zvážilo okupaci centrálu jenom jako poslední krok v případě , že se vyčerpají všechny možnosti dialogu a nezbude žádná jiná volba .
musíme s politováním oznámit , že dnes byly veškeré možnosti dialogu vyčerpány a obsazení centrálu je nevyhnutelné .
úřady v hongkongu se na oznámení pekingu celé dny připravovaly a v neděli posílily ochranu sídla vlády a rozmístily policisty a barikády .
podněcování nepokojů je podle mnohých obyvatelů hongkongu známka toho , že pomalu ztrácí kontrolu nad městem .
příval lidí z pevniny zvyšuje konkurenci v oblasti výrobků a služeb .
rostou také obavy , že hodnoty jako demokracie a svoboda slova jsou zvyšujícím se tlakem z pekingu ohýbány .
někteří lidé kritizují hnutí okupace centrálu a říkají , že jejich demonstrace ohrožují obchod - záchranný člun hongkongu .
„ protest , o kterém mluví , by mohl způsobit mnohem větší ekonomickou škodu podle toho , kolik lidí se zúčastní a na jak dlouho , “ říká politička regina ip , která hnutí dlouhodobě kritizuje .
nechceme , aby se rozšířily obavy , že hongkong se dostává mimo kontrolu .
takové vnímání by mohlo poškodit investice .
čínská státní média také v posledních dnech přišla se zprávami , které demokratické aktivisty v hongkongu vykreslují jako podvratné agenty řízené západem .
v létě aktivisté zorganizovali neoficiální referendum o hlasovacích právech , ke kterému přišlo 780 000 účastníků - více než pětina voličů v hongkongu .
a v červenci se desítky tisíc lidí zúčastnily jedné z největších pro-demokratických demonstrací v historii oblasti .
předvolební agitka ?
liga v jihlavě nosí název podle politického hnutí
malou kopanou hraje v krajském městě vysočiny přibližně 1 600 amatérských sportovců .
a jejich nejvyšší soutěž se nově jmenuje společně pro jihlavu liga .
název dostala podle jednoho hnutí , které jde do říjnových komunálních voleb .
desítkou na jeho kandidátce je navíc šéf malé kopané v jihlavě jan mráka .
&quot; byla valná hromada , kde s tím žádný problém nebyl , &quot; uvedl mráka .
situací kolem první ligy malé kopané se už zabývali právníci jihlavské radnice a doporučili změnit systém rozdělování dotací .
malá kopaná získala loni podle webu města okolo milionu korun .
i letos jde o částku ve stovkách tisíc .
podle právního názoru není postup malé kopané v rozporu se zákonem ani směrnicemi magistrátu .
situace je ale pro úřad podnětem pro úpravu pravidel přidělování grantů a dotací , &quot; uvedl mluvčí magistrátu radek tulis .
čerpat dotace od města a současně vyjádřit jako malá kopaná podporu ve volbách jedné politické straně , to už asi nepůjde .
na vysočinský &quot; velký &quot; fotbal podobný požadavek od politiků zatím nepřišel .
že by třeba vznikly čssd krajský přebor , ods divize nebo kdu-čsl 1 .
a třída a podobné soutěže ?
nebyl bych pro .
naopak bych byl rád , kdyby se na nás obrátili sponzoři z řad firem , &quot; poznamenal předseda krajského fotbalového svazu miroslav vrzáček .
šéf malého fotbalu jiné strany a hnutí do názvu ligy nepustí
podle hráčů malé kopané by si tento sport v jihlavě zasloužil vlastní areál s šesti hřišti , šatnami a sociálním zařízením .
&quot; například hřiště na stoupách není naše , jsme tam v pronájmu , &quot; upozornil ondřej lapeš z klubu starlet jihlava .
nejvhodnější lokalitou by byl český mlýn .
tam se ale bude stavět například podle mého názoru nesmyslný areál pro skejťáky , kterých je v jihlavě asi tak padesát , &quot; upozornil mráka .
primátor jihlavy jaroslav vymazal ( ods ) reagoval , že malá kopaná využívá hřiště s umělou trávou v ulicích rošického a na stoupách , která jsou v majetku města .
chceme budovat taková hřiště , která mají maximální využití .
chystáme modernizaci či výstavbu sportovišť u škol , která budou v odpoledních hodinách přístupná .
myslím si , že pro malou kopanou se za poslední roky udělal obrovský pokrok , &quot; dodal vymazal .
další politické strany v názvech lig se podle jana mráky neobjeví .
máme omezení .
pokud k nám do partnerství někdo z jednoho oboru vstoupí , tak druhého už tam nedáváme , &quot; vysvětlil .
&quot; politické hnutí v názvu ligy , to považuji minimálně za nešťastný krok , &quot; řekl člen radniční komise pro sport karel voldán .
&quot; ať si ale voliči zhodnotí , zda pan mráka využívá spolek malá kopaná jihlava a dotace města pro politické účely , nebo ne , &quot; dodal .
americká tradice proniká do univerzitního života - prváci mohou lítat tryskovým letadlem
jsme rádi , že na poptávku můžeme odpovědět spuštěním první luxusní cestovní služby pro studenty v británii .
za účelem zanechání co nejlepšího dojmu při příjezdu na univerzitu nabízí společnost také možnosti dopravy včetně soukromého tryskáče nebo vozů typu rolls-royce phantom , aston martin nebo mclaren p1 .
stewart také prohlásil , že služba má i svou bezpečnostní stránku .
servis je ideální možností pro studenty , kteří by jinak museli svoje věci vláčet přes celý stát v nebezpečně naloženém autě .
těšíme se , že s našimi vif ( very important fresher - velmi důležitý prvák ) variantami tento rok studentům zajistíme , že na univerzitu dorazí s minimem nervozity a maximem luxusu .
mluvčí společnosti řekl , že vzhledem k tomu , že se služby teprve spustily , nemají zatím žádné rezervace , ale dodal : „ studenti si začnou dělat rezervace během několika příštích týdnů . “
společnost také uvedla , že přestože studenti platí roční školné ve výši 9 000 liber , očekává , že služba si na trhu najde své místo .
v porovnání se studenty před deseti , dvaceti , třiceti nebo čtyřiceti lety jsou dnešní studenti jiní , co se týče očekávání a přání - je důležitější než kdy jindy udělat správný první dojem a program vif je přesně ten vhodný způsob , jak toho docílit .
národní unie studentů ale službu kritizovala jako nedosažitelnou .
megan dunnová , viceprezidentka unie pro vyšší vzdělávání , poznamenala : „ pro většinu studentů je takový projekt nedosažitelný .
hodně studentů , kteří tento měsíc nastupují na univerzitu , se musí předtím , než vyhodí tisíce liber za něco tak jednoduchého jako dorazit na kolej , vyrovnat s finanční krizí , protože dostupná finanční podpora v podobě půjček a grantů nedokáže držet krok se stoupajícími náklady na základní potřeby .
feministky se po událostech ve fergusonu staví proti rasismu a chování policie
na začátku měsíce zabil policista ve fergusonu v missouri neozbrojeného mladíka .
přítomní čekající na pohřeb s rukama vzhůru skandují : „ ruce vzhůru , nestřílejte ! “
po dva týdnech protestů ve fergusonu v missouri kvůli zastřelení neozbrojeného mladíka michaela browna , zaznamenala bloggerka miriam zoila perézová posun v internetových diskuzích bělošských feministek .
zjistila , že když dojde na prosazování reprodukčních práv a rovnosti příjmů , upřednostňují bělošské feministky pohlaví před rasou .
se vzrůstajícím napětím na středozápadě , které přitáhlo pozornost celostátního tisku , si perézová všimla , že reakce bělošek se ve 100 % soustředí na rasu .
v porovnání s reakcemi černošek brzy po střelbě 9. srpna se osobní články s nadpisy jako „ zamyšlení bělošky nad fergusonem “ nebo „ feminismus není jen o utlačování žen “ objevily relativně pozdě .
podle perézové to ale představuje důležitou změnu .
„ myslím , že ve feministickém hnutí není moc lidí , kteří by o rase a výsadách mluvili na takové úrovni , “ prohlásila .
lidé cítili , že k tomu , co se stalo , se musí vyjádřit .
pro krizi , které čelíme , je to charakteristické , protože &#91; situace ve fergusonu &#93; je tak rasově vyhraněná , že na to museli upozornit .
podle profesorky angličtiny na státní univerzitě v ohiu korithy mitchellové vynesl ferguson na světlo problémy , kterým afroameričanky musejí čelit každý den a které v kulturní sféře nejsou vnímány jako „ ženské otázky “ .
„ můžu na facebooku zveřejnit vtipné historky ze života se svým partnerem a dostane to 150 liků od lidí z celého světa , “ řekla mitchellová .
když napíšu něco o tom , že barevní jsou ve své vlastní zemi v pasti , je to ticho ohlušující .
„ jak je možné , že žena může veřejně mluvit o vztazích , ale ne o bezpečnosti ve veřejném prostoru ? “ zeptala se .
pro černošky jako je mitchellová , které se zabývaly otázkou rasy , pohlaví a sexuality v americké historii , neexistuje mezi otázkami rasy a pohlaví dichotomie .
černošky si podle ní nemohly dopřát luxus přehledně si tyto problémy rozdělit : každý den žijí v této smíšené realitě .
přestože bělošky dnes otázku rasy a pohlaví v mainstreamových feministických kruzích slučují , angela hatteryová , profesorka přednášející ženskou otázku a genderová studia na george mason university , říká , že jejich předchůdkyně dělaly opak .
mezi lety 1865 a 1890 bylo nejméně 10 000 černochů lynčováno a důvodem bylo téměř ve všech případech znásilnění bělošky , “ řekla hatteryová .
ke zdůvodnění lynčování jste potřebovali spolupráci bělošek .
podle hatteryové rozkol mezi běloškami a černoškami přišel , když bojovnice za volební právo jako susan b . anthonyová prozkoumaly na konci 19. století terén a uvědomily si , že volební právo může mít jenom jedna skupina lidí - ženy nebo černoši .
„ rozhodly se vsadit karty na hlasovací právo pro ženy a na právo pro černochy se zaměřit později , “ vysvětlila hatteryová .
když si tohle uvědomíme , získáme důležitý náhled na to , proč barevné ženy běloškám nevěří .
neodvedly jsme dobrou práci .
nikdy jsme černoškám nepomohly chránit jejich manžele a děti .
i poté , co ženy v roce 1920 získaly volební právo , trvalo deset let , než se začaly organizovat proti lynčování v asociaci jižanských žen pro předcházení lynčování .
skupina vznikla 40 let poté , co si černošky poprvé řekly o pomoc .
podle mitchellové vzedmutí reakcí bílých feministek na otázky , které dění ve fergusonu přineslo - otázka chování policie , rasová diskriminace - odráží dobu , kdy bílé feministky musely „ dohánět “ otázky , se kterými se černošky potýkaly generace .
„ nebylo by skvělé , kdyby aktivistky na těchto prostorech &#91; tradičního feminismu &#93; braly právo vychovávat dítě stejně vážně jako braly právo na antikoncepci ? “ nadnesla mitchellová .
druhá vlna feministek , které udělaly kariéru bojem za reprodukční právo a přístup k antikoncepci , nyní zjišťují , co to znamená .
významné feministické aktivistky jako gloria steinemová vzaly dva týdny po zastřelení michaela browna útokem facebook , kde zveřejnily sloupek rebeccy carrollové z guardianu , která se dožadovala toho , aby bílí američané razantněji protestovali proti rasismu .
„ doufám , že ženy , které mají různé , ale přesto obdobné důvody pro chápání nebezpečí ve společnosti - a názorů na rasu , které se v průzkumech veřejného mínění výrazně liší - budou usilovat o změnu , “ napsala steinemová .
přestože steinemová zastává intersekcionální feminismus , který zahrnuje otázky rasy i pohlaví , její komentáře na otázku rasy v americe některé lidi matou .
odbornice z american enterprise institute christina sommersová , autorka knihy „ kdo ukradl feminismus ? “ , řekla pro she the people , že mladí muži ve spojených státech , především mladí barevní muži , jsou „ mnohem zranitelnější než jejich sestry “ , ale poznámky steinemové stran fergusonu čelí kritice , kterou vyvolala již dříve .
máme nyní stovky speciálních programů pro dívky a mladé ženy , ale téměř žádné pro chlapce .
ale když bílý dům spustil malý program my brother &apos; s keeper , který měl pomoci zranitelným mladým černochům a hispáncům , vyvolalo to u mnoha feministek včetně glorie steinemové rozzuřené reakce .
vztah policie k černošské komunitě není jediný problém , který se dostává do popředí zájmu mainstreamového feminismu .
poté , co americká pohraniční policie zadržela tento rok na jihozápadě země téměř 63 000 mladistvých bez doprovodu , znovu vyvstala otázka reformy imigračním zákonů - tentokrát jako ženská otázka .
andrea mercadová , spolupředsedající we belong together , organizace mobilizující ženy pro reformu imigračních zákonů , řekla , že aby bylo možné otázku přednést jako pro ženy nezbytnou , jediné , co musela udělat , bylo sdílet příběhy imigrantek .
„ mluví samy za sebe , “ říká mercadová .
vzhledem k tomu , že většina pracovních povolení se uděluje mužům , ženy , které s nimi přijdou , se ocitají v pozici , kdy jsou zranitelné , co se týče domácího násilí a zneužívání .
„ tyhle příběhy mají v ženských organizacích ohlas , “ uvedla .
bydliště prasete v ipswichi na prodej
realitní kancelář odstranila obrázek domu na prodej v suffolku - když ho zveřejnila , odpočívalo na něm v obýváku prase .
jednopokojový samostatný domek , který je na prodej za 120 000 liber , stojí na soukromé cestě v ipswichi .
informační fotografie zahrnovaly obrázek obývacího pokoje , ve kterém odpočívá s hlavou na pohovce prase .
realitní kancelář connells uvedla , že prase na fotografii je domácí mazlíček majitelů .
„ fotka se tam ocitla omylem , a proto už byla odstraněna , “ řekl mluvčí kanceláře .
v informacích o nemovitosti popsala realitní kancelář connells bývalou modlitebnu jako „ ojedinělý samostatný jednopokojový domek . “
přestože kancelář fotku ze svých webových stránek již odstranila , v propagačních materiálech se stále objevuje .
prodej domu vyvolal zájem na sociálních sítích , kde se někteří ptali , zda je prase zahrnuto v ceně .
po výhře v loterii má město harvey na jihozápadě čerstvého milionáře
hráč loterie v harvey získá milion .
probíhá pátrání po novém milionáři na jihovýchodě perthu , jeden šťastlivec si ze sobotního tažení loterie domů odveze 1,1 milionu dolarů .
trafiky v harvey měly při rozdělování štěstí již podruhé během pěti let , naposledy se v listopadu 2009 jednalo o výhru jednoho milionu dolarů .
štastný výherce se ale teprve musí přihlásit .
majitel obchodu steve forward řekl , že o výhře mluví celé město na jihozápadě perthu .
je to hlavní téma a všichni jsou rozrušení .
mysleli jsme , že podobná výhra je na dotek .
osm vítězů si v západní austrálii minulý měsíc rozdělilo jednu výhru , čímž završilo několik šťastných týdnů .
minulý víkend se hráč v canning vale stal jedním z pěti srpnových milionářů a jen o několik týdnů dříve pár v belmontu vyhrál neuvěřitelných 7,5 milionu dolarů .
vítězná dvojice si sázela dvacet let a řekla , že výhra jim umožní procestovat svět a koupit si nový dům .
milionář z harvey je 59. jediným výhercem loterie v západní austrálii za tento rok , celkem vyhráli 85 milionů dolarů .
vlaky deutsche bahn večer nevyjedou .
strojvůdci chtějí vyšší mzdy
gdl v tiskovém prohlášení označil protest za varovnou stávku , pro kterou schválně vybral čas mimo dopravní špičku .
zvoleným časem stávky bere gdl ohled na mnoho lidí , kteří se z víkendu vracejí po železnici až během prvního pracovního dne .
zároveň myslíme i na lidi dojíždějící za prací během dne , &quot; uvedl odborový svaz v pondělí ráno v tiskovém prohlášení k vyhlášení stávky .
&quot; naše první stávka by měla zasáhnout především nákladní dopravu , méně už cestující , &quot; doplnil gdl .
db zatím oficiální reakci na vyhlášení stávky nezveřejnily .
není ani jasné , jak se protestní akce dotkne mezinárodních železničních spojení , mimo jiné s českem .
odbory požadují zvýšení mezd strojvůdců o pět procent a zkrácení pracovní doby o dvě hodiny týdně .
v současnosti se průměrný plat strojvůdců pohybuje v závislosti na odpracovaných letech mezi 36 tisíci a 46 tisíci eury ( 998 tisíc a 1,27 milionu korun ) ročně .
strojvůdci u db pracují 39 hodin týdně .
db odmítají přistoupit na růst platů při zkrácení pracovní doby .
zdůrazňují přitom , že se mzdové ohodnocení strojvůdců musí vyvíjet stejně jako u ostatního železničního personálu , u kterého db se zkracováním pracovního týdne nepočítají .
hrozilo , že krestův vůz začne hořet .
proto na barum rallye skončil
co přesně se stalo ?
šlo o vadu materiálu .
auto bylo úplně nové , takže mě ani nenapadlo , že by se něco takového mohlo stát .
nešlo výfuk provizorně opravit a pokračovat v pomalejším tempu do servisu , kde by ho mechanici vyměnili ?
kdybychom tam zamířili rovnou , tak ano .
ale nás ještě čekaly další dvě erzety a to nešlo .
je v něm vysoká teplota a riziko , že by auto začalo hořet , bylo velké .
to si nemůžu dovolit .
v plném tempu jste zvládl pět rychlostních zkoušek .
jaký jste z nich měl dojem ?
velmi dobrý .
cítil jsem se jako zamlada .
byli jsme rychlí , přitom jsem nejel přes vint .
všechno bylo způsobené tím , že auto jsme piplali více než půl roku , aby bylo na nějaké úrovni .
závod ukázal , že se nám to povedlo .
rozjel jste ho tak , že jste mohl reálně pomýšlet na vítězství .
sebe i auto jsem připravil tak , že jsme na výhru opravdu měli .
práce nepřišla vniveč .
na druhou stranu výsledek , na který jsme mohli pomýšlet , se nedostavil .
ale to je barumka .
technika bohužel řekla ne .
nebyl jste jediný ze špičky , který předčasně odstoupil z boje o prvenství .
vypadli z něj i zahraniční favoriti breen , abbring či lappi .
překvapilo vás , že tolik favoritů odstoupilo ?
ano .
hlavně pro diváky to byla škoda , protože závod tím předčasně skončil .
na špici se dlouho pohyboval i jaromír tarabus , kterému chystáte vůz .
jenže doplatil na to , že vylétl z trati a nabral téměř dvouminutové manko .
jak jste byl s jeho výkonem spokojený ?
je to škoda , protože mohl zopakovat stupně vítězů .
vždyť zajížděl první druhé časy .
ale i mira potvrdil , že auto jsme nachystali dobře .
jel hodně rychle .
přesně před rokem jste ohlásil konec kariéry , přesto jste se na startu barum rally objevil .
může z vás dobrý pocit z jízdy zase udělat pravidelného účastníka rallyových závodů ?
v této chvíli určitě ne .
loni jsem řekl , že barumka je můj poslední závod a stejně jsem to nedodržel .
rozhodl jsem se , že ji pojedu zase .
byl to můj zdejší devatenáctý start , a když bude za rok zase šance , asi do toho půjdu .
ale o ničem dalším nepřemýšlím .
spousta lidí dorazila k trati jen kvůli vám .
potěšilo vás to ?
do jisté míry jsme startovali právě kvůli nim .
spousta lidí , známých či neznámých , se neustále ptala , jestli pojedu .
chtěl jsem jim udělat radost .
co vás čeká po barumce ?
tým pokračuje dál .
příští týden pojedeme do vyškova , kde bude závodit robert adolf .
doufám , že auto tady moc nepoškodil .
navíc si na tento závod od nás chce půjčit fabii honza sýkora .
s mirou nás čeká evropský dvojzávod ve švýcarsku a na korsice .
k tomu už budeme muset chystat věci na příští rok .
můžete už něco naznačit ?
ne , nic není rozhodnuto .
když korsická rallye patřila do mistrovství světa , pátým místem jste tam dosáhl svého maxima v seriálu .
neláká vás vyzkoušet si tamní tratě znovu ?
neláká .
ústní dohoda se zaměstnavatelem může být problém
bohužel jste si nenechal vystavit od lékaře potvrzení o pracovní neschopnosti , které slouží jako důkaz pro organizaci , že nemůžete ze zdravotních důvodů vykonávat pracovní povinnosti .
absenci jste navíc ihned neoznámil zaměstnavateli .
následně sice došlo k dohodě , že dané dny budou evidovány jako dovolená , dohoda ale proběhla pouze ústně .
přestože zákoník práce neukládá povinnost nechat si písemně potvrdit souhlas zaměstnavatele s čerpáním dovolené , v praxi se tento postup osvědčil .
pokud dojde pouze k ústní domluvě , nemáte o dohodě potvrzení .
později může být údajný souhlas s čerpáním dovolené , stejně jako ve vašem případě , popřen a nepřítomnost v práci posuzována jako dlouhodobá neomluvená absence , tudíž důvod k okamžitému zrušení pracovního poměru dle § 53 zákoníku práce .
pro případ soudního sporu o domluvě se zaměstnavatelem vám tak chybí prokazatelný důkaz .
pracovní poměr s vámi ale nebyl zrušen dle § 53 , pouze máte dané dny uvedeny v zápočtovém listu jako neomluvenou absenci .
neomluvená absence v zápočtovém listu nemá stejné důsledky jako § 53 ( např. nemožnost pobírat hmotné zabezpečení v nezaměstnanosti ) , přesto je tím ztížená možnost hledání nového zaměstnání .
doporučujeme vám znovu navštívit daného lékaře a nechat si písemně potvrdit , že skutečně došlo k úrazu , v důsledku kterého jste byl práce neschopný ( nejedná se o tzv. &quot; neschopenku &quot; , jde pouze o doklad lékaře ) .
při hledání nového zaměstnání můžete zmíněný doklad předložit a situaci vysvětlit .
v praxi je vhodné nepodceňovat jak vystavení písemného lékařského potvrzení o pracovní neschopnosti , tak brzké oznámení zaměstnavateli či vyžádání písemného souhlasu s čerpáním dovolené .
vyvarujete se tak případných komplikací .
nehoda tonyho stewarta při návratu na trať
návrat na trať skončil pro tonyho stewarta jen kousek za polovinou závodní dráhy atlanta motor speedway .
stewart podruhé narazil do hrazení poté , co mu v 172. kole praskla pravá přední pneumatika , a závod pro něj skončil .
stewart dovezl poničené auto do garáže , reportérům se nevyjádřil a odešel .
šéf jeho týmu chad johnston řekl , že tým auta č. 14 je zklamaný , ale bude se nyní soustředit na závod v richmondu , ve virginii , který se uskuteční příští víkend .
„ chtěl bych , abychom měli lepší výkon a lepší závěr , “ řekl johnston .
pojedeme do richmondu a budeme doufat , že se nám tam bude dařit víc .
stewart narazil do hrazení poprvé v nedělním večerním závodě po kolizi s kylem buschem , což si vyžádalo opravu pravého boku jeho auta .
„ do dnešního závodu jsme vkládali naděje na dobré zakončení , “ řekl johnston a dodal : „ prostě to nevyšlo . “
nedlouho po druhé havárii bylo stewartovo auto naloženo a tým sbalen a připraven k odjezdu .
poté , co jeho auto zasáhlo a usmrtilo jiného řidiče na závodě v new yorku , vynechal stewart tři závody nascar sprint cup .
rozhodl se tento víkend vrátit a k tomu potřeboval vyhrát buď závod v atlantě nebo následující závod v richmondu , aby dohnal místo v tabulce .
k závodění se vrátil během vyšetřování tragické nehody , při které zemřel dvacetiletý kevin ward jr . , který stewartovi vjel během závodu do cesty .
úřady řekly , že prošetřování příčiny nehody potrvá minimálně další dva týdny .
zatím se nerozhodlo o tom , zda bude stewart čelit nějakým obviněním .
trojnásobný šampion se před závodem dočkal vřelého povzbuzování .
stewart začal na 12. místě , na začátku závodu se propracoval na 10. a potom dokonce na 4 .
poté , na začátku 122. kola , se buschovo auto č.
18 dostalo mimo kontrolu , vyjelo ze druhé zatáčky a narazilo do stewartova , čímž oba vozy poslalo do hrazení .
stewart pokračoval , ale stáhl se na 21. místo .
praha vybrala nové správce stanovišť taxi , vydělá 12,3 milionu
praha dokončila výběrová řízení na nové správce stanovišť taxislužby .
za 103 parkovacích stání získá ročně zhruba 12,3 milionu korun .
donedávna přitom za stejná místa pro řidiče vozů taxi ročně vybírala 150 tisíc korun .
informoval o tom radní lukáš manhart ( top 09 ) .
dříve město při výběru správců používalo losování .
vítěz pak získal pronájem za paušální částku 1000 korun na rok .
pravidla se ale změnila .
v současnosti rozhoduje výše nabídky .
&quot; rok od vypovězení původních nájemních smluv a zahájení výběrových řízení se prokázalo , že nový systém pronájmů je pro prahu daleko výhodnější a celkově spravedlivější , &quot; tvrdí radní .
nejdražší flek je na perštýně
nejvyšší cenu nabídli zájemci o stanoviště v ulici na perštýně .
ročně zaplatí 2,1 milionu korun .
přibližně 1,5 milionu korun noví správci zaplatili za místa před obecním domem nebo na václavském náměstí .
nová pravidla pronájmů stanovišť taxislužby radní přijali na podzim roku 2012 a v létě loňského roku vypověděli původní nájemní smlouvy .
výběrová řízení se konala ve čtyřech vlnách a nového správce našlo 29 stanovišť .
už podruhé jsme letos museli čistit studnu .
celou jsme ji pokaždé vypustili , čímž vzniknul prakticky druhý rybník kolem chaty .
pak jsme tam nalili savo .
neuvěřitelný puch !
naše studna ve sklepě skýtala vždy dostatek nádherné voňavé vody .
a to nebyla kdovíjak odborně udělaná , děda ji vydlabal svépomocí .
už dávno .
byla jen tak na tři skruže a celkově svérázná , jako ostatně všechno na chatě , ale jak říkám .
voda byla skvělá .
až do letoška .
když jsme zahajovali sezónu , samozřejmě jsme vodu vyčerpali .
když tam stála řadu měsíců , zasloužila si to .
jenže i pak se nám zdálo , že ta voda nějak nevoní .
napadlo nás , jestli tam něco nespadlo .
v místě , kde procházelo čerpadlo , to při troše smůly bylo možné , tam deska docela nedoléhala , tak byl otvor utěsněný kusem cihly .
naše inspekce potvrdila , že se cihlou hýbalo .
jinak ve vodě nebylo nic vidět , a to jsme ji prosvítili až na dno .
takže jsme ji opět vypustili a přečistili .
samozřejmě jsme vylepšili improvizované těsnění kolem trubky čerpadla .
ve sklepě jsme si všimli ale divných věcí .
na zemi ležel ulepený balíček s nějakými kostičkami .
tak to aspoň vypadalo .
a o kus dál další .
teď to vypadalo jako oslintaná myš .
u stropu , v místech , kde jsou průduchy , dědův vynález , byly zbytky ryby !
a těžce jeté !
náš sklep je taky svérázný .
někdo by řekl , že děda zkrátka podhrabal chatu .
a nebyl by tak daleko od pravdy .
stěny i podlaha je jenom udusaný písek , pouze strop je podbitý .
dávají se tam hlavně lodě .
a kola .
a lehátka na pláž .
vrata se širokými mezerami byla většinou otevřená , jak tam v jednom kuse někdo chodil .
u stropu několik již zmíněných průduchů .
bez sítě , takže tam běžně zalétávají ptáci a na trámech si staví hnízda .
o myších je zbytečné se zmiňovat .
děda chtěl , aby to luftovalo , a to ono zas jo .
teď ovšem ani luft nepomohl .
celý sklep páchnul .
vyčistili jsme tedy i celý sklep .
zvlášť ta ryba na trámu byla výživná !
vyhodili jsme i věci , co byly kolem : prkna , heraklitovou desku , a tak .
naše chata na dálku vítala kolemjdoucí dezinfekčním odérem .
přemýšleli jsme , kdo nám tam mohl ty nechutné zbytky natahat ?
nejbližší kočka bydlí dva kilometry odsud ve vsi .
těžko by k nám chodila svačit .
dědu napadl jeden soused , který není úplně v pořádku .
jestli on ten franta nám ty nechutnosti tam nešoupnul průduchem ?
je tu prakticky po celý rok , blbý nápady , to on má .
rozhodli jsme se sklep i studnu hlídat a pravidelně kontrolovat .
po několika dnech bylo všechno v pořádku .
vodu jsme zase začali používat , zatím jenom na mytí a praní , než budou hotové testy , ale už to bylo dobré .
tahat vodu z lesní studánky není nic , co bych chtěl dělat nějak dlouho .
jednou jsme zaslechli strašlivý úzkostný štěkot naší feny .
máma se podívala z balkónu a viděla v trávě vedle verandy dlouhou silnou černou hadici .
réza nad ní poskakovala a pištěla jak blázen .
máma jí vynadala , protože myslela , že réza vyhrabala odpadovou hadici z umyvadla .
najednou se ale ta hadice částečně smotala do klubka a částečně se napřímila .
na balkón dolehlo syčení .
réza dostala hysterický záchvat .
seběhli jsme dolů .
užovka , dlouhá hodně přes metr a tlustá jak býkovec , se chystala spolknout obrovskou ropuchu a réza jí v tom bránila .
nebylo jasné , jestli chtěla ropuchu zachránit nebo jestli ji chtěla sežrat sama , ale to bylo nepodstatné .
když užovka uviděla přesilu v podobě celé naší rodiny , asi si řekla , ať si ji teda sežereme , když jsme takoví hladi , a elegantně se protáhla průduchem do sklepa .
letěli jsme za ní .
jako blesk skočila za studnu .
jen tak mimochodem jsme zaznamenali na její desce další páchnoucí balíček .
podle vůně asi rybka .
předevčírem tam nebyla !
naše nové zabezpečení kolem čerpadla bylo trochu šejdrem .
a to jsme sklep zamykali i přes den .
že by ...
vyšli jsme ven a tam jsme každý zalehl k jednomu průduchu .
nečekali jsme dlouho .
za studní to zašramotilo .
nejdřív se objevila plochá hlavička se žlutými měsíčky na krku .
pak se vyhoupla na studnu celá užovka .
omotala se kolem čerpadla a začala se dobývat dovnitř .
vyhozený zaměstnanec se mstil , nakoupil na firmu notebooky a prodal je
zhrzený zaměstnanec po propuštění nakoupil na firmu počítače a pak je prodal .
získané peníze stihl ještě před zadržením policií utratit .
během krátké doby muž nakoupil ve dvanácti případech celkem šestnáct počítačů za více než dvě stě tisíc korun .
&quot; notebooky po převzetí odvážel do olomouce , kde je prodával po bazarech , &quot; uvedl vrchní komisař šumperské policie rostislav brückner .
motivem podvodů byla msta zaměstnavateli za propuštění a také zisk peněz .
&quot; při výslechu nám tvrdil , že peníze použil na splátky úvěrů , &quot; sdělil brückner .
policie rovněž zjistila , že podvodník je patologický hráč , který se opakovaně léčil na psychiatrii .
peníze tak mohly skončit také ve výherních přístrojích nebo ve videoloterijních terminálech .
&quot; faktem je , že jsme u něj žádné peníze nenašli , &quot; řekl komisař .
podvodníkovi , který byl už jednou trestán za krádeže , teď hrozí pobyt ve vězení v délce jednoho roku až pěti let .
policisté zatím nesdělili , zda hrozí trest také bazarům , které notebooky pod cenou koupily a dál je prodávaly .
&quot; je pravda , že přebíraly úplně nové zboží , což je minimálně podezřelé , &quot; konstatoval komisař .
žádný z majitelů bazaru však zatím nebyl obviněn .
pojď , ještě kousek , to zvládneš aneb jak jsem si užil we run prague
letos si na nás pořadatelé připravili několik změn .
tou největší byla změna trasy , která přivedla cíl na náplavku , místo aby vedla zpět do žlutých lázní .
na závod jsem se těšil spolu se zbytkem rungo.cz týmu , chystal jsem se ho ale prožít tak trochu z druhé strany .
s celým týmem jsme se rozhodli osobně zdravit naše čtenáře na stánku , kde jsme se společně fotili a natáčeli videa .
abych svůj pohled z druhé strany dotáhl k dokonalosti , přijal jsem roli osobního vodiče .
spolu s kamarádkou káťou jsme se těsně před startem poslušně zařadili na konec koridoru 60 až 70 minut .
pozdravili jsme se s kamarády , kteří kolem nás procházeli do sektoru pro rychlejší běžce .
už nezbývalo moc času .
pár poskoků na rozehřátí , zapnout sporttestery , odpočítávání a start !
výkřiky jásotu , ale místo rychlého startu následovalo cupitání ke startovní čáře .
po pěti minutách docházíme k bráně , zapínám měření a rozbíháme se tempem na hodinu deset .
proplétáme se žlutým hadem běžců , kteří podobně jako káťa běží svůj první závod .
zatím vypadají všichni svěže , pomalu klesající slunce na obloze dodává výhledu na vyšehrad skoro až kýčovitý nádech .
pulzující masa táhnoucí se po nábřeží vypadá , jako by tady běžela celá praha .
na nábřeží mezi vyšehradem a národním divadlem se tradičně začíná projevovat , kdo má kolik sil .
lehký kopeček na palackého náměstí nutí mnoho běžců zpomalit nebo přejít do chůze .
těsně před přeběhem do divadelní vidím policejní doprovod a hned za ním letí vítek pavlišta neuvěřitelným tempem do cíle .
slyším obdivné ufuněné vzdychání ostatních běžců .
přesouvám se k okraji trati , povzbuzuji ho , chystá si se mnou plácnout , ale těsně před tím se mi podvrtne noha a naše ruce se těsně minou .
seběh divadelní ulicí dává šanci na krátký odpočinek a rozdýchání .
je potřeba , před námi jsou místa , na kterých mi výhledy vyrazí dech .
otočka na mánesově mostě ukazuje prahu v celé kráse zapadajícího slunce .
nedýchám a nohy mě nesou skoro samy .
za první občerstvovačkou nastává chvíle pravdy .
při přeběhu silnice káťa škobrtne o obrubník a předvádí skok plavmo .
dívám se , jestli nepotřebuje pomoc , a spouštím sérii povzbuzujících slov , aby neměla čas myslet na bolest .
zvedá se a pokračujeme kozí uličkou , je to jedno z nejužších míst trati , v této fázi závodu tu už sice není takový nával , přesto je ale potřeba dobře sledovat okolí .
ještě netuším , že pojem nejužší místo získá svůj pravý význam později .
za prašnou bránou nás freneticky povzbuzují turisti i kamarádí ostatních běžců .
snažím se tlesknout si s každým , kdo nabídne ruku , a radím to i kátě , protože deset tlesknutí s fanoušky je jako půlka energetické tyčinky .
fakt to funguje , opět zrychlujeme a byť jsme se dost výrazně propadli , teď začala stíhací jízda .
předbíháme desítky běžců , když míjím někoho obzvláště unaveného , snažím se ho povzbudit pár slovy : &quot; pojď , ještě kousek , to zvládneš ! &quot;
za poslední občerstvovačkou už nás nikdo nepředbíhá , zrychlujeme .
zatím jsme běželi na hodinu a čtvrt , přidáváme , není na co čekat .
tři kilometry do cíle budou bolet , ale je potřeba opravdu máknout .
slunce už pomalu zapadlo a končící den symbolicky pomalu ukončuje závod .
poslední výběh na most , otočka a už jen rovinka do cíle .
tempo , kterým běžíme , mě udivuje , kde se to v tom děvčeti bere ?
&quot; pojď , jdeme pod hodinu třináct , makáme ! &quot; volám .
zkoušíme to , sprintujeme a je tady cíl .
hodina třináct a šest sekund .
no , co se dá dělat .
trenér zadal limit hodinu dvacet .
takže sedm minut pod plán .
což je super výsledek .
těsně za cílem se kátě podlamují nohy , pomáhám jí k zábradlí , kde chvíli odpočívá .
je na ní vidět vyčerpání , ale také štěstí z dobře odvedeného výkonu .
po chvíli ji pomalu odvádím ven z prostoru cíle .
euforie nám nedává myslet na tlačenici v průchodech k šatnám .
tady je vidět , že kozí ulička nebyla tím nejužším místem .
tím je až tady za cílem náplavka , která je pod náporem téměř deseti tisíc běžců nacpaná k prasknutí .
pokud někdo nemá rád davy , není to místo pro něj .
i já po chvíli ztrácím hlavu a přemýšlím , jestli ty nádherné výhledy a oproti minulým letům zajímavější trasa stála za to , co se děje v cíli .
z vlastní zkušenosti vím , že pořádání závodu není žádná legrace .
pokud se k tomu přidá deset tisíc lidí , bohatý doprovodný program a uzavření celého centra prahy pro veškerou dopravu , je z toho obrovská výzva .
letošní změna trasy ukázala běžcům mnoho zajímavých míst , jenže přinesla také několik opravdu nepříjemných překvapení .
výborná atmosféra rozpumpovaná ve žlutých lázních se přenesla mezi běžce i v samotném závodu .
organizátoři kolem trati i náhodní diváci ji stupňovali na každém metru trati .
při městském běhu historickým centrem se bohužel musí počítat s překážkami , které nelze odstranit , ale cíl masového závodu v místě , které je na jedné straně ohraničeno zdí a na druhé řekou , nepovažuji za nejlepší řešení .
pokud si řeknu , že závod skončil proběhnutím cílem , hodnotím ho jako velmi povedený .
za cílem jsem měl trochu strach o zdraví zúčastněných , ale nakonec vše dobře dopadlo .
napište nám do diskuze , jestli se i vám trasa líbila a co říkáte na situaci v cíli .
vězeňští dozorci v bulharsku organizují protesty
stovky zaměstnanců vězeňské služby v celém bulharsku se účastnily celonárodního protestního shromáždění před ministerstvem spravedlnosti v hlavním městě sofii .
na pokojné demonstraci zopakovali svůj požadavek na znovuzavedení původních pracovních podmínek , které se v nedávné době změnily .
na seznamu požadavků , které mají být projednány s prozatímním ministrem spravedlnosti hristo ivanovem , jsou i vyšší platy .
dozorci měsíc symbolicky protestovali proti nové pracovní době a požadovali návrat k původním dvaceti čtyřhodinovým směnám .
přestože se odbory vězeňských dozorců a představitelé ministerstva spravedlnosti setkali , nedohodli se , informovalo bulharské státní rádio ( bnr ) .
„ jednání stále probíhají , “ řekl bnr vedoucí generálního ředitelství vězeňské služby rosen zhelyazkov .
očekává se , že k protestům zaměstnanců vězeňské služby se připojí také členové federace odborových organizací zaměstnanců na ministerstvu vnitra .
proč může mít vesmír více rozměrů a my je nevidíme
fyzikové obvykle bestsellery nepíší , ale brianu greenovi z kolumbijské univerzity se v roce 1999 podařila trefa do černého .
jeho kniha elegantní vesmír se stala pro laiky nejpřístupnější cestou , jak proniknout k houštině problémů , kterou se dnes zabývá řada teoretických fyziků - snaze sjednotit dvě skvěle fungující , ale vzájemně nekompatibilní objevy 20. století : kvantovou teorii a teorii obecné relativity .
jednou z příčin úspěchu elegantního vesmíru nepochybně je , že v případě hledání sjednocené fyzikální teorie nejde o nudný příběh .
fyzikové základní problém mezi dvěma klíčovými teoriemi ( vždyť v tuto chvíli je náš vesmír de facto rozdělený na dva světy s odlišnými zákony ) řešili a řeší tak nápaditě , že si to stojí za převyprávění i laikům .
greene si se složitým materiálem navíc poradil natolik svěže a poutavě , že mu nelze vyčítat , kolik zajímavého do své knihy nezahrnul .
navíc svou &quot; chybu &quot; z větší části napravil v dalších dvou knihách : struktura vesmíru a skrytá realita .
zřejmě ani autor by nic nenamítal proti tomu , kdyby jeho kniha zastarávala rychleji , ale faktem je , že i po 15 letech elegantní vesmír poskytuje stále téměř vše podstatné , co by informovaný laik s ambicí porozumět světu měl vědět o této důležité části teoretické fyziky .
je poměrně pravděpodobné , že v příštích letech bude v této oblasti přece jen o něco živěji ( třeba kvůli tomu , že urychlovač lhc pojede konečně na &quot; plný plyn &quot; ) , a tak je dobrá chvíle vstoupit do greenem nenásilně otevřených dveří světa moderních fyziky .
kolik rozměrů může mít náš vesmír ?
nápad , že náš vesmír má možná více než tři prostorové rozměry , jistě může znít pošetile , fantasticky , podivně či mysticky .
přesto je konkrétní a zcela přijatelný .
abychom to pochopili , odvraťme na chvíli svůj zrak od vesmíru jako celku k něčemu přízemnějšímu , konkrétně k dlouhé a tenké zahradní hadici na zalévání .
představte si , že stometrovou zahradní hadici natáhnete z jedné strany kaňonu na druhou a celou scenerii sledujete z půlkilometrové vzdálenosti ( jako na obrázku a na následující stránce ) .
z takové vzdálenosti snadno zaznamenáte dlouhou ve vodorovném směru nataženou hadici , ale pokud právě netrpíte bystrozrakostí , tloušťku hadice rozeznáte stěží .
vzhledem ke své velké vzdálenosti od hadice byste si pomysleli , že mravenec donucený žít na hadici má jen jeden rozměr , v němž se může procházet : levo-pravý rozměr podél hadice .
když se vás někdo zeptá , kde byl mravenec v daný okamžik , odpovíte mu jen jedním údajem : vzdáleností mravence od levého ( či pravého ) konce hadice .
tím vším chceme říct jen to , že z půlkilometrové vzdálenosti vypadá dlouhý kus hadice jako jednorozměrný objekt .
ve skutečném světě hadice tloušťku má .
pokud vše zvětšíme , spatříme náhle druhý rozměr - ve tvaru kružnice ovíjející hadici .
v takto zvětšeném pohledu je zřejmé , že se mravenec ve skutečnosti může pohybovat ve dvou nezávislých rozměrech : v už dobře známém levo-pravém rozměru po délce hadice , ale také v &quot; rozměru ve / proti směru pohybu hodinových ručiček &quot; , tedy kolem kruhovéhoprůřezu hadice .
začínáte chápat , že k určení polohy malého mravenečka musíte zadat dvě čísla : jak daleko je od konce hadice a kde je na kružnici ovíjející hadici .
to odráží fakt , že povrch hadice je dvojrozměrný ( pozn. experti postřehnou , že tato kapitola se soustřeďuje čistě na poruchovou teorii strun .
neporuchové aspekty probírá 12. a 13. kapitola . ) .
povrch hadice je dvojrozměrný : jedna dlouhá podélná dimenze je znázorněna přímou šipkou , dimenze ve směru obvodu , označená kruhovou šipkou , je krátká a svinutá .
mezi těmito dvěma rozměry je nicméně jasný rozdíl .
rozměr podél hadice je dlouhý a snadno viditelný .
rozměr ovíjející obvod hadice je krátký , &quot; svinutý &quot; a hůře znatelný .
abychom si existenci kruhového rozměru uvědomili , museli jsme hadici zkoumat s výrazně lepším rozlišením .
zmíněný příklad ilustruje důležitou vlastnost prostorových dimenzí .
to , že se rozdělují do dvou skupin .
mohou být buď velké , rozlehlé , a proto přímo patrné , nebo naopak malé , svinuté a mnohem hůře pozorovatelné .
samozřejmě že v uvedeném případě jsme se zrovna nepředřeli , abychom &quot; svinutou &quot; dimenzi ovíjející tloušťku hadice odhalili .
stačilo si vzít na pomoc dalekohled .
kdyby ale hadice byla tenčí - jako vlas nebo kapilára - , svinutou dimenzi bychom odhalili jen s velkým úsilím .
kaluza zaslal v roce 1919 einsteinovi svůj článek , v němž vyrukoval s ohromující myšlenkou , že by prostorová geometrie vesmíru mohla mít více než tři nám všem známé rozměry .
svoje radikální tvrzení kaluza odůvodňoval tím , že dodatečná dimenze poskytuje elegantní a přesvědčivý rámec , v němž lze einsteinovu obecnou relativitu a maxwellovu elektromagnetickou teorii vetkat do jediné , sjednocené pojmové struktury .
okamžitě se vnucuje otázka , jak jde tento kaluzův postřeh dohromady s očividnou skutečností , že vidíme právě tři rozměry prostoru .
odpověď , kterou kaluza tiše předpokládal mezi řádky a kterou jasně vyslovil a upřesnil švédský matematik oskar klein v roce 1926 , stojí a padá s tvrzením , že prostorová geometrie našeho vesmíru může mít jak velké , tak i svinuté rozměry .
to znamená , že stejně jako dimenze ve směru délky hadice má i náš vesmír velké , rozlehlé a lehce viditelné tři dimenze , jejichž existenci si každým okamžikem uvědomujeme .
ale analogicky s kruhovým obvodem zahradní hadice může mít vesmír i dodatečné dimenze , pevně svinuté do prostoru tak nepatrného , že doposud zůstaly skryty i před našimi nejdokonalejšími experimentálními aparaturami .
abychom získali jasnější představu o podstatě kaluzova pozoruhodného návrhu , zůstaňme ještě chvilku u hadice .
představte si , že na obvod hadice nakreslíme černou barvou poměrně hustou řadu kružnic .
zdálky vypadá hadice stále jako tenká jednorozměrná čára .
s dalekohledem teď díky kresbě odhalíme svinutou dimenzi ještě snáze , uvidíme totiž motiv z obrázku 2 .
zřetelně vidíme , že povrch hadice je dvojrozměrný , s jednou dimenzí velkou a téměř neomezenou a s druhou krátkou a kruhovou .
kaluza a klein přišli s myšlenkou , že náš vesmír má podobnou strukturu , ale kromě jedné malé kruhové dimenze má tři velké prostorové dimenze , dohromady tedy čtyřiprostorovédimenze .
je obtížné nakreslit objekt s příliš mnoha rozměry .
abychom své představivosti trochu pomohli , všimněme si ilustrace na obr.3 ; ukazuje dvě velké dimenze a jednu malou kruhovou dimenzi .
na obrázku zvětšujeme pohled na geometrii prostoru podobně , jako jsme zvětšovali povrch hadice .
každá následující úroveň , představuje obrovské zvětšení geometrie prostoru z úrovně předchozí .
náš vesmír může mít dodatečné dimenze ( vidíme je na čtvrté úrovni zvětšení ) , pokud jsou svinuty do dostatečně malého prostoru ; tím si vysvětlujeme , že jsme je dosud přímo nepozorovali .
čtvercová síť znázorňuje běžně známé &quot; velké &quot; dimenze , zatímco kružnice novou , malinkou a svinutou dimenzi .
právě jako smyčky nití v hustě utkaném koberci , i tyto kružnice existují v každém místě obvyklých rozměrů - jen jsme je kvůli názornosti zakreslili pouze do průsečíků ve čtvercové síti .
pozadí obrázku 4 znázorňuje běžně známou strukturu prostoru - obyčejný svět kolem nás - v takových běžných měřítkách , jako jsou metry , znázorněných stranou malého čtverečku ve čtvercové síti .
na každém následujícím obrázku se zaměříme na malou oblast obrázku předcházejícího ; zvětšíme ji , aby se stala viditelnou .
zpočátku se nic zvláštního neděje , jak vidíme na několika prvních úrovních zvětšení .
když však postoupíme na své cestě za mikroskopickými vlastnostmi geometrie prostoru dále - na čtvrtou úroveň zvětšení v obrázku 3 - , spatříme náhle novou , do tvaru kružnice svinutou dimenzi , podobnou smyčkám niti v hustě tkaném kusu koberce .
kaluza a klein přišli s myšlenkou , že dodatečný kruhový rozměr existuje na každém místě ve směru velkých dimenzí podobně , jako má i hadice kruhový obvod v každém bodě své délky .
v zájmu názornosti jsme kruhový rozměr zakreslili jen v některých , pravidelně rozmístěných bodech .
obrázek 4 kaluzovu a kleinovu představu o mikroskopické struktuře geometrie prostoru shrnuje .
podobnost s hadicí je zřejmá , třebaže zaznamenáváme i důležité rozdíly .
zaprvé , vesmír má tři velké , daleko se rozléhající prostorové rozměry ( z nichž jsme nakreslili jen dva ) , kdežto hadice má velký rozměr jen jeden .
ještě důležitější rozdíl tkví v tom , že teď mluvíme o prostorové geometrii vesmíru samotného , nikoli jen o nějakém předmětu uvnitř vesmíru , třeba naší hadici .
základní myšlenka je ale stejná .
pokud je dodatečná kruhově svinutá dimenze extrémně miniaturní , rozpoznat ji je - stejně jako kruhový obvod hadice - mnohem těžší než pozorovat zjevné , velké a rozlehlé rozměry .
je-li velikost dodatečné dimenze dostatečně malá , odhalit ji bude ve skutečnosti i nad síly našich nejmodernějších nástrojů na zvětšování .
nejdůležitější ale je , že dodatečná dimenze není pouhým oblým hrbolkem uvnitř běžných rozměrů , jak dvojrozměrná ilustrace mylně naznačuje .
kruhová dimenze je novým rozměrem , který existuje v každém bodě tří běžných rozlehlých rozměrů .
je to rozměr na zbylých třech dimenzích nezávislý stejně , jako jsou rozměry shora-dolů , zleva-vpravo a zepředu-dozadu nezávislé ( a kolmé ) navzájem .
dostatečně malý mraveneček by se mohl pohybovat ve všech čtyřech dimenzích a na určení jeho pozice bychom potřebovali čtyři údaje , kromě tří obvyklých ještě pozici v kruhové dimenzi ; počítáme-li i čas , pak údajů pět , v každém případě o jeden více , než bychom normálně očekávali .
zaujalo vás ?
knihu elegantní vesmír briana greeena můžete zakoupit zde na knihy.idnes.cz.
cena za e-knihu je 149 , - kč .
k našemu překvapení tedy zjišťujeme , že byť jsme si vědomi existence jen tří rozměrů prostoru , ukazuje kaluzovo a kleinovo uvažování , že tím není vyloučena existence dodatečných svinutých rozměrů , jsou-li dostatečně malé .
vesmír může mít klidně více rozměrů , než kolik jich můžeme spatřit pouhým okem .
jak malé by měly být ?
nejmodernější technické vybavení dokáže rozpoznat struktury velké miliardtinu miliardtiny metru .
menší svinuté dimenze sotva můžeme pozorovat .
v roce 1926 zkombinoval klein původní kaluzův nápad s několika myšlenkami z právě se rodící kvantové mechaniky .
jeho výpočty naznačily , že dodatečná kruhová dimenze by mohla mít velikost přibližně jedné planckovy délky , tedy velikosti daleko za rozlišovací schopností dnešních přístrojů .
od té doby fyzici nazývají možnost dodatečných drobných prostorových rozměrů kaluzovou-kleinovou teorií .
wohnout honza homola radí , jak cvičit na elektrickou kytaru : 5. díl
celá podstata &quot; dvanáctky &quot; spočívá v dvanáctitaktové harmonické formě , kterou můžete libovolně opakovat .
kdo tápe v hudební teorii , najde její princip podrobně vysvětlený zde .
jan homola neboli honza homolka tobolka ( 1976 )
vzděláním loutkař a loutkovodič , jehož facebookový profil lze sledovat zde , se od maturity před dvaceti lety živí jako grafik .
je kytaristou kapely wohnout , ze které se údajně bohužel nedá odejít .
kytaristou je po otci , stejně jako bratr matěj , lídr wohnoutů .
s trénováním začněte na jedné struně .
&quot; rytmický model je na jen vás , vymyslet si můžete cokoliv , stačí ho pak aplikovat na harmonický model dvanáctky , &quot; radí honza .
když přidáte další strunu , můžete figuru zase obměnit .
stačí si poslechnout a sledovat honzu , co se dá s dvanáctkovou harmonií na dvou strunách vymýšlet a jak pěkně už to začíná znít .
přiberete-li třetí strunu , už můžete koketovat s melodií nějaké písničky .
až konečně přidáte čtvrtou , pozor na změnu ladění , upozorňuje honza ve videu .
příště se honza vrátí k pentatonice a zkusíte si ji dát dohromady právě s dvanáctkou .
tak ji poctivě cvičte .
jak nejlépe , to se dočtete v rozhovoru s janem homolou u první lekce jeho školy hry na elektrickou kytaru zde .
další gól bez čekání ?
na velké slavení to není , uznává hradecký dvořák
bod bereme a jsme za něj rádi .
první poločas jsme měli víc šancí my , druhý domácí , &quot; vypravoval útočník , jenž tentokrát skóroval z pokutového kopu .
nebyl jste při jeho zahrávání nervózní , přece jen jej doprovázel ohromný pískot ?
nějak zvlášť jsem to nevnímal , i když na druhou branku , kde jsou domácí fanoušci , by to asi bylo horší .
penaltou jste po půlhodině vyrovnal , ale vy jste gól také z penalty dostali už po necelých čtyřech minutách .
co se stalo ?
zaspali jsme začátek , byli jsme pasivní , vznikl z toho roh a po něm pak penalta .
po ní jste se zvedli a první poločas jste byli lepším týmem , který měl víc šancí .
proč se to po přestávce změnilo ?
těžko říct .
souhlasím s tím , že jsme po inkasovaném gólu hráli až do přestávky dobře .
v kabině jsme si říkali , že chceme i po ní udržet tempo hry , ale nedokázali jsme to .
abych pravdu řekl , ani si nedokážu vysvětlit proč .
je ale asi také pravda , že si domácí o přestávce něco ke své hře řekli , asi s ní nebyli moc spokojení .
na hřišti soupeře jste teprve poprvé bodovali , zatímco doma jste třeba ještě nedostali ani gól .
proč je to takový rozdíl ?
neřekl bych , že je to takový rozdíl , spíš záleží na nás , jak se s tím popereme .
v brně jsme dobře začali , ale pak to bylo od nás špatné , plzeň , to je jiná kategorie .
čtyři zápasy jste čekali na gól , neměli jste strach , že to po minulém utkání může být podobné ?
to snad ani ne , ale pochopitelně jsme rádi , že od minulého zápasu nemusíme řeči o čekání na gól poslouchat .
teď jsme bez čekání přidali další , ale stále jsou jen tři v šesti zápasech , což ještě na velké slavení není .
island - láva přitéká z kilometry vzdáleného kráteru .
láva vyletující na povrch v oblasti holuhraun nedaleko ledovce vatnajökull , přitéká podzemním tunelem z kilometry vzdáleného kráteru .
ten se nachází pod ledovcem , stejně tak část zmiňovaného podzemního lávového tunelu .
tato skutečnost nyní vědce znepokojuje nejvíc ...
situace prozatím zůstává neměnná .
od včerejšího rána ( 31.8 .
2014 ) stále vyletuje z pukliny přibližně stejné množství lávy .
oproti původním odhadům je však její množství nižší , ne 1000 m3 , ale &quot; pouze &quot; 300-400 m3 .
oproti předchozí erupci z 29.8 .
2014 je až 50x větší .
vědci se však obávají , že by se lávový tunel mohl otevřít i v místech , kde se nachází pod ledem .
pokud by se tak stalo , navíc s podobnou intenzitou , jakou předvádí současná erupce , znamenalo by to obrovské záplavy , a to jak na řece jökulsá á fjöllum , tak na dalších řekách .
v okolí erupce je cítit silný zápach síry , z trhliny stoupají oblaka páry a plynů .
rozhodně se nejedná o erupci vhodnou pro turistický ruch , jako tomu bylo v případě erupce u fimmvörðuháls v roce 2010 .
tohle je mnohem větší a také je tu mnohem víc plynů , &quot; říká vulkanolog ármann höskuldsson .
počasí se však od včerejška značně zlepšilo , v ranních hodinách panovalo v oblasti téměř bezvětří .
stopy po písečné bouři byly smyty deštěm .
vědci mohou pokračovat ve své práci .
pro letecký provoz platí oranžový stupeň ( druhý nejvyšší ) pro bárðarbungu a žlutý ( třetí ) pro askju .
nebe nad chebem patřilo odvážné lady peggy .
prošla se po křídlech
letecký den v chebu .
na stroji boeing stearman pt-17 se představila letecká akrobatka peggy walentinová , která za letu vylezla z kokpitu ke hrazdě na horním křídle dvouplošníku a také mezi křídla .
tam je odkázána pouze na sílu svalů .
letecký den v chebu se letos konal už popáté a pořadatelům se opět podařilo připravit několik zajímavých leteckých kousků .
premiéru si na nejstarším českém letišti odbyla nejen &quot; chůze po křídlech &quot; v podání německé akrobatky peggy walentinové , ale také legendární stíhačka p-51 d mustang nebo letoun beechcraft 18 .
ten na sebe strhl pozornost svým zářivým potahem .
akrobacie zvaná wingwalking má původ v usa .
po 1. světové válce se tak snažilo prosadit mnoho bývalých válečných pilotů .
jenže kvůli velkému počtu smrtelných úrazů byl zakázán .
dnes se ale pomalu vrací do programu leteckých dnů .
peggy po startu vyleze z kokpitu na horní křídlo .
tam předvádí různé cviky .
ke konci vystoupení se přesune do prostoru mezi křídly letounu , kde její show pokračuje , &quot; popsal luděk matějíček z chebského ultralight clubu a organizátor leteckého dne .
pilotem letounu boeing stearman 75 e je její manžel friedrich .
jestliže vystoupení peggy bylo hlavním hřebem programu , pak následující představení stíhačky mustang bylo pověstnou třešničkou na dortu .
legendární stíhačka se na plochu přihnala s grippeny armády české republiky v závěsu ( takzvaně na číslech ) .
takovou sestavu mohli letečtí fanoušci v česku vidět poprvé .
pilot miroslav sázavský pak všem předvedl dech beroucí akrobacii s letounem z roku 1945 .
vyrobený byl ještě za války , ale pravděpodobně se jí nikdy nezúčastnil .
byl zařazený v armádních rezervách .
od roku 1963 působil v civilní sféře .
i jako závodní letoun .
dnes má svůj domovský hangár na letišti v mnichově hradišti .
na stejném místě je také další perla chebského leteckého dne , dvoumotorový beechcraft c45h expeditor .
na letišti nešel mohutný stroj přehlédnout .
jeho vyleštěný hliníkový potah zářil do dálky .
obdiv si získal i stroj max holste mh 1521m broussard v barvách francouzského letectva .
malé dopravní letadlo zaskočilo za odřeknutý turbolet a z německého hofu přivezlo část německé delegace na letecký den .
němečtí sousedé se v chebu předvedli s rekonstruovanými letadly jak 18t nebo tříčlennou formací dvouplošníků bücker jungmann .
lucie borhyová : dramatický návrat před kameru !
rodičovské starosti vyměnila lucie borhyová alespoň pro dnešní večer za ty pracovní .
stres nebo nervozita - blonďatá moderátorka nic z toho evidentně nezná .
moderovaní televizních zpráv jí totiž šlo dobře , jako by s ním na dva měsíce vůbec nepřestala !
je to teprve přitom dva týdny , co blondýnce skončilo šestinedělí , při kterém zažívají ženy po porodu ten největší stres .
lucie se však v hlavní zpravodajské relaci tv nova ještě pravidelně ukazovat nebude .
regulérní návrat ji čeká podle informací blesk.cz až za měsíc .
přece jenom ji její dcera linda nyní potřebuje víc než televizní diváci .
lucie borhyová se vrátila na televizní obrazovku a byla to trefa do černého .
exhibice za rok v praze ?
hala by se vyprodala , plánuje rozlučku jágr
bylo by důstojné , kdyby se něco takového udělalo během mistrovství světa .
ale záleží , jak se k tomu postaví svaz , &quot; říkal v jihlavě po exhibici s názvem zlaté utkání , ve kterém se znovu sešel úchvatný naganský tým .
i hráči , kteří se podíleli na zlatém hattricku .
hráči by chuť měli , že ?
určitě .
bylo by zkrátka dobré udělat rozloučení se zlatou generací během mistrovství .
podle mě se dají během turnaje najít jeden dva dny , kdy je úplné volno a kam by se dalo takové utkání vmísit .
řekneme to gumovi ( jiřímu šlégrovi ) nebo béďovi ščerbanovi ( pořadatel jihlavského zápasu ) , kteří by si to vzali na starost ...
aréna by se vyprodala .
jenže co když budete hrát s new jersey play-off ?
tak když tak přiletím ...
hrát v reprezentaci ale nechcete .
nebo jihlavské setkání nějak pozměnilo vaše rozhodnutí ?
reprezentace a exhibiční utkání jsou dvě rozdílné věci a v reprezentaci jsou rozhodující výkony .
jedna věc je , že by mě tam lidi rádi viděli , ale výkony jsou rozhodující , zvlášť na mistrovství světa .
tam by měli jezdit hráči , kteří na to mají , a ne kvůli tomu , že mají dobré jméno .
mé rozhodnutí se nijak nezměnilo .
jak jste si vlastně užil to naganské shledání ?
už jen to setkání s hráči bylo skvělé .
člověk si oživil historky a zažil spoustu legrace .
byl to skvělý zážitek nejen pro fanoušky , ale i pro nás hokejisty .
ovšem nejdůležitější byla pocta ivanu hlinkovi .
a je dobré připomínat historii našeho hokeje a to , že odchází jedna generace , která za to opravdu stála .
slavomír lener , vladimír růžička a petr čechmánek na střídačce .
sám si ještě vybavíte svůj první reprezentační zápas ?
na takové věci se nezapomíná .
bylo to proti calgary flames a tři mladí : já , robert holík a robert reichel , jsme nastoupili v jedné trojce .
pro všechny to byl první reprezentační start .
no ale že bychom nějakým způsobem dominovali , tak to se nedá říct .
v jihlavě po dlouhé době chytal dominik hašek .
co jste říkal na jeho výkon ?
mě hašan na ledě nikdy nepřekvapí .
chtěl jsem mu to vrátit s tou kritikou , ale nemůžu ( hašek kritizoval jágra za důvody , proč se rozhodl skončit v reprezentaci ) .zachytal prostě výborně .
i hnilička se skvěle předvedl .
přitom si byl se mnou jednou v noci zatrénovat a tam byl děravej .
a teďka chytal famózně .
nejdřív usa a pak už nizozemsko , fotbalistům začíná kvalifikace
ke smíchovskému nh hotelu se v pondělí dopoledne sjížděli prominentní hosté .
lidé mohli zahlédnout třeba brankáře petra čecha z chelsea , reprezentačního trenéra pavla vrbu ...
a tamhle , ta postava v černé kšiltovce , to je tomáš rosický !
záložník arsenalu a kapitán reprezentace dorazil na sraz kolem půl dvanácté mezi posledními .
čeká nás krásný zápas proti nizozemsku .
kdo by se netěšil ? &quot; řekl , když už v reprezentační soupravě předstoupil před novináře .
program české reprezentace
pondělí 1. září : začátek srazu , první trénink
úterý 2. září : trénink otevřený pro fanoušky ( 18 : 30 , letná ) autogramiáda ( 20 : 00 )
středa 3. září česko - usa ( 20 : 15 , letná )
úterý 9. září česko - nizozemsko ( 20 : 45 , letná ) konec srazu
rosického a spol. můžou fanoušci podpořit ještě před středečním zápasem proti usa ( 20 : 15 ) .
reprezentace pro ně totiž otevřela úterní trénink , který na letné začíná v 18 : 30 .
a po něm bude následovat autogramiáda , na které rosický ani čech nebudou chybět .
jinak ovšem bude tento sraz národního týmu klidnější .
což si pochvaluje trenér vrba , jenž si právě na množství společenských akcí na jaře stěžoval .
konečně se budeme věnovat tomu , čemu se věnovat chceme .
teď se budeme soustředit na nizozemsko .
je výhoda , když máte hráče pohromadě osm dnů .
budeme mít čas nacvičovat věci , na které doteď tolik času nebylo , &quot; pochvaloval si vrba , jenž národní tým oficiálně vede od ledna .
českou fotbalovou reprezentaci bude při vstupu do nového kvalifikačního cyklu provázet mušketýrská image .
reprezentace má pod vrbou za sebou tři zápasy , všechny přípravné .
s norskem a finskem remizovala 2 : 2 a s rakouskem prohrála 1 : 2 .
tyto výsledky však ještě důležité nebyly .
to až teď .
zápasem s nizozemskem totiž odstartuje kvalifikace o postup na mistrovství evropy 2016 .
českému mužstvu by samozřejmě pomohlo , kdyby zvládlo i generálku proti usa .
první půlrok byl , abychom se poznali .
teď už jsou důležité výsledky .
musíme myslet na to , abychom byli úspěšní , &quot; souhlasil vrba .
jediným hráčem třiadvacetičlenné nominace , který má zdravotní problémy , je útočník david lafata .
trápí ho teplota .
pokud by se nestihl uzdravit do středečního utkání proti usa , trenér vrba by povolal ještě jednoho útočníka .
genetické poruchy jsou často špatně diagnostikovány
žena z británie popisuje , jak si po špatné diagnóze mnoho let myslela , že zemře .
poté , co byla diagnostikována s jinou chorobou , strávila karin rodgersová většinu dospívání v domnění , že jí zbývá jenom několik let života .
ve skutečnosti se jednalo o charcot-marie-tooth syndrom ( cmt ) - skupinu dědičných poruch , které poškozují nervy mimo mozek a páteř .
charitativní organizace cmt uk uvedla , že špatná diagnóza je mezi lidmi s cmt běžný problém , protože o nemoci se ví jen velmi málo .
má se za to , že ve spojeném království trpí cmt přibližně 23 000 lidí , což se může projevovat symptomy v oblasti motoriky jako je svalová slabost , nemotorná chůze a zkroucené prsty na nohou .
u postižených se může vyskytnout také necitlivost nebo bolest , tento stav je neléčitelný a progresivní , což znamená , že postupem času se symptomy zhoršují .
když bylo rodgersové třináct , myslela si , že trpí freidreichovou ataxií ( fa ) - onemocněním , které má velmi špatnou prognózu .
věřila , že než oslaví osmnácté narozeniny , bude upoutaná na kolečkové křeslo , a mrtvá , než jí bude třicet .
matka dvou dětí , které je nyní 51 , říká : „ jako dítě jsem věděla , že nemůžu dělat stejné věci jako ostatní .
každý den jsem upadla a všechno mi trvalo déle .
nikdy jsem nemohla s ostatními dětmi jezdit na kolečkových bruslích nebo na skateboardu a ve škole mě šikanovali kvůli tomu , jak jsem chodila a běhala . “
když bylo rodgersové třináct a byla po několika operacích , které měly uvolnit její achillovy šlachy a narovnat chodidla , využila toho , že její lékař odešel z místnosti , a nahlédla do své dokumentace , kde se dozvěděla , že trpí fa .
„ cítila jsem se provinile , protože jsem slídila , a tak jsem to nikomu neřekla , ale když jsem se vrátila domů , vyhledala jsem si informace o nemoci v knihovně a napsala jsem do asociace fa , “ říká .
když mi odpověděli , byla jsem v šoku , naprosto jsem zpanikařila .
myslela jsem , že než mi bude osmnáct , skončím na vozíku , a než mi bude pětadvacet , budu mrtvá , a mezitím postupně ztratím veškeré svoje schopnosti .
byla jsem na to úplně sama a plánovala jsem si pohřeb . “
když jí bylo sedmnáct , uvědomila si , že její schopnost chůze se nezhoršila tolik , kolik předpokládala , a zeptala se na to svého chirurga .
jenom se postavil , objal ji a řekl : „ zlatíčko , nemyslím si , že tu nemoc máš , jinak bys už byla na vozíku .
myslím , že to bude něco mnohem méně životu nebezpečného . “
po absolvování několika genetických testů se zjistilo , že má cmt .
„ když mi vysvětlil , co cmt je , myslela jsem , že jsem dítě štěstěny , “ prohlásila .
charitativní organizace cmt uk zahájila měsíc informovanosti o cmt , aby na tuto nemoc upozornila .
podnikatelé v oblasti washingtonu : s obratem ekonomiky se zvedají daně
rostoucí ekonomika znamená více zákazníků , vyšší prodeje a nová pracovní místa .
a taky vyšší daně .
podle nového průzkumu , který byl zveřejněn minulý týden , státní a místní zdanění firem v zemi s urychlováním ozdravení ekonomiky minulý rok mírně vzrostlo a firmy ve washingtonu nebyly výjimkou .
podnikatelé v marylandu a virginii dohromady za fiskální rok 2013 do státních a lokálních pokladen odvedli 27,6 miliard dolarů , což je o 3,8 % vyšší částka než 26,6 miliard dolarů vybraných v roce 2012 .
daňové zatížení - státní i místní - se minulý rok zvedlo o 4,3 % na 671 miliard dolarů v porovnání s 3,9 % minulý rok a jednalo se o třetí růstový rok za sebou po letech 2009 a 2010 , kdy se daně snižovaly .
podle studie , kterou provedla profesionální firma ernst &amp; young a politické uskupení center on state taxation , se státní daně zvyšovaly rychleji , o 4,3 % , než místní odvody , o 3,9 % .
více než polovina daňových příjmů okrsku , 56 % , je z živnostenské daně , a 36 % příjmů marylandu je od společností .
virginia , s 28 % , vykazuje úměrně nejmenší daňové příjmy z podnikání .
výzkumníci tvrdí , že většinový podíl růstu daňových příjmů pochází ze zvýšení hodnoty nemovitostí patřících firmám , což daně z nemovitosti tento rok po třech po sobě jdoucích letech s růstem -1 % zvýšilo o 3,7 % .
přestože většina zisku pochází z velkých států jako kalifornie , new york a texas , zdá se , že stejná situace je i ve washingtonu .
společnosti v d.c. , marylandu a vriginii minulý rok zaplatily přes deset miliard dolarů na státních i místních daních z nemovitosti , což v porovnání s 9,6 miliardami v roce 2012 představuje roční nárůst o 4,2 % .
zjevné zvýšení hodnoty nemovitostí však tolik nevyhání nahoru státní a místní daňové příjmy v marylandu , kde daň z nemovitosti představuje necelou pětinu zdanění společností .
pro firmy ve virginii a d.c. představuje daň z nemovitosti téměř polovinu státního a místního zdanění .
„ v marylandu vlastní hodně nemovitostí firem , především základ daně v okolí d.c. , vláda nebo nevýdělečné organizace , které neplatí daně , “ vysvětlil douglas lindholm , výkonný ředitel center on state taxation .
takže maryland je nucený se mnohem více spoléhat například na daně z příjmů , aby zaplatil za stejné služby , které jsou v jiných státech .
nedávné zvýšení daňových příjmů z podnikání nemůže být připsáno pouze uzdravujícímu se trhu s nemovitostmi .
podle údajů se zdá , že příjmy z podnikání se také zvyšují .
firmy v tomto regionu zveřejnily daň z příjmu obchodních společností 2,3 miliardy dolarů , které se zvýšily z 2,1 miliardy z roku 2012 .
maryland na daních z příjmů obchodních společností vybral jednu miliardu dolarů , nejvíce v regionu .
přestože se ubírají stejným směrem , místní daňové zatížení podnikatelů neroste v těchto třech místech stejně rychle .
míra růstu v d.c. byla na úrovni celostátního průměru , na 4,3 % , zatímco růst marylandu byl výrazně vyšší , 4,9 % .
pouze ve virginii bylo zvýšení zdanění pod průměrem , na 4,1 % .
virginia má ze všech tří obvodů ( z nichž všechny mají stejné zdanění ) nejnižší zdanění příjmů obchodních společností , 6 % .
míra zdanění obchodních společností v marylandu je 8,25 % , zatímco průměr d.c. zůstává relativně vysoko , na 9,975 % .
podobná studie , kterou tento rok provedla americká obchodní komora , ukázala , že virginia má nižší státní a místní zdanění a celkově příznivější daňové klima než maryland .
d.c. studie nehodnotila .
i přes tuto výhodu čelí virginia tlaku konkurence z jihu .
severní karolína nedávno podepsala zákon snižující daň obchodních společností z 6,9 % na 6 % , stejně jako virginia , a příští rok se daň sníží na 5 % .
pokud bude stát v nadcházejícím roce nadále splňovat příjmové cíle , mohla by se v roce 2017 zákonem stanovená míra zdanění příjmů snížit až na 3 % .
podle nedávné studie se drobným podnikatelům ve washingtonu vede lépe , a proto platí vyšší státní a místní daně .
živnostenská daň odváděná drobnými podnikateli jako daň z osobních příjmů - struktura kompenzace zvyšování nákladů zvyšováním cen , podle které je organizována většina firem - v d.c. , marylandu a virginii vzrostla minulý rok o 20 % na 2,4 miliardy dolarů , mnohem rychleji než jiné daně .
výzkumníci tvrdí , že trend a celostátní zvyšování živnostenské daně budou pravděpodobně příští rok pokračovat , celkové daňové příjmy z prodeje pro státní i místní vlády se v porovnání za stejné období v minulém roce prvních třech čtvrtletí roku 2014 zvýší na 6,2 % .
washington však může za ostatními zaostávat , protože snižování státních výdajů si vybírá svou daň na pracovním trhu .
co vám uniklo : šéfem evropy bude tusk , putinovo novorusko i lafatovy nůžky
vznikne na ukrajině nový stát ?
putin vyzval k jednání o novorusku
ruský prezident vladimír putin se zmínil o možnosti vytvoření nového státu na jihovýchodě ukrajiny , kde se od dubna střetávají vládní jednotky s proruskými povstalci .
varoval rovněž evropské firmy , že po nynějším režimu protiruských sankcí budou mít obtížný návrat na ruský trh .
podpora , kterou západu poskytuje válčení ukrajinské armády na východě ukrajiny , podle něj odporuje demokratickým hodnotám .
ukončení konfliktu podle něj závisí na kyjevu , a tak nedokáže říci , kdy ukrajinská krize skončí .
další sankce pro rusko ?
česko si vymohlo právo s částí nesouhlasit
evropská komise má spolu s diplomaty do týdne navrhnout podobu dalšího přitvrzení protiruských sankcí , rozhodl v noci na dnešek summit eu .
novinářům to řekl stálý předseda schůzek členských zemí herman van rompuy .
podle českého premiéra bohuslava sobotky mají být konkrétní návrhy na posun podoby sankcí připraveny už v pondělí .
tusk bude novým unijním &quot; prezidentem &quot; .
van rompuye nahradí v prosinci
polský premiér donald tusk byl na summitu evropské unie zvolen do čela evropské rady , tedy takzvaným unijním prezidentem , který řídí vrcholné schůzky členských zemí .
od prosince na dva a půl roku nahradí hermana van rompuye .
v čele evropské diplomacie vystřídá catherine ashtonovou italská ministryně zahraničí federica mogheriniová .
italku , která se tak stane místopředsedkyní budoucí evropské komise , ještě musí ve funkci potvrdit evropský parlament .
asistovaná smrt je v česku realita , jen se o ní nemluví
pomoci nevyléčitelnému a dlouhodobě trpícímu pacientovi s odchodem ze života ?
v českých podmínkách , kde zákony nepovolují eutanazii , to legálně nejde .
přesto z vyjádření lékařů , které ln oslovily , vyplývá , že o takových žádostech slýchávají .
als : nejtěžší kapitola neurologie , říká lékař o skleróze
česku trpí amyotrofickou laterální sklerózou ( als ) přibližně tři stovky lidí , 21 pacientů podstupuje v pražském motole experimentální léčbu kmenovými buňkami .
my stoprocentně nevíme , zda bude úspěšná .
ale když to nezkusíme , tak to nezjistíme , &quot; říká radim mazanec , motolský neurolog .
je v tom znát rukopis cia , potřebovali válku , píše huml o sestřelení letu mh17
poslanec za čssd stanislav huml má jasno v tom , kdo sestřelil malajsijské letadlo nad ukrajinou .
podle něj je zřejmé , že &quot; tvrdé sankce , které byly vyhlášeny s ohledem na sestřelení civilního letadla s téměř 300 mrtvými , způsobila úmyslně ukrajinská armáda &quot; .
podle zákonodárce je z toho navíc znát rukopis cia .
nesplnitelné sliby .
blíží se volby a strany opět nabízejí i nemožné
konec bezdomovců na ulicích , parkování pro každou rodinu i lanovka nad prahou .
před každými volbami se to opakuje : strany slibují nemožné .
také nyní se s blížícími komunálními volbami politici předhánějí , kdo se voličům víc zalíbí .
server lidovky.cz vybral nesplnitelné sliby ze současnosti i minulosti .
před 70 lety se čechoslováci vylodili u dunkerque .
začalo urputné obléhání
bylo to 30. srpna 1944 , kdy se československá samostatná brigáda přesunula do francie .
její velitel alois liška soustavně žádal o doplnění technického vybavení a odeslání na frontu .
britská strana nakonec vyhověla a tuto pozemní jednotku zařadila jako jednu ze svých sil při obléhání přístavního města dunkerque , které zůstávalo v moci německých vojsk .
souhrn : plzeň vede ligu před pražskými &quot; s &quot; , liberec deklasoval baník
viktoria plzeň je novým lídrem fotbalové ligy , kterou vede o bod před oběma pražskými &quot; s &quot; .
změny v čele tabulky způsobila porážka slavie 1 : 2 v mladé boleslavi .
po dvou porážkách se v domácí lize vzpamatovala sparta , díky dvěma lafatovým zásahům porazila jablonec .
rekordní výhru v ročníku si připsal liberec , který rozstřílel baník ostrava 6 : 0 .
62 tisíc diváků na volejbale ?
poláci říkají ano
úvod ms volejbalistů ve varšavě přinesl divácký rekord .
na fotbalovém stadionu pod zataženou střechou sledovalo hladkou výhru domácích nad srbskem 62 tisíc diváků .
vstupenky byly přitom vyprodány za 100 minut .
jak přežít návrat z dovolené ?
nikam nespěchejte a dopřejte si spánek
poslední dny prázdnin jsou před námi .
zvyknout si po návratu ze slunečné pláže nebo chalupy na běžné pracovní tempo může být pro mnohé oříšek .
může jej dokonce doprovázet i deprese .
naštěstí existují osvědčené tipy , jak se se změněnou situací vyrovnat : nespěchat a dopřát si kvalitní spánek .
rodina joan riversové : „ držíme palce “
joan riversová je v bezvědomí tři dny , od chvíle , kdy ji přivezli do nemocnice v new york city , ale její dcera se dnes vyjádřila , že neztrácí naději , že se jednaosmdesátiletá komička uzdraví .
„ děkujeme za vaše pozdravy a podporu , “ uvedla melissa riversová v dnešním prohlášení .
držíme jí palce .
její matku přivezli do mount sinai hospital ve čtvrtek po telefonátu na záchrannou službu , podle kterého u ní došlo k srdeční zástavě na yorkwillské endoskopii v upper east side , jak uvedl zdroj .
lékaři ji záměrně udržují pod vlivem sedativ a pod přísným dohledem , dokud si nebudou jisti jejím stavem , který zůstává „ vážný “ .
reakce na sebe nenechaly dlouho čekat a to včetně neskutečné podpory na internetu od osobností jako donald trump , montel williams a kelly ripa .
realita je překrucovaná titulky
že média svými titulky překrucují realitu , není ( bohužel ) žádná novinka .
vím , že titulky &quot; prodávají &quot; noviny , ale bohužel také vím , že jsou mnozí takzvaní &quot; čtenáři &quot; , kteří nic jiného nečtou .
a to je fakt , který mě poslední dobou velmi trápí , výstižnější je spíš slovo štve .
týká se to zejména článků o konfliktu izraele a hamásu v pásmu gazy .
zcela běžné jsou titulky &quot; izrael zaútočil na gazu &quot; .
teprve v textu se dočtete , že izraelský &quot; útok &quot; byl reakcí na vypálené rakety z pásma gazy , a to mnohdy v době vyhlášeného příměří .
to se pak objeví titulek &quot; obě strany porušily příměří &quot; .
uvědomuje si novinářská obec , že tímto svým postupem se přímo podílí na antisemitských postojích , které po celé evropě ( a nejen tam ) narůstají ?
neuplynulo ani šedesát let od konce 2. světové války .
dosud žijí lidé , kteří přežili šoa .
když jsem viděla videa ze spolkové republiky německo , kde dav vykřikoval hesla &quot; židovské svině &quot; a podobné zhůvěřilosti , zatrnulo mi .
to chce svět dokončit to , co se nepovedlo hitlerovi ?
uvědomují si naši novináři fakt , že po židech byli určeni k likvidaci slované ?
dámy a pánové novináři , věnujte prosím trochu více péče své práci .
často jste označováni za &quot; hlídací psy demokracie &quot; .
tak ji obhajujte .
dokud tu je .
a obhajujte také právo jediného opravdu demokratického státu na blízkém východě na ochranu svého obyvatelstva .
jak byste chtěli , aby se zachovala naše vláda , kdyby se některý z našich sousedů rozhodl , že český národ zlikviduje a českou republiku vymaže z mapy světa ?
možná byste si také měli uvědomit ještě jeden fakt .
na území státu izrael bydlí téměř 20 % arabů s izraelským občanstvím .
a je jim tam dobře .
když se jich zeptáte , proč nejdou mezi &quot; své &quot; , třeba do gazy , odpovědí vám , proč by to dělali ?
v izraeli mají práci , sociální jistoty a špičkovou zdravotní péči ( sama jsem na vlastní oči viděla , jak do špičkové soukromé nemocnice hadassa , která je financována ze sponzorských darů židů z celého světa , běžně chodí i arabové a jsou tam pochopitelně ošetřeni ) .
hamás svými střelami útočí i na své arabské bratry .
jediná opravdová pomoc gaze , a tím i této neklidné oblasti , je zbavit ji hamásu a odzbrojit ho .
a ne odsuzovat izrael , byť nepřímo v titulcích .
informujte o praktikách hamásu , o jeho zneužívání lidí jako lidských štítů .
informujte o tom , že hamás má za cíl zlikvidovat stát izrael , a to za jakoukoliv cenu .
i za cenu smrti nevinných arabských dětí .
informujte o tom , že hamás je na seznamu světových teroristických organizací .
informujte o tom , že za devět let samosprávy v gaze mohla být tato oblast vzkvétající díky humanitární pomoci z celého světa .
dokonce i z izraele , který tam dodává vodu a elektřinu , za kterou ovšem správci gazy neplatí a dokonce se rozčilují , že jsou v této době občas dodávky proudu přerušeny .
kdyby hamás neinvestoval peníze do výstavby podzemních tunelů , aby jimi mohli pronikat sebevražední útočníci na území izraele , ale třeba do výstavby bytových domů , nemocnic a škol , žilo by se jeho arabským bratrům z gazy podstatně lépe .
amazon kupuje za 1,04 miliard dolarů twitch
amazon právě potvrdil tvrzení information z pondělního rána : internetový maloobchodník - producent videí a stovky dalších věcí - kupuje za 1,04 miliardy dolarů ( 970 milionů amerických dolarů ) video streamingovou službu twitch .
oznámení vyvolalo překvapení nikoliv proto , že by nikdo neočekával , že twitch někdo koupí , ale protože se očekávalo , že kupcem bude youtube .
před třemi měsíci vypadal prodej twitche googlu za jednu miliardu jistý , a toto spojení vypadalo jako přirozené .
twitch , který teprve před třemi lety založila justin.tv , měl našlápnuto k tomu , aby se stal všeobecně používanou video streamingovou službou - živá verze youtube .
místo toho se z něj rychle stala platforma pro hráče , kteří na ni vysílali online přenosy z her - slovy business insider „ youtube pro živě přenášené hraní “ .
interaface twitche .
na youtube jsou již populární videa „ let &apos; s play “ , druh , kde mudrlanti ( většinou starší ) dávají hrám zpracování mystery science theater .
faktem je , že youtube při popisutwitche přichází na přetřes hodně , takže zprávy , že youtube kupujetwitch , nikoho moc nevzrušily , byl to učebnicový příklad toho , jak zavedená společnost vyplatí možnou konkurenci .
záhadou je , proč dohoda s youtube nevyšla , přestože společnost byla ochotná zaplatit stejnou částku jako amazon .
vše , co v současné době máme k dispozici , je vyjádření ceo twitche emmeta sheara : „ vybrali jsme si amazon , protože věří v naši společnost , má stejné hodnoty a dlouhodobou vizi a chce nám pomoci splnit ji rychleji . “
další záhadou je - upřímně - neuvěřitelný úspěch twitche .
pro snoby jako jsem já , kteří tvrdí , že sport radši dělají než sledují , je těžké pochopit , co je tak úžasného na tom , hry místo skutečného hraní jenom pozorovat .
jedna věc je dívat se ve tři ráno kamarádce přes rameno , jak hraje resident evil , a úplně jiná věc je pozorovat někoho cizího , jak dostane dvacet zásahů do hlavy v call of duty .
všechny hry , na které byste se právě mohli dívat .
další problém je , že spousta dnešních , nejvíc populárních her jsou z perspektivy hráče , takže dívat se na jejich záznam , aniž byste mohli sami perspektivu kontrolovat , je docela dobrý recept , jak si pořídit bolehlav .
připouštím , že hry typu speed run , ve kterých rogeři bannisteři naší elektronické doby dokončí hru v rekordním čase , je zábavné .
pokud ale někdo není mistr hraní nebo humoru , jeho kanál na twitchi pravděpodobně nebude moc zajímavý .
ale co o tom skeptici jako já vědí ?
twitch má měsíčně 55 milionů návštěv a je čtvrtý na vrcholu internetového provozu .
jak přesně toho amazon využije ?
je těžké si představit , že se twitch vmíchá do amazon instant video stejně elegantně , jako by ho bývalo mohlo spolknout youtube .
twitch ale má něco , co by chtěla přitáhnout každá firma : hordy mladých mužů , které inzerenti chtějí .
jak řekl ředitel twitche shear , amazon i twitch „ věří v budoucnost her “ a média nevypadají , že by se zdráhala , ani jako - polknutí - diváci .
druhá základní lež kreacionismu .
další český překlad amerického ateistického vloggera arona ra .
tentokrát na téma &quot; svatá písma jsou boží slovo . &quot;
přiloženo původní video .
druhou základní lží kreacionismu je víra , že posvátné texty byly sepsány bohem a nikoliv skutečnými lidskými autory .
když věřící debatují o jedné z mnoha věcí , které jsou v rozporu s jejich náboženstvím , často nás postaví před otázku : komu budete věřit ?
údajnému božímu slovu , nebo slovu člověka ?
jako kdyby lidské zkoumání bylo zcela nicotné ve srovnání s autoritou jakou si představují , že má jejich doktrína .
jenomže když říkají &quot; člověk &quot; , hovoří o vědě .
a když referují ke &quot; slovu božímu &quot; , referují k mýtům o bohu zapsaným lidmi .
jestliže skutečně existuje inteligentní s tvořitel s nějakým účelem , pak je to on , kdo vytvořil fosilní záznam , který odhaluje evoluční historii , a musí to být on , kdo vymyslel genetické vzorce , které jí odpovídají , a musí to být on , kdo dodal další řady důkazů , které ukazují výlučně k evolučnímu závěru do posledního detailu .
proč by jinak všechny tyto věci existovaly ?
zdá se , jako kdyby se nám snažil něco říct !
lidé nemohli vytvořit žádnou z těch věcí .
ale lidé dovedou vyprávět příběhy , fabulovat .
a byli to lidé , kdo napsali všechny ty texty , které předstírají , že jsou slovem božím .
každé údajně svaté učení kteréhokoliv náboženství na světě popisuje samo sebe jako sepsané lidmi , nikoliv bohy .
lidmi , kteří byli &quot; pohnuti &quot; či &quot; inspirováni &quot; svými oblíbenými bohy , nebo třeba naslouchali diktátu andělů , ale ty texty nebyly sepsány nikým jiným než pouhými smrtelníky s určitou mírou představivosti , nikoliv anděly a už vůbec ne bohy .
kdyby skutečně existoval jeden skutečný bůh , byl by integrální součástí všech bohů všech náboženství , über-galaktický supergénius , ultimátní entita celého kosmu .
kdyby bytost takové velikosti někdy napsala knihu , existovala by jen jedna taková kniha , jediné písmo svaté .
byla by známá všude na světě , bez předchůdců , paralel či alternativ v jakémkoliv jazyce , protože pouzí lidští autoři by se s takovým dílem nemohli měřit .
a lidé by jí nemuseli naslepo věřit , protože by byla konsistentní , podložena ověřitelnými a pravdivými důkazy , a zjevovala by hlubokou mravnost a moudrost dalece přesahující veškeré lidské limity .
trvale by inspirovala každého čtenáře k jednotě společné víry .
pokud by ji napsal bůh , nečekali bychom nic menšího .
jenomže to , co vidíme místo toho , je přesným opakem .
místo jediného náboženství vedoucího ke konečné pravdě máme mnoho různých náboženství bez společného původu a všechna se neustále rozpadají na čím dál více oddělené denominace , hledající sporné pravdy a každá si nějakým způsobem nárokuje boží vedení , bez ohledu na pokračující rozbíhavost a oddělování v každém směru .
židovská tóra , křesťanská evangelia , islámský korán , bahá &apos; u &apos; lláhův kitáb-i-akdás , zarathuštrovy avesty , sikhský adí-granth , mahabharátská bhagavad-gita , kniha mormonova , či kniha urantia jsou všechny považovány za &quot; absolutní pravdu &quot; a &quot; zjevené slovo jediného pravého boha &quot; a příslušní věřící každé z nich říkají , že ti ostatní jsou na scestí .
jediné logické vysvětlení pravděpodobně je , že na scestí jsou do určité míry všichni .
žádná z výše zmíněných knih nemá oproti ostatním žádnou výhodu .
žádná z nich nemá důkazní oporu a žádná se nedá historicky potvrdit .
jmenuji se dr. paul maier , a jsem profesor starověké historie na západní michiganské univerzitě .
neříkám , že jsem dokázal , že bible je spolehlivá a historický přesná .
samozřejmě , že není .
pořád musíte mít víru .
všechny z nich vyžadují víru a také apologie ( obhajoby ) , protože obsahují nesrovnalosti , absurdity a primitivní představy kdysi považované za pravdivé , které už byly překonány .
takže nelze tvrdit , že jsou důkazem božské moudrosti .
mnoho z nich prosazuje ohavná zvěrstva namísto mravnosti a o mnoha z nich se tvrdí , že byly potvrzeny naplněním proroctví - s tím , že každá taky může obsahovat proroctví která naplněna nebyla .
přední teologové připouštějí , že všechny posvátné texty jakéhokoliv náboženství byly napsány lidskýma rukama a tudíž jsou předmětem interpretací , dojmů a pohledů jejich primitivních a často předsudky svázaných politicky motivovaných autorů , čímž vysvětlují mnohé z protimluvů a nesrovnalostí v těchto knihách , zvláště pak těch v bibli .
já bych to nenazýval protiřečení , spíš vzájemné komentáře .
musíme znovu poukázat na to , že zde máme dva různé autory , jejichž práce byla nějak smíchána dohromady během nějaké redaktorské revize .
má pravdu , že genesis má více než jednoho autora a rozhodně není vyprávěním očitého svědka !
někteří experti nyní rozlišují čtyři různé zdroje jen pro pentateuch , tj. pět knih &quot; mojžíšových &quot; a mojžíšovi nepřipisují autorství žádné z nich , protože téměř jistě neexistoval tak , jak je v bibli popisován .
odborníci se shodnou na tom , že genesis byla složena ( pravděpodobně ezdrášem ) z několika vzájemně nepříbuzných ústních tradic před méně než 2500 lety .
ostatní dokumenty byly přefiltrovány v tom samém čase a všechny jsou připisovány lidským autorům .
bible není ani náhodou tak stará , jak si její věřící myslí .
svitky od mrtvého moře jsou nejstaršími archeologickými nálezy textů známé pro svůj nedokončený základ všech západních monoteistických věr , a přesto jsou o mnoho století mladší než kořeny zoroastriánství , buddhismu , hinduismu , helénismu , druidských kultů , čínského či egyptského náboženství .
křesťanství začalo jako gnostická víra , následovali docéti a ebionité a jejich úplně jiné náhledy na ježíše , které se nakonec zkombinovaly v jakémsi kompromisu nazvaném ortodoxie .
ostatní křesťanské skupiny jako luciferiáni byli rozehnáni a zdiskreditováni dalšími revizemi bible .
jedna z těchto uprav se vztahuje ke králi ugaritu , který vládl před 3500 lety .
protože jeho následovníci představovali zásadní ohrožení pro mladé mojžíšké náboženství , autoři nového zákona se rozhodli zesměšnit a ba &apos; al zebula , &quot; pána na hoře &quot; změnili na belzebuba &quot; pána much &quot; .
takže bible byla záměrně a podvodně pozměňována jak z náboženských , tak z politických důvodů .
zbývající část toho , co se stalo novým zákonem byla kanonizována ve 4. století n.l. v sérii komisních rozhodnutí na sněmu v nikaji .
čtyři evangelia byla přijata a šestnáct dalších bylo odmítnuto prostým zvednutím ruky , jako kdyby se skutečnost nějaké věci dala přijmout nebo odmítnout hlasováním .
způsob , jakým se kánon vyvinul závisel na tom , co se četlo o nedělích v tehdejších křesťanských centrech .
co se četlo na druhou neděli po velikonocích v jeruzalemské církvi ?
a co v římské církvi v tom samém čase ?
a postupně zjišťovali , že se blíží k těm samým evangelijním příběhům .
a tak se jádro kánonu takto vyvinulo z úzu prvotní církve .
takže koncil prostě přijal jako evangelium jakékoliv relevantní příběhy které kolovaly mezi nevzdělanými masami v tom čase .
ale stejně tak vědomě odebrali více než deset knih z bible , i když k nim referovaly knihy , které byly schváleny .
mezi odmítnutými položkami najdeme spisy jak apoštolů , tak proroků .
proč by nás boží slovo mělo odkazovat na knihy , které jsou jen slovy nějakých lidí a / nebo už ani nejsou k dispozici ?
kdo tady byl skutečným editorem ?
bible často zmiňuje lidské autory .
ale jak by mohla být takto schválena , kdyby byl bůh skutečným autorem této nahodilé míchanice pověstí , podobenství a žalmové lyriky ?
bible byla zcela určitě napsána lidmi a rozhodně ne příliš osvíceními , spíše naopak !
to je ten důvod proč je tak velká část jejího obsahu historicky a vědecky zcela na omylu , ať už jde o téměř cokoliv od začátku až do konce .
hovoříme o lidech , kteří věřili , že hadi a osli mohou mluvit , věřili v zaklínadla , krvavé oběti , rituální kouzla , očarované předměty , ohnivé lektvary , astrologii a pět živlů magie .
mysleli si , že když použijí kouzelný prut , kterým někoho postříkají krví , vyléčí ho to z lepry .
hovoříme o lidech , kteří si mysleli , že králíci jsou přežvýkavci a netopýři jsou ptáci a velryby jsou ryby a pí že je celé číslo .
tihle lidé věřili , že když ukáží těhotné krávě pruhované vzory , porodí pruhovaná telata .
jak by tohle mohl říct někdo , kdo ví něco o genetice ?
autoři této knihy to samozřejmě nevěděli .
kdyby bible byla sepsána nějakou vyšší bytostí , pak by neobsahovala takové chyby , jaké obsahuje .
kdyby pocházela z pera skutečně nadřazené bytosti a byla zamýšlena jako doslovná historie , potom by neobsahovala vůbec nic z toho , co obsahuje .
jako morální průvodce totálně selhává protože , většina z původních hebrejských spisů byla sepsána nevzdělanými a bigotními divochy , kteří přehlíželi nebo podporovali krutost vůči zvířatům , incest , otroctví , zneužívání otroků , zneužívání rodinných příslušníků , zneužívání dětí , násilí na dětech , potraty , plenění , vraždění , kanibalismus , genocidu a předsudky vůči rase , národu , náboženství , pohlaví a sexuální orientaci .
aby obhájili svou nelidskost tvrzením , že konají boží vůli .
avšak kreacionisté tohle všechno stále ignorují .
některé z jejich webových stránek připouštějí , že pokud je jakákoliv skutečnost v rozporu s biblí , pak musí být skutečnost ignorována !
a proč ?
protože kdyby kreacionisté neměli své milované knihy , neměli by ani boha .
v jejich světě je jedno a druhé totéž .
je ironické , že odmítají boží &quot; dílo &quot; jako &quot; uctívání stvoření namísto stvořitele &quot; .
ale sami považují slovo člověka za slovo boží a boha samotného a dokonce trvají na tom , že vyvrácení jejich údajně &quot; svatých &quot; knih nějak vyvrací boha jako takového .
nikoliv jejich verzi boha ale všechny verze boha .
kreacionističtí křesťané si myslí , že pokud se bible mýlí , pak bůh lže .
nemohou přijmout , že by bůh mohl existovat a bible by se současně mohla mýlit , protože nedokáží oddělit doktrínu od božstva .
takže jde o druh modlářství , kde věřící uctívají člověkem vyrobené kompilace , jako kdyby tyto knihy byly samotný bůh , protože si myslí že jsou jeho slovem .
jenomže bůh nikdy nenapsal ani nediktoval žádný ze spisů jakéhokoliv náboženství .
všechno , co lidé schválili či odmítli do svého údajně &quot; neměnného slova &quot; jakéhokoliv boha , bylo vymýšleno , sestavováno , seskupeno , překládáno , interpretováno , upravováno a často také záměrně pozměňováno a překrucováno pouhými chybujícími lidmi .
originál zde :
účastnice kbelíkové výzvy si vykloubila čelist
když si lila na hlavu ledovou vodu , křičela isabelle robertsová ze spojeného království tak , že si poškodila strukturu obličejových kostí .
tahle kbelíková výzva se nepovedla .
žena byla hospitalizována poté , co při kbelíkové výzvě křičela tak , že si vykloubila čelist .
zatímco si na hlavu lila ledovou vodu , křičela isabelle robertsová tak intenzivně , že si poškodila strukturu kostí v obličeji .
„ voda byla tak studená , že jsem musela křičet , ale přitom mi začala tuhnout čelist , “ řekla pro the mirror .
dvacetiletá dívka na sebe vylévá vodu .
isabelle robertsová chvíli před nehodou
zkoušela jsem zavřít pusu , ale nešlo to , byl zaseknutá , a uvědomila jsem si , že se něco děje .
potom to došlo máme a sestře , ty se mohly potrhat smíchy , ale já jsem musela rychle na pohotovost . “
dvacetiletá dívka musela být hospitalizována , aby jí vrátili čelist na původní místo poté , co se v úterý zúčastnila módní virální vlny .
video se stalo internetovou senzací , na facebooku a twitteru ho sdílely tisíce lidí .
útočník v čínské škole pobodal devět lidí , tři z nich zemřeli
muž jménem čchen podle agentury nová čína ráno násilně vnikl do budovy základní školy a kolem půl jedenácté místního času zaútočil .
tři z devíti lidí , které pobodal , později zemřeli v nemocnici .
čchen se posléze zabil skokem z výšky , uvedla nová čína s odkazem na regionální vládu .
v posledních letech čína zažila sérii podobných útoků ve školách a proti dětem .
veřejnost proto volá po větších bezpečnostních opatřeních a lepší ochraně dětí v zemi , kde má mnoho manželských párů v souladu s vládní politikou jen jednoho potomka .
zeman prvňáčkům v lánech ukázal , jak musel ve škole sedávat
nejmenší školáky odvedli deváťáci do jejich třídy , kde s paní učitelkou vyčkávali na příchod prezidenta .
ten pak dětem předvedl , jak musel sám sedět ve škole .
&quot; my jsme museli sedět s rukama za zády , to vás už naštěstí nečeká , vy už jste svobodní lidé , &quot; řekl dětem zeman .
jeho manželka pak prvňáčkům předala jako dárek hlavolam .
prezident miloš zeman s chotí v první třídě základní školy v lánech .
ministr školství marcel chládek zahájil nový školní rok v soukromé sportovní škole v litvínově .
&quot; tento rok chci více propojit české školství s českým sportem , &quot; přiblížil jeden z důvodů , proč se první školní den vydal na sever čech .
vedení školy ho před časem oslovilo na hokejovém utkání v litvínově .
&quot; byli první , tak jsem pozvání k účasti na zahájení školního roku přijal , &quot; dodal ministr .
ministr školství marcel chládek ( čssd ) zahájil školní rok v soukromé sportovní škole v litvínově .
do prvních tříd letos nastoupilo 115 tisíc prvňáčků .
na základní školy bude chodit celkem přes 850 tisíc dětí a na středních školách se bude vzdělávat přes 405 tisíc studentů , odhaduje ministerstvo školství .
novým art directorem zpravodajství novy je david fiala
novým art directorem zpravodajství a publicistiky televize nova se od 1. září stal david fiala .
ve funkci vystřídá alana zárubu , který vedl od 1. června kreativní oddělení celé skupiny nova .
david fiala dříve působil v grafickém oddělení zpravodajské televize z1 .
poslední dva roky se pod vedením alana záruby podílel na realizaci kompletní vizuální proměny zpravodajských relací televizní noviny , střepiny , prásk ! a dalších publicistických pořadů televize nova .
david fiala ovládá velmi dobře synergii komunikace mezi redakcí , studiovým řízením a grafickým oddělením , což je podstata práce art directora zpravodajství .
má cit pro typografii a čistý elegantní design , což je cesta , po které se chceme ve vizuálu zpravodajství novy dále ubírat , &quot; říká kreativní ředitel novy alan záruba .
apple icloud údajně podlehl hackerům , na veřejnost se dostaly nahé snímky celebrit
snímek obrazovky s výpisem uniklých souborů
zatím anonymní uživatel na serveru 4chan zveřejňuje nahé i pornografické snímky amerických celebrit , upozornil na to americký server mashable.com.
údajně je získal neoprávněným přístupem k uživatelským účtům na serverech applu , kam je postižení uživatelé nahráli prostřednictvím automatického zálohování obrázků z iphonů a ipadů .
apple se k problému zatím nevyjádřil .
část celebrit odmítá snímky jako zfalšované , ale již několik dotčených pravost snímků přiznalo .
patří mezi ně i herečka jennifer lawrenceová známá z titulní role katniss ve filmové sérii hunger games nebo mary elizabeth winsteadová , která hrála například ve smrtonosné pasti 4.0 .
cílem hackera je využít získané obrázky a videa k obohacení .
o záběry údajně projevily zájem americké časopisy , podle zpráv na serveru 4chan ale chce hacker raději peníze od komunity .
podle serveru the next web jde velmi pravděpodobně opravdu o slabinu v zabezpečení icloudu .
na serveru github se totiž před dvěma dny objevil nástroj , který umožňoval získat hesla k uživatelským účtům prostřednictvím hrubé síly , tedy automatickým opakováním pokusů o přihlášení s různými hesly .
tento nástroj prokazatelně fungoval , ale apple po dvou dnech bezpečnostní díru zavřel .
jisté však je , že potenciální útočníci měli spoustu času na získání přístupu k různým účtům před zveřejněním tohoto nástroje .
uživatelé icloudu by tak měli z preventivních důvodů změnit své heslo spojené s apple id .
důležitá je přitom délka hesla , ne jeho složitost .
vhodný je délka alespoň 12 znaků .
únik nahých snímků celebrit považovat za připomínku bezpečného využívání on-line služeb .
přestože jsou servery firem , jako je apple , google nebo microsoft , zabezpečené mnohonásobně lépe než počítače v domácnostech nebo menších firmách , je upload citlivých fotografií v nechráněné formě zbytečné riziko .
pokud chcete on-line zálohovat explicitní fotografie nebo jakýkoliv jiný citlivý obsah , soubory před uploadem nejprve zašifrujte .
rozumné je také nastavit automatické zálohování fotografií z telefonu tak , aby probíhalo pouze na wi-fi a po připojení k nabíječce .
tak budete mít možnost včas citlivé snímky přesunout &quot; do bezpečí &quot; , a hlavně budete mít prostor smazat nepovedené snímky , takže nebudou zbytečně zabírat prostor v on-line úložišti .
návod na to , jak šifrovat soubory i komunikaci na internetu , nabízíme čtenářům hn a ihned.cz v podobě elektronické knihy od michala altaira valáška ve formátu pdf .
chytrý způsob , jak ušetřit za vysokoškolská skripta
vzhledem k tomu , že cena za vysokoškolská skripta pro mnoho studentů přesahuje 1 000 dolarů ročně , přišel nastávající student druhého ročníku s chytrým způsobem , jak snížit náklady .
vymyslel systém půjčování knížek od spolužáků z vyšších ročníků s nabídkou nominální kompenzace , aby pozdrželi jejich odprodej zpátky .
„ knížku na výpočty , která běžně stojí 180 dolarů , jsem na semestr získal za deset a za kuřecí nugety , “ říká schroeder , 19 , který studuje na covenant college v georgii .
knížky vyžadované v jeho posledním semestru by stály 430 dolarů , říká .
utratil 120 .
podle univerzitní rady utratí průměrný student za učebnice a pomůcky více než 1 200 dolarů ročně , ale studenti mají různé možnosti , jak tyto výdaje zvládat .
preferovanou volbou studentů se stávají internetové obchody a kreativní řešení jako je to schroederovo .
na vzestupu je půjčování učebnic , což studentům umožňuje semestr knížku používat a to často s výraznou slevou , než kdyby si ji koupili .
neebo inc provozující více než 250 knihkupectví v areálech kampusů říká , že půjčování knížek se od roku 2011 zdvojnásobilo .
průzkum v odvětí ukazuje , že okolo čtvrtiny knih v univerzitních knihkupectvích bylo v minulém jarním semestru půjčených , říká viceprezident neebo trevor meyer .
méně než polovina učebních textů se podle národní asociace univerzitních obchodů v univerzitních knihkupectvích kupuje .
tady je 101 nejlepších způsobů jak uspět .
nakupování online
ceny některých nových knížek mohou být na internetu až o třetinu nižší než v univerzitním knihkupectví .
doporučená cena devátého vydání knížky „ calculus “ rona larsona , bruce edwardse a roberta hostetlera je téměř 290 dolarů , ale na internetu je možné ji na chegg.com , v maloobchodě specializovaném na učebnice , zakoupit novou za 239,99 dolarů .
kupovat použité
pokud vám nevadí poznámky jiných lidí nebo opotřebení a poničení , vhodnou možností jsou použité učební texty .
na chegg.com se „ calculus “ prodává za 93,49 dolarů .
matt casaday , 25 , student vyššího ročníku na brigham young university , říká , že na amazon.com zaplatil za použitý výtisk „ strategic media decisions : understanding the business end of the advertising business “ 42 centů .
nový se prodával za 48 dolarů .
univerzitní vyučující ingrid braceyová , vedoucí university of massachusetts amherst &apos; s college without walls navrhuje , aby si studenti u svých vyučujících ověřili , zda jsou starší vydání akceptovatelná .
někdy nejsou změny pro práci v seminářích podstatné .
pokud ano , mohou se starší vydání prodávat za zlomek ceny poslední verze .
kromě chegg a amazonu , jsou oblíbenou alternativou pro nákup použitých knih také ebay inc &apos; s half.com.
půjčování
za zvážení stojí také půjčovaní učebnic , pokud s nimi dobře zacházíte , nezapomínáte je vracet a nepotřebujete je mít i po skončení semináře .
můžete ušetřit až 80 % nákladů za novou knížku .
student by si například mohl na celý semestr půjčit „ calculus “ za asi dvacet dolarů .
seznamte se s podmínkami obchodu , ve kterém si knížku půjčujete , a to včetně postihu za poznámky , zvýraznění nebo opotřebení a poškození .
mějte na paměti : pokud knihu včas nevrátíte , pokuta může být vyšší než cena nové knížky .
e-knihy
další možností je opatřit si místo normální knížky e-knihu .
někdy se tyto knížky v podstatě půjčují v podobě elektronické licence platné po určitou dobu od distributorů jako amazon.com , chegg a barnes &amp; noble inc .
chegg půjčuje „ calculus “ na šest měsíců za přibližně 61 dolarů .
podle braceyové tak mohou ty nejvýhodnější nabídky najít studenti literárních kurzů , protože mnoho klasiků je nyní k dispozici ke stažení zdarma , zatímco přírodovědné a technické texty mohou být velmi drahé .
v každém případě choďte po obchodech .
joe gault , 29 , který brzy nastoupí na pepperdine law school , doporučuje řídit se podle isbn , protože to zaručuje , že kupujete správnou knihu .
předtím , než si knížku objednáte přes internet , ujistěte se , že je opravdu skladem , radí gault .
přesvědčil se o tom na vlastní kůži .
knížka , kterou si koupil , byla vyprodána na čtyři týdny , a musel zaplatit plnou cenu za knížku z univerzitního knihkupectví .
bahno , samé bahno .
a pak našli ve studni torzo pušky z konce války
ta studna stojí kousek od kostela sv. jiří .
odkryli jsme porost okolo a začali jsme vytahovat letitý nános - zhruba metr a půl bahna a shnilého listí .
když jsme se blížili k jílovitému dnu , narazili jsme na hlaveň , &quot; líčil radomil novák .
vytáhli jsme ji , očistili a zjistili , že je to torzo útočné německé pušky , kterou používaly jednotky ss .
nález je údajně neobvyklý .
podle mých informací se takové pušky vyráběly až ke konci války .
a bylo jich asi tři sta tisíc , &quot; dodal novák .
všechny dřevěné konstrukční věci se časem rozložily , proto je nepoužitelná .
její tělo je ovšem zachovalé - drží svůj tvar .
jak se ve studni ocitlo ?
jedno vysvětlení existuje .
možná ji tam hodili lidé , kteří se potřebovali zbavit zbraně používané jednotkami ss , pravděpodobně ze strachu , aby nebyli odsunuti .
fašisté na útěku by to zřejmě neudělali .
ti odhazovali zbraně v lese , &quot; myslí si nálezce .
puška bylo to jediné , co nadšenci z hnutí duha jeseníky ve studni našli .
&quot; mohly tam být i ruční granáty , těch tu kdysi byla všude kolem spousta , proto jsme zpomalili výkopové práce , pečlivě jsme prohmatávali bahno , aby se nestalo nějaké neštěstí , ale nic jiného tam dole nebylo , &quot; přiblížil novák .
nález skončí v depozitáři muzea na zámku v nedalekých slezských rudolticích .
ukrajinský generál : zajatého čecha jsem zatím neosvobozoval
exkluzivní rozhovor aktuálně.cz s generálplukovníkem volodymyrem rubanem , který osvobozuje ukrajinské vojáky ze zajetí proruských separatistů .
kyjev / praha - &quot; promiňte , musím to vzít ... volají mně z doněcka , &quot; omluvil se snad osmkrát při exkluzivním rozhovoru s aktuálně.cz ukrajinský generálplukovník volodymyr ruban , jinak také ředitel tamního centra osvobozování válečných zajatců .
generálplukovník volodymyr ruban v televizní debatě .
při každém takovém přerušení nebylo možné neslyšet jména lidí , jejich počty či místa , kde jsou - anebo by měli být - , které si ruban upřesňuje se svým protějškem na druhém konci telefonu .
&quot; to bude ono - jeď tam , &quot; zakončil jednu z bleskových diskusí s doněckem a opět se věnoval té naší .
volodymyr ruban je generálem v záloze , někdejší pilot stíhačky a aktivní účastník protivládních protestů na majdanu .
ještě včera - když jsme si domlouvali rozhovor - byl v doněcku .
osvobozování ukrajinských vojáků ze zajetí proruských separatistů se věnuje čtyřiadvacet hodin denně .
aktuálně.cz : možná víte , že na straně proruských separatistů bojují i češi .
naše kontrarozvědka odhaduje jejich počet do třiceti .
může jich být ovšem i mnohem víc .
už jste se s nějakým českým zajatcem při vašich vyjednáváních setkal ?
volodymyr ruban : osvobozoval jsem už zajaté srby , dagestánce , čečence , jednoho švéda , gruzínce ... ale čecha zatím ještě ne .
ale vím , na koho se v praze obrátit , pokud bychom narazili na vašeho zajatého krajana a mohli ho vysvobodit .
ukrajinský voják zajatý separatisty
a.cz : co radíte čechům , kteří se přidávají k proruským separatistům a ukrajinští vojáci je zajmou ?
měli by pochopit , že pokud jako češi bojují v ukrajinských praporech dobrovolníků a separatisté je zajmou , tak je po výslechu bez milosti zastřelí , stejně jako kteréhokoliv jiného cizince .
separatisté považují tyto muže za nájemné žoldnéře a ti si podle nich nic nezaslouží nic jiného než smrt .
pokud ale například ukrajinští vojáci zajmou skupinu doněckých separatistů - a mezi nimi tedy třeba i čecha - , tak ho posadí za mříže a jednají s ním jako s válečným zajatcem .
ten chlap zkrátka přežije .
ukrajinská strana se chová i ve válce jako stát .
a.cz : a kolik se vám už podařilo zachránit ukrajinských zajatců ?
jestli tomu dobře rozumím , tak výměnou .
některé zdroje uvádějí , že už to dávno překročilo stovku mužů .
dávno už jsme přestali počítat , kolika lidem jsme pomohli .
jenom jsme je ale osvobodili ... před válkou nezachránili , pokud se rozhodnou v bojích pokračovat .
zachránci jsou ve válce lékaři , chirurgové , ale my rozhodně ne .
tak to je .
a každý den přibývají další a další .
každý den někoho zachráníme .
někdy jednoho , jindy čtveřici či pětici .
a nemusí jít vždy o výměnu .
někdy stačí k propuštění zajatců i pouhá lidská prosba .
a.cz : proslýchá se , že jste si za několik měsíců získal u proruských separatistů velkou autoritu a dokonce i důvěru ... stejně jako v ukrajinské společnosti .
jak se vám podařilo vybudovat respekt obou válčících stran ?
těžká otázka .
jeden z důstojníků v kyjevě mně dal přezdívku &quot; šílený generál s ocelovými koulemi &quot; .
neuráží mě to .
a možná to i vystihuje podstatu naší práce .
jako šéf ukrajinského důstojnického sboru jsem si nějakou tu autoritu získal už dříve .
nikdy nechytračím , nepodvádím a držím vždy slovo .
ať se děje cokoliv , tak jednám čestně a mluvím pravdu .
dokonce i tehdy , když je to ukrajinské vládě , anebo té doněcké či luhanské velmi nepříjemné .
pokud mučí a zabíjejí lidi ?
tak jim jednoduše říkám , že je mučí a zabíjejí .
a že jsou to zločiny .
často přitom riskuji život , dokonce mě při výměně zajatců i zajali ... tahle práce pro mě může kdykoliv znamenat konec ... nemusím se vrátit .
a.cz : o kolika popravách a mučení zajatců víte ?
... ( dlouhá pomlka ) ... k mučení zajatců se při výsleších uchylují ukrajinci i separatisté .
bohužel .
a popravy ?
ty se odehrávají jen na doněcké straně .
o tom , že rovněž ukrajinská armáda popravuje zajatce , nemám informace .
ani náznaky o tom , že se ukrajinská armáda něčeho podobného dopouští .
o množství poprav máme představu , ale čísla uvádět nemohu a ani nechci .
a.cz : popište mi charaktery a motivy proruských separatistů .
jsou mezi nimi důstojníci , ale i veteráni z afghánistánu .
snaží se o samostatnost a možná i demokracii v doněcku či luhansku - tak to alespoň říkají .
nechtějí už více hrát hry s ukrajinskými oligarchy .
separatisté mají už oligarchů plné zuby a jsou jejich nesmiřitelnými odpůrci - na život a na smrt .
jak my říkáme - přejedli se jich až po hrdlo .
stejné sny a tužby lidé dávali mimochodem najevo i na majdanu .
a teď si trochu zaspekuluji : rusko podporuje separatisty a západ naopak ukrajinský stát .
jednu spekulaci považuji za velkou a tu druhou naopak za malou .
už tahle moje věta ale v sobě skrývá nesmiřitelný rozpor .
a.cz : jak se vám například jeví jeden z nejtvrdších vůdců proruských separatistů igor bezler ?
vždy když překračuji linii válečné fronty , jsem beze zbraně a ukazuji vojákům či ozbrojencům rozpřažené holé ruce .
a vždy mě mají obě strany těch dvě stě či tři sta metrů na mušce či v optickém zaměřovači .
ty obličeje lidí , kteří na mě míří , pokaždé dobře vidím ... a oni mohou kdykoliv zmáčknout spoušť svých zbraní .
výsadkář , zkušený plukovník s německými i ukrajinskými předky .
považuje se za ruského důstojníka , avšak jeho rodina - matka - žije na ukrajině .
věří , že ukrajina by neměla existovat .
a jestli ano , tak jen jako malá gubernie ve velkém ruském impériu .
v každém případě o tom neustále hovoří a ukrajinu považuje za jakési vzniklé nedorozumění .
takový stát by podle něj ani neměl existovat .
zároveň je nesmiřitelným nepřítelem všech ukrajinských oligarchů .
a.cz : když už hovoříme o charakterech - v diskusní show ukrajinské televize jste vašeho premiéra arsenije jaceňuka označil za slabého , bezradného a unaveného &quot; vůdce &quot; , jenž by udělal nejlépe , pokud by rychle odešel .
za těch tři sta metrů chůze dostanu vždy alespoň pětkrát strach .
proč bych se měl tedy tajit s názorem , že jaceňuk je velmi slabým premiérem a že škodí naší zemi ?
a.cz : má podle vás podíl na válce v ukrajině ?
možná víte , že ukrajinci jaceňuka přezdívají &quot; králíkem &quot; .
a králík není v očích ukrajinců zvířetem , z něhož by šel strach či by mělo u ostatních respekt a autoritu .
jeho chování přímo kopíruje chování králíka .
možná je dobrý ekonom , ale jako premiér nemá ve válce právo plakat v parlamentu , prosit ho , hrát s ním jeho intriky , vyhrožovat , že položí funkci ... on musí zemi řídit , spravovat ji a v době války i chránit .
při ohrožení země nemá premiér nárok na rodinu , kamarády , odpočinek na plačtivé emoce .
on je přece prvním z ministrů ukrajiny .
a jaceňuk ?
chová se jako pubertální dívka .
ano , je unaven , ale také slabý , protože nebyl nikdy silný ... nebojuje za ukrajinu , jen si neustále na vše stěžuje .
měl by proto odejít .
čím dříve , tím pro ukrajinu lépe .
proč strážci galaxie nedokázali zachránit tržby
postradatelní 3 sylvestera stallonea vrátili z devadesátimilionového rozpočtu v usa méně než 30 milionů dolarů a sin city : ženská , pro kterou bych vraždil vrátil ze sedmdesátimilionového rozpočtu jenom 12 milionů .
film sex tape s cameron diaz během prvního víkendu vydělal pouze 14,6 milionu dolarů a také filmy pro děti jako jak vycvičit draka 2 byly pro kina zklamáním .
podle článku filmového kritika robbieho collina v telegraphu je , co se dětských filmů týče , na vině jejich samotná kvalita .
collin označil rok 2014 jako „ nejhorší “ rok dětských filmů a jak vycvičit draka 2 nazval pouhým „ funkčním “ pokračováním .
když přijde na filmy nasazené na trochu starší cílovou skupinu , zdá se , že problém nutně nemusí být v kvalitě samotných filmů .
v červenci porovnal entertainment weekly servery cinemascore a metacritic a jejich průměrné hodnocení letních filmových premiér vysílaných alespoň ve 2 000 kinech v období mezi dnem obětí války a 20. červencem v roce 2013 a v tomto roce .
výsledky , které berou v úvahu názor diváků i filmových kritiků , naznačují , že letošní filmová úroda je podobné kvality jako loňské hity .
podle některých komentátorů může být na vině změna v přístupu diváků a vyšší popularita internetových serverů jako netflix .
režisér jon favreau , který v současné době pracuje na disneyho zpracování knihy džunglí , webové stránce hollywood reporter sdělil : „ myslím , že časy se mění . “
musíme si to připustit a nesnažit se honit se za tím , co už bylo .
na rozdíl od současné krize hollywoodských kasovních trháků dosáhl zisk netflixu díky internetovým službám 1,2 miliard dolarů , což je téměř dvakrát víc než loňských 837 milionů dolarů .
minulé léto kritizoval režisér steven spielberg studia za to , že se příliš spoléhají na práva ke komiksům , a předpověděl „ zhroucení “ hollywoodu .
ve světle současného propadu prohlašují někteří komentátoři , že na jeho katastrofické věštbě může něco být .
s uvedením možných velkých kasovních trháků v létě 2015 včetně avengers : age of ultron , mimoňů a jurského světa , jsou ve filmovém průmyslu jiná čísla optimističtější .
producent x-men simon kinberg nedávno označil pokles v tržbách za jednoduše „ cyklický “ . pro hollywood reporter řekl : „ příští léto bude létem největších kasovních trháků v historii a nikdo si nebude dělat starosti s prodejem . “
kldr opět hrozí soulu , odpálila další raketu krátkého doletu
severní korea odpálila do moře další raketu krátkého doletu , oznámil soul .
údajný test rakety se uskutečnil krátce po ukončení společných vojenských manévrů spojených států a jižní koreje , které pchjongjang vnímá jako přípravu na invazi .
provincie čagang leží na severozápadě kdlr při hranicích s čínou .
mluvčí jihokorejského ministerstva obrany podle agentury dpa uvedl , že střely byly odpáleny z místa na severozápadě kldr a doletěly do vzdálenosti zhruba 200 kilometrů .
severní korea tak zřejmě poprvé odpálila raketu z provincie čagang , uvedla jihokorejská média s odvoláním na armádní kruhy .
v provincii se prý nachází podzemní odpalovací rampa pro rakety typu scud .
jde o další ze série podobných zkoušek , které izolovaný severokorejský režim provedl v posledních týdnech .
severní korea letos uskutečnila nezvykle velké množství testů raket a dělostřelectva .
summit nato : první protesty v newportu a cardiffu
během víkendu proběhly protesty odpůrců summitu nato v newportu .
v sobotu se stovky lidí shromáždily v centru newportu , aby se zúčastnily pochodu proti nato .
a v neděli asi 150 lidí přišlo na radnici v cardiffu na setkání , které bylo popsáno jako proti-summit .
stephen fairclough sledoval během víkendu situaci a mluvil s protestujícími , kteří přicestovali z bridgend do belgie .
teenageři museli být letecky přepraveni z blue mountains
dva mladiství turisté byli vyzvednuti letadlem a převezeni do bezpečí poté , co strávili noc v blue mountains v novém jižním walesu .
šestnáctiletá dívka a osmnáctiletý muž se po nedělním poledni vydali na túru do govetts leap v blackheathu .
když se nevrátili domů , znepokojení příbuzní zavolali kolem osmé hodiny večer policii .
byla vyslána pátrací četa včetně místní policie a záchranný tým a pár byl okolo jedenácté hodiny večer nalezen poblíž bridal veil falls .
dívka si poranila koleno a muž spadl a přitom se uhodil do hlavy .
policisté s nimi zůstali přes noc a v pondělí ráno byli vyzvednuti .
ve stabilizovaném stavu byli sanitkou převezeni do blue mountains hospital .
olomouc přivezla z opavy jen bod , výhru měl na noze vašíček
právě 23letý forvard mohl rozhodnout , ve dvou největších šancích ale neuspěl .
po gólu volala hlavně střela zblízka tři minuty před koncem , místo v síti ale skončila na brankáři opavy josefu květoňovi .
měl jsem to na noze , takové šance musím dávat .
sám na sebe jsem naštvaný , &quot; sypal si vašíček popel na hlavu .
&quot; asi jsem to měl dávat výš pod víko , trochu mi to sjelo , &quot; přemítal .
defenzíva sigmy toho opavě moc nedovolila , výjimkou byl mikulův nájezd z 11. minuty , který však pokryl gólman reichl .
pak už začali tlačit hanáci , do šancí je ale v bloku bránící domácí nepouštěli a střely z dálky pochytal květoň .
patnáct minut jsme se srovnávali , pak jsme převzali iniciativu .
ve druhém poločase jsme už byli lepší , měli jsme více ze hry a opava nás ohrožovala jen ze standardních situací .
ale vyloženou šanci vašíček neproměnil , a tak to skončilo 0 : 0 , &quot; mrzelo trenéra hanáků leoše kalvodu .
opava bod brala i kvůli absencím v sestavě , kde kromě dvojice zraněných chyběli i petr vavřík s třígólovým střelcem petrem ševčíkem , kteří ve slezsku hostují ze sigmy .
ta jim na rozdíl od své dřívější politiky neumožnila nastoupit .
náhradníci si zaslouží absolutorium .
sigma působila fotbalověji , ale až na jednu standardku jsme ji k ničemu nepustili , &quot; mínil trenér slezanů petr baránek .
bylo k vidění hodně důrazu , agresivity a bojovnosti .
remíza je asi zasloužená , bod je pro nás slušný zisk , &quot; dodal .
sigma se remízou dostala na čtyři body , což znamená třinácté místo .
nic , co by mohlo uspokojit šéfa klubu josefa lébra , který po porážce se znojmem podmínil svůj milionový vklad do pokladny diametrálně rozdílnými výkony v dalších zápasech .
&quot; uvědomovali jsme si varování pana lébra , takže nemůže být řeč o tom , že by kluci nechtěli bojovat , &quot; všiml si kalvoda a na adresu spícího střelce vašíčka dodal : &quot; věřím , že to přijde a až dá gól , tak mu to tam začne padat .
ale po první trefě ho hned vystřídám , aby si góly šetřil i na další zápasy , &quot; smál se kalvoda .
al pacino dvakrát nadchl benátky .
filmový festival jinak prožívá krizi
po obrovském nadšení nad zahajovacím filmem birdman , jehož režisér alejandro gonzález iňárritu se rázem zařadil mezi vážné kandidáty na zlatého lva , další dny nasvědčovaly dojmu , že zájem o 71. ročník festivalu v benátkách poněkud opadl .
ať už proto , že počet míst v největším sále se zvýšil na čtrnáct set , nebo proto , že po birdmanovi následovaly kritiky uznávané , ale pro diváky méně přitažlivé snímky jako dokument o genocidě v indonésii 60. let pohledem ticha a jiné filmy se sociální tematikou od amerických 99 domovů po íránské povídky , v kinech zkrátka zůstávala prázdná sedadla .
hrdinové z komiksů
dokonce ani červený koberec před festivalovým palácem neobléhaly zatím takové davy jako v minulosti a údajně přestalo být problémem sehnat na poslední chvíli místo v hotelu .
o krizi se v itálii mluví více než jinde a není divu , že postihla i tak vážené instituce jako biennale a nejstarší filmový festival na světě .
naštěstí se krize neprojevuje nedostatkem osobností , přítomných však výhradně v souvislosti s filmy .
zatímco mladší fanoušci toužili po autogramech představitelů komiksových superhrdinů michaela shannona a andrewa garfielda , kteří se v 99 domovech vcelku úspěšně zhostili dramatických rolí , pro všechny generace bez rozdílu se stala hlavní událostí návštěva legendárního herce ala pacina .
zazářil tu navíc hned ve dvou filmech .
v příběhu prozření uváděném mimo soutěž , který natočil oscarový barry levison podle románu philipa rotha , má čtyřiasedmdesátiletý pacino roli , jež je mu blízká : herce na vrcholu slávy , který trpí depresemi z konce kariéry i osobního života .
ale vidět ho hned druhý den jako podivínského majitele železářství z venkovského městečka ve filmu manglehorn , jejž natočil david gordon green , to byl opravdu nezapomenutelný zážitek .
volpiho pohár za nejlepší herecký výkon by ho neměl minout - ale má ještě umělec pacinova formátu zapotřebí cen ?
možná je pro něj největší satisfakcí láska publika , a toho italského zvláště , neboť ačkoli se narodil v new yorku , hlásí se al pacino hrdě k zemi , ze které pocházejí jeho prarodiče .
body pro italy
ostatně právě italský film si letos vede v benátkách velice dobře .
černé duše , které režíroval francesco munzi , se staly po birdmanovi prvním snímkem odměněným dlouhým potleskem vstoje .
kalábrijská odnož mafie je v něm nahlížena pohledem na rodinné vztahy mezi klany , které vzájemně bojují o moc i peníze , a režisér dokázal sladit všechny předpoklady pro dobrý film : kvalitní scénář , kameru , hudbu a herce .
zaujal také komorní psychothriller hladová srdce , který natočil saverio costanzo s albou rohrwacherovou v úloze ženy , jež svou scestnou úzkostlivostí málem zahubí vlastní dítě .
naopak z francouzských soutěžních filmů se nedočkaly vřelého přijetí ani výkupné za slávu , ani 3 srdce , obě díla ulpívající na tradičním modelu konzumních filmů , které se opírají o popularitu hereckých představitelů .
ale koneckonců , dva opravdu výtečné filmy , tedy birdman a černé duše , nejsou na první polovinu festivalu tak málo .
a třebaže festivalové snímky mají vesměs depresivní náměty , nový snímek petera bogdanoviche s názvem she &apos; s funny that way , vtipná komedie uvedená v benátkách mimo soutěž a natočená ve stylu amerických veseloher 40. let , dokázala pozvednout náladu na víc než jeden den .
policisté chytili v praze čtyři výrobce pervitinu , léky vozili z polska
&quot; detektivové zadrželi v uplynulých dnech tři muže ve věku 42 , 42 a 37 let a pětadvacetiletou ženu , kteří od loňského listopadu až do letošního srpna vyrobili a prodávali drogu pervitin na praze 9 , &quot; uvedla policejní mluvčí jana rösslerová .
nejprve v úterý 12. srpna zásahová jednotka v cihlářské ulici chytila dvaačtyřicetiletého organizátora a dealera v jedné osobě a mladou ženu , která ve skupině figurovala jako nákupčí léků v polsku a prodejkyně dávek .
následující den detektivové zadrželi na základě předchozího souhlasu státního zástupce dalšího člena skupiny , a to sedmatřicetiletého muže .
posledního ze čtveřice policisté dopadli ve středečních ranních hodinách 20. srpna v areálu malešické spalovny , &quot; popsala mluvčí .
za převoz léků z polska dostávala žena třetinu drogy
hlavní organizátor měl široké pole působnosi .
v dílně letenského areálu , v zahradním domku v horoměřicích , v bytě v koněvově ulici a na dalších místech na praze 9 vyráběl pervitin , opatřoval různé pomůcky a chemikálie potřebné k jeho výrobě a zajišťoval převoz léků s pseudoefedrinem z polské republiky .
dále vyrobenou drogu vážil , rozděloval do plastových sáčků a pervitin následně prodával .
s převozem léků z polska nebo prodejem narkomanům mu vypomáhala pětadvacetiletá , dosud netrestaná žena .
za to dostávala od organizátora odměnu v podobě třetiny vyrobené drogy , &quot; dodala rösslerová .
kriminalisté provedli na základě příkazu soudce také několik domovních prohlídek , kde zajistili drogu , průmyslové chemikálie , digitální váhy , platové sáčky , injekční stříkačky , hadičky a další pomůcky a předměty , které lze podle expertiz považovat za kompletní výbavu pro výrobu metamfetaminu .
dealer byl od roku 1995 trestán už sedmkrát
&quot; z dostupných evidencí pak policisté zjistili , že hlavní organizátor byl od roku 1995 celkem sedmkrát soudně trestaný za majetkovou trestnou činnost , žena soudně trestaná nebyla , &quot; doplnila policejní mluvčí .
poslední zadržený byl v roce 2006 podmíněně odsouzený za trestný čin pohlavní zneužití a sedmatřicetiletý automechanik , který je stíhaný na svobodě , byl od roku 2009 devětkrát soudně trestaný .
i u něj to to bylo převážně za majetkovou trestnou činnost .
vyšetřovatel obvinil tři muže a ženu ze spáchání trestného činu nedovolená výroba a jiné nakládání s omamnými a psychotropními látkami a jedy , za což jim hrozí až desetileté vězení .
u tří osob nakonec podal vyšetřovatel státnímu zástupci i podnět k návrhu na uvalení vazby , kam je nakonec soudce umístil , &quot; řekla mluvčí .
čtvrtý obviněný , sedmatřicetiletý recidivista , skončil na svobodě .
jeho postavení a úloha v tomto případě nebyla až tolik zásadní jako u ostatních obviněných .
policisté s tímto mužem i tak nadále pracují .
ferrari nabízí šachy ze dřeva a karbonu .
ferrari nabízí v rámci svých dalších produktů velmi zajímavé věci za hodně &quot; zajímavé &quot; ceny .
jako dobrý příklad poslouží třeba v itálii ručně vyrobené šachy s hrací deskou o velikosti 42 x 42 cm .
pokud se vám líbí , připravte si více než 40 000 kč .
přesná cena činí 43 405 kč .
zákazník získá sadu dřevěných černě a červeně lakovaných figurek uložených v dřevěné krabici potažené karbonovými vlákny .
asi nikoho nepřekvapí , že místo klasického jezdce mají hráči k dispozici figurku vzpínajícího se koníka .
pokud se vám šachy nezdají jako dostatečně hodnotný dárek , je k dispozici také třeba model ferrari 500 f2 vyrobený ( samozřejmě ručně ) v měřítku 1 : 1,8 .
cena této hračky činí 318 305 kč .
rušení gymnázií a středních škol nedává smysl .
česko má málo všeobecně vzdělaných lidí a statistiky navíc ukazují , že gymnazisté mají dobré uplatnění .
začátek školního roku je tu .
ve školách v posledních čtrnácti dnech probíhaly velké přípravy .
většinou jde o rutinní záležitosti , jako třeba přenést květináče z letního úložiště zpět do tříd a nafasovat křídy .
na hořickém gymnáziu budou mít trochu větší frmol .
pár dní před začátkem sezony shánějí nábytek , počítače a další technické vybavení i literaturu do knihovny .
nedošlo k loupeži ani zpronevěře , čtyřleté gymnázium v hořicích po třech letech otevírá a obnovuje svoji činnost .
nikoliv na veřejné , ale na soukromé platformě .
nedostatek materiálního vybavení není způsoben tím , že by zakladatelé byli tak neschopní .
museli čekat na to , zda bude existence školy potvrzena zanesením do rejstříku škol spravovaného mšmt .
„ francouzští socialisté by měli sklapnout a dát francii do pořádku , “ říká klíčový spojenec francoise hollanda
valls vyzývá silně roztříštěnou levici , aby „ ukázala svou podporu “ bojovně naladěnému socialistickému prezidentovi , jehož nové rozdělení funkcí se nesetkalo se souhlasem většiny francouzů .
prezident si zaslouží všeobecný respekt , zaslouží si loajalitu , zaslouží si naši podporu .
„ naše povinnost je zůstat mu po boku , “ řekl a sklidil potlesk .
jako smířlivé gesto trval předseda vlády na tom , že jeho vláda nebude zpochybňovat kontroverzní francouzský třicetipětihodinový pracovní týden a to navzdory vášnivým dohadům ze strany emmanuela macrona , nového ministra financí , který na začátku týdne navrhl , aby se pravidla uvolnila .
v sobotu hollande žádal socialisty , aby zůstali „ soudržní “ s vládou .
christiane taubirová , ministryně spravedlnosti , mu ale udělala čáru přes rozpočet , když se objevila na setkání rebelujících socialistických poslanců , kde socialistickou stranu kritizovala za to , že kvůli ní „ francouzi ztratili víru v budoucnost . “
marine le penová , lídryně extrémně konzervativní pravice , se neustálým vnitřním sporům mezi socialisty vysmála , když prohlásila , že nepředpokládá , že nová vallsova vláda vydrží déle než pár měsíců .
císař francois hollande je nahý a princ manuel valls také . byli donuceni sestavit novou vládu , když ta předchozí nevydržela ani do konce léta .
„ a nová nevydrží do konce podzimu nebo zimy , “ řekla le penová svým příznivcům .
znovu zopakovala výzvu své strany k rozpuštění parlamentu a prohlásila , že je přesvědčená , že by to straně mohlo vyhrát předčasné volby a že je připravena řídit zemi .
francouzská vládnoucí strana utrpěla v březnových komunálních volbách porážku a v květnu extrémně konzervativní pravice uspěla ve volbách do evropského parlamentu .
podle průzkumu veřejného mínění týdeníku journal du dimanche si 76 procent francouzů myslí , že socialistická strana se vystavuje riziku , že se rozdělí na několik soupeřících frakcí ještě před koncem hollandova funkčního období v roce 2017 .
pascal perrineau , politolog univerzity sciences po , varoval , že francouzům brzy dojde trpělivost , pokud se nové socialistické vládě nepodaří zlepšit ekonomiku a snížit rekordní nezaměstnanost .
„ je to omezený prostor pro příležitost , ale veřejné mínění si musí myslet , že v situaci dochází ke změnám , “ varoval .
jinak by se situace mohla ještě zhoršit .
hazard a pouliční umění už praha do voleb neomezí
změny příslušných vyhlášek by mělo připravit a schválit až nové vedení hlavního města .
z ulic prahy nezmizí před komunálními volbami další herny a město nebude omezovat pouliční umění .
omezeno nebude ani venčení psů .
praha nestihne do říjnových voleb připravit a schválit v zastupitelstvu změny příslušných vyhlášek .
&quot; rozhodnutí o změnách by navíc nemělo dělat současné vedení města , kterému končí za několik týdnů mandát , &quot; řekl radní lukáš manhart ( top 09 ) .
zrušit plošně hazard na svém území se v uplynulých týdnech rozhodlo hned několik radnic , například prahy 5 a 7 .
herny ale nezmizí , vyhláška o hazardu se měnit zatím nebude .
je to úkol nového vedení města po volbách .
nyní bychom to ani technicky nestihli vzhledem například k lhůtám na podání připomínek a podobně , &quot; vysvětlil manhart .
dodal , že poslední jednání současného zastupitelstva , které musí změnu vyhlášky schválit , se uskuteční 11. září .
referendum o plošném zákazu hazardu chystají v den komunálních voleb městské části praha 1 a praha 8 .
v současné době platí zákaz hazardu například v praze 2 či praze 12 .
vyhláška se ze stejných důvodů nebude měnit ani v případě pouličního umění , takzvaného buskingu .
na ten si stěžuje zejména praha 1 , která již poslala magistrátu návrh míst , o která by chtěla současný seznam zakázaných míst rozšířit .
hudebníky nechce rovněž praha 5 v okolí anděla .
vyhlášku regulující venčení psů město chystá několik měsíců , zatím není dokončena .
umístění heren i problematiku buskingu řeší městské vyhlášky .
může je vydávat či upravovat pouze zastupitelstvo hlavního města .
radnice mají jen poradní hlas , samy vydávat vyhlášky nesmějí .
minulý týden umístil vítězství proponentům skotské nezávislosti na dosah ruky
kampaň za skotskou nezávislost byla v nebezpečí , že tuto chybu udělá napotřetí , když málem umístila na billboardy po celém skotsku otázku , zda chtějí skoti být bohatí .
jenže k srdcím skotských voličů se nedostanete tím , že budete apelovat na jejich peněženku , ani si nezískáte jejich respekt , když jim začnete vyhrožovat .
morálka nového zákona je ve skotsku stále živá , i když jen málo skotů ještě chodí i dnes do kostela .
skoti mají daleko větší tendenci vyhnat směnárníky z chrámu , než aby si nechali od nich diktovat , jak mají hlasovat .
šéf skotských nacionalistů alex salmond tohle dobře ví , a proto se v televizní diskusi opakovaně dotazoval svého soupeře , unionistického darlinga , zda je ochoten respektovat &quot; suverénní vůli skotského lidu &quot; , pokud by skotští voliči hlasovali pro nezávislost , a začít podporovat jednotnou měnu pro skotsko i pro anglii .
to darlinga donutilo , aby volil mezi skotskou občanskou společností a londýnskými finančníky , a s grimasou padl do této pasti .
samozřejmě , že darling nepodpoří mandát skotských voličů .
avšak ta diskuse o tom , jakou bude mít skotsko měnu , byla už víceméně neutralizována .
co opravdu motivuje skotské voliče je férovost , pracovní příležitosti a obrana státního zdravotnictví , které mají občané zadarmo .
darling ve věci měny podpořil londýnské bankéře a vyvolal také dojem , že nebude protestovat proti privatizaci zdravotnictví .
tím , jak to řekl salmond , &quot; vlezl do postele s konzervativci &quot; .
to je pro každého skotského politika velmi nebezpečné postavení .
každý skotský volič ví , že skotští podnikatelé jsou v posteli s konzervativci .
to potvrdil david cameron , který ve skotsku promluvil nikoliv k voličům , ale k asociaci &quot; bossů &quot; , ke konfederaci britského průmyslu .
začíná být jasné , že cameronovo odmítnutí debatovat o nezávislosti se skotským premiérem salmondem bylo pro unionistickou kampaň vážným omylem .
cameron tak vypadá jako zbabělý absentující domácí .
skoti by ho respektovali , kdyby přijel na debatu se skotským premiérem .
cameron aspoň dokázal říct , že skotsko může být &quot; úspěšnou nezávislou zemí &quot; .
alistair darling nedokáže nic takového říct , působí mu to téměř fyzickou bolest .
to , co sděluje , je jasné : skoti si nemají vyskakovat a musejí přijmout to , co je .
nejdelší rok má 10 měsíců .
pesimistický začátek školy podle miloše urbana
ilustrace k povídce nejdelší rok
miloš urban nejdelší rok
konec byl z prázdnin vůbec nejlepší , ten poslední týden , co se už nikam nejelo a jenom jsme se povalovali a povlávali s babím létem , ticho před bouří , klid před stresem .
nové oblečení , když se dalo sehnat z tuzexu , botky z východního německa .
čtení rychlých šípů , už popadesáté , svištění na kole horem kolem imperialu až dozadu za vary , někam k tenisovým kurtům , už nebylo vedro , slunce hladilo záda a ramena , poklepalo paprsky na rozloučenou .
večer mírná nervozita , pořád ještě prázdninový režim , spát až v půl jedenácté , za týden bude hůř , chvíle před usnutím se protáhnou z pár minut na dvě hodiny , ráno pak vstávat v půl sedmé .
přijde pondělí .
většinou neprší , naopak , léto se zlomyslně pošklebuje před školou .
připloužit se v přízračném světle na plácek a připadat si jako plastová postavička ve skleněném těžítku , je tam ta škola , zdš a .
zápotockého s obludně růžovou omítkou , a před ní staré známé obličeje i pár nových , kluci vytáhlejší , holky prsatější .
tamhle jsou grázlové , těm se vyhnout , stejně je zajímavé , jak neomylně drží pospolu a jak jsou tady brzo .
a tyhle dospěle vypadající holky , jež přišly zakřiknuté , se teď něčemu hystericky smějí , asi se v jejich životě přes prázdniny něco změnilo , zatímco u mě je všechno při starém .
a zas noví prvňáci , někteří nervní a jiní natěšení , proč sem vůbec lezou ?
protože musí , vzdělávací vojnou povinní .
tak tedy dovnitř , chladná vlhkost podlahy a lehký pach dezinfekce , otrávený školník s mopem , bohužel pořád ten samý , co prý zapůjčí žáku klíček od plechové skřínky , kde se dají nechávat učebnice a kterých je pořád tak málo .
za flašku .
smrad šaten zůstává v paměti , nyní se nekoná , je pěkně vyvětráno , ale za týden bude hůř .
už jenom z té představy se svírá žaludek a začíná bolet hlava .
hlava , která ještě hůř pojme učivo z matematiky , té ďábelské hry pro vyvolené , mezi něž nepatřím a nikdy nebudu .
zase ty trojky a čtyřky , nedejbůh pětky , schovat se před zkoušením , zapadnout do lavice a nejlépe vysublimovat , být tam i nebýt , existovat jen jako jméno v třídnici a snít si zatím příběhy o milejších holkách a hezčích budovách , o anténách do vesmíru , kde nikdo s nikým nesoutěží , nikoho neponižuje a nikomu nepodráží nohu .
nejdelší rok má deset měsíců .
a je teprve den prvý , teď jako před lety .
narozené dcery nechala zemřít .
hrozí jí až výjimečný trest - novinky.cz
k prvnímu porodu došlo v březnu 2012 v kabince veřejných toalet na autobusovém nádraží v jihlavě .
bez cizí pomoci se jí narodila holčička , kterou po přestřižení pupečníku zabalila do připravené deky , schovala pod bundou a odnesla k silničnímu přivaděči , kde ji odložila do keřů nacházejících se několik desítek metrů od silnice .
rodila cestou do školy
přišlo to na mne asi trochu dřív .
byla jsem na cestě do školy .
v autobuse jsem měla potřebu jít na záchod , tam jsem porodila .
narodila se živá , koukala na mne .
pupečníkovou šňůru jsem přestřihla nůžkami , které jsem nosila do školy , &quot; popsala obžalovaná a uvedla , že se za těhotenství prý styděla .
&quot; následujícího dne se na místo vrátila , tělo dítěte vložila do batohu a odvezla , tělo vyjmula z batohu , zabalila do černého igelitového pytle a ukryla a zanechala pod schodištěm v domě své babičky v havlíčkově brodě , &quot; stojí v žalobě s tím , že není zcela zřejmé , kdy došlo k smrti novorozence .
mohlo to být za desítky minut , ale i několik hodin po porodu , udušením při zakrytí dekou nebo při vložení pod bundu , podchlazením či vykrvácením z nepodvázaného pupečníku .
obdobný scénář se opakoval příští rok na jaře .
žena v blíže nezjištěné době od února do 12. dubna , kdy byla mrtvolka dítěte nalezena náhodnými svědky pod křoviskem u rybníka na havlíčkobrodsku , zase sama tajně porodila .
tentokrát v koupelně podkrovního bytu v rodinném domě .
aniž si ověřila , zda se narodilo živé , aniž přestřihla a podvázala pupečník , který byl obtočený okolo krku , vložila dítě do několika plastových obalů včetně igelitové tašky a nechala ho v koupelně .
následně v odpoledních hodinách ho spolu s tehdejším partnerem odvezli k rybníku .
nakonec ji udal přítel
otcem obou dětí byl právě přítel obžalované , který ale údajně o těhotenstvích partnerky nevěděl .
i z toho důvodu nestojí nyní před soudem , pouze byl potrestán za prohřešek proti zákonu o pohřebnictví .
byl to také on , kdo se později obrátil na policii .
nelíbí se mi , že není potrestán jako spoluviník .
s dítětem manipuloval proti mému přání .
vím , že moje řešení nebylo správné , ale přišlo mi v tu chvíli jako lidské , &quot; neskrývala rozhořčení obžalovaná , která údajně ve vztahu muži podléhala a bála se ho .
v průběhu své výpovědi hovořila mladá žena poměrně vyrovnaně .
slzy do očí jí vehnal až okamžik , kdy hovořila o vztahu k rodičům , od nichž po dosažení plnoletosti sama odešla .
nechtěla prý zabíjet
&quot; jezdí za mnou každých 14 dní na návštěvu , dělají pro mne úplně všechno , i když vím , že si to nezasloužím , &quot; vzlykla .
nepořizovala jsem si výbavičku , protože jsem děti nechtěla , připadala jsem si mladá .
furt jsem ho chtěla dát do babyboxu , ale nevím , co se stalo , že jsem tak neudělala .
to vám vysvětlit nedokážu , &quot; odpověděla na dotaz soudci .
odmítla však , že by jednala s rozmyslem a úmyslem novorozence zabít .
druhé dítě se podle jejího tvrzení navíc narodilo mrtvé .
ani v těhotenství ale nepřestala pít alkohol .
omezila jsem to však .
a nepila tvrdý .
i kouření jsem omezila , &quot; uvedla .
ačkoliv na ní těhotenství bylo v obou případech vidět , všem i na opakované dotazy tvrdila , že má zdravotní potíže , že je zavodněná .
a to i příteli .
hlavní líčení bude u hradeckého soudu pokračovat v úterý výpověďmi soudních znalců .
ve středu by již mohl být vynesen rozsudek .
žena je ohrožena trestní sazbou až 18 let vězení , případně i trestem výjimečným .
norwegian cruise se blíží třímiliardovému odkoupení společnosti prestige cruise
podle zdrojů seznámených s celou záležitostí , pokročila společnost norwegian cruise line holdings s.r.o. ( nchl.o ) , třetí největší provozovatel výletních plaveb lodí na světě , ve vyjednávání o koupi prestige cruises international inc. přibližně za tři miliardy dolarů .
obchod by norwegian cruise , společnosti s tržní hodnotou 6,8 miliard dolarů , která soupeří s větší konkurencí royal carrebian cruises s.r.o. ( rcl.n ) a carnival corp ( ccl.n ) , umožnil přístup k luxusním výletním lodím prestige cruises a bohaté klientele .
dohoda může být zveřejněna již tento týden , prozradil v neděli zdroj , ale upozornil , že jednání stále nemusí skončit úspěšně .
majitel prestige cruises , soukromé investiční společnosti apollo global management llc ( apo.n ) , vlastní také dvacetiprocentní podíl v norwegian cruise .
zdroje si nepřály být jmenovány , protože jednání nejsou veřejná .
představitelé norwegian cruise a prestige cruises na žádosti o komentář neodpověděli , mluvčí apollo odmítl situaci komentovat .
norwegian cruise se sídlem v miami provozuje třináct výletních lodí na plavbách v severní americe , středozemním moři a baltském moři , střední americe a karibiku .
příjem firmy v roce 2013 byl 2,57 miliard dolarů , o 13 % více než v roce 2012 .
prestige cruises působí pod značkami oceania a regent , které dohromady vlastní osm výletních lodí plujících do skandinávie , ruska , středozemí , severní ameriky , asie , afriky a jižní ameriky .
společnost v roce 2013 oznámila tržby ve výši 1,2 miliardy dolarů , o 6 % více než v předchozím roce .
očekává se , že devětadvaceti miliardový segment výletních plaveb bude v nadcházejícím roce profitovat ze vzestupu střední třídy v rostoucích ekonomikách jako je čína a indie .
společnosti soutěží o to , aby se u těchto zákazníků staly preferovanou možností při výběru výletních plaveb .
společnost prestige cruises u amerických regulačních úřadů registrovala první veřejnou nabídku v lednu 2014 .
apollo má ve společnosti většinový podíl od roku 2007 od uzavření obchodu v hodnotě 850 milionů dolarů .
norwegian cruise existuje ve své současné podobě od roku 2000 , kdy došlo ke sloučení s provozovatelem výletních plaveb vlastněným genting bhd ( gent.kl ) , konsorciem podniků zabývajících se trávením volného času a kasiny , které kontroluje malajsijský miliardář lim kok thay .
v roce 2008 investovalo apollo do norwegian cruise jednu miliardu dolarů .
společnost norwegian cruise uvedla akcie na burzu v lednu 2013 .
podle registrace u regulačních úřadů ke konci června vlastnil genting kapitálový podíl 28 % , apollo 20 % a soukromá investiční společnost tpg capital lp 8 % .
podle registrační dokumentace první veřejné nabídky zahrnují carnival , royal caribbean cruises a norwegian cruise dohromady 82 % objemu severoamerických pasažérů .
prodemokratičtí aktivisté v hongkongu den po rozhodnutí o hlasování provokují čínské úřady
poblíž postávala skupina lidí loajálních k pekingu , kteří mávali čínskou vlajkou .
stálá komise národního lidového kongresu v neděli schválila , aby se voleb v roce 2017 v hongkongu zúčastnili pouze dva ze tří kandidátů .
všichni kandidáti musí nejdříve získat podporu jmenovací komise , která se bude pravděpodobně skládat ze členů věrných pekingu .
kvůli tomuto rozhodnutí je pro opoziční demokraty téměř nemožné dostat se na volební lístky a přimět pro-demokratické aktivisty obnovit slib a ochromit finanční centrum hongkongu protesty hnutí „ okupace centrálu “ .
v hongkongu je politická reforma hlavním důvodem napětí , čínští vedoucí představitelé se obávají , že požadavek na demokratizaci se rozšíří do dalších měst .
poté , co peking v červnu zveřejnil podrobnou zprávu nastiňující čínskou úřední pravomoc v hongkongu , demokratičtí aktivisté uspořádali neoficiální referendum o volbách ve zvláštním úředním obvodu a stovky tisíc lidí vpochodovaly do městské obchodní čtvrti a obsadily ji .
tiskovou konferenci , na které vystoupí premiér li , organizuje vláda v hongkongu a čínský styčný úřad v hongkongu .
během dne měli na několik tiskových konferencích promluvit také místopředseda stálého výboru legislativní komise zhang ronghsun a náměstek ředitele státní rady úřadu pro záležitosti hongkongu a macau feng wei .
studenští aktivisté prohlásili , že se odpoledne shromáždí před kanceláří vlády hongkongu .
do posledních dní koloniální vlády před 150 lety se británie nikdy o demokracii v hongkongu nezmínila .
putin žádá kyjev , aby s východní ukrajinou zahájil jednání o „ státní suverenitě “
podle popisu událostí ruskými novinami požádal v neděli ruský prezident vladimír putin , aby ukrajinská vláda zastavila boje se separatisty na východě země a okamžitě zahájila jednání o „ státní suverenitě “ odtržených oblastí .
jeho mluvčí dmitrij peskov později vysvětlil , že putin svou poznámkou neměl v úmyslu naznačit , že oblasti východní ukrajiny pod kontrolou separatistů se stanou součástí ruska , ale že jejich status v rámci ukrajiny by měl být přehodnocen , aby rusky hovořící oblast dostala pravomoc k ochraně svých práv a zájmů .
putinova výzva kyjevské vládě , aby jednala s proruskými povstalci jako se sobě rovnými , odpovídá zjevné strategii , podle které se řídí od vypuknutí nepokojů před pěti měsíci : pomozte separatistům obsadit území a donuťte ukrajinskou vládu udělit nově vyhlášenému novorusku faktickou nezávislost , aby se místo se západem mohl spojit s ruskem .
v rozhovoru pro první kanál státní televize putin odsoudil ukrajinské vojenské akce , které mají znovu získat východní oblasti doněcka a luhansku , které v březnu a dubnu ovládli separatisté poté , co moskva 18. března anektovala krymský poloostrov patřící ukrajině .
kreml a separatisté nedávno obsazené území označili jako „ novorusko “ nebo „ nové rusko “ , termínem , který odkazuje na slavné předrevoluční dny ruského impéria .
ruská tisková agentura itar-tass zveřejnila putinova slova , podle kterých je „ vězeň iluzí “ každý , kdo věří , že na obzoru jsou mírová jednání , protože ukrajinští politikové zahájili před parlamentními volbami 26. října kampaně , zatímco vládní jednotky napadají civilní obyvatelstvo v oblastech ovládaných separatisty .
„ v zájmu lidí žijících v těchto oblastech musíme neprodleně zahájit smysluplná jednání a to ne pouze o právních záležitostech , ale také o politické organizaci společnosti a o statutu státní suverenity jihovýchodu ukrajiny , “ prohlásil .
peskov řekl , že putinova narážka na státní suverenitu byla myšlena v kontextu širší autonomie , o které se s vedením kyjeva jedná již několik měsíců a která má zmírnit obavy rusky hovořících oblastí z ohrožení kulturních a jazykových práv.
peskov uvedl , že potřebnou autonomii může východním oblastem udělit pouze ukrajinská vláda .
nejedná se o záležitost k projednání mezi ukrajinou a ruskem , řekl peskov , „ protože se nejedná o konflikt mezi ruskem a ukrajinou , ale o vnitřní ukrajinský konflikt . “
zakročení mluvčího kremlu , které mělo korigovat „ nesprávnou interpretaci “ putinových poznámek , zdůraznilo přístup vedení ruska k řešení povstání separatistů na východě , který je odlišný od otevřeného obsazení krymu , kde se většina z dvoumilionové populace původem řadí k etnickým rusům .
moskva by měla mnohem větší potíže anektovat i doněck a luhansk na východě ukrajiny , neboť většina z 6,5 milionu obyvatel nejsou rusové a průzkumy veřejného mínění , které proběhly ještě před konfliktem , ukázaly širokou podporu setrvání na ukrajině .
autonomie , o které ruští diplomaté jednali na mezinárodních fórech , by regionálním vládám na ukrajině dala pravomoc určovat své vlastní obchodní dohody a mezinárodní vztahy , a v podstatě tak dát kremlu faktickou kontrolu nad územím , které by spojilo ruskou pevninu s krymem .
černomořský poloostrov anektovaný před pěti měsíci je sídlem hlavní ruské námořní flotily , námořního obchodního zázemí i historických pobřežních resortů .
oblasti mezi ruským rostovem a krymem jsou také střediskem dolů , továren a sléváren , které vyrábějí důležité komponenty pro ruskou armádu .
ukrajinský prezident petro porošenko během svého inauguračního projevu ze 7. června navrhl , aby ukrajinští zákonodárci - po nových volbách - zvážili změny v ústavě , které by různorodým regionům daly více kontroly nad jejich financemi a jazykovým statutem .
tato vize autonomie se ale značně liší od vize kremlu a separatistů . moskva je obviňována z vyzbrojování a podněcování násilí .
putinova poslední výzva , aby kyjev jednal se separatisty jako se sobě rovnými následovala po dalším postupu povstalců minulý týden poté , co na východní ukrajinu pronikly ruské jednotky a tanky z dříve klidné oblasti podél azovského moře .
separatisté posíleni rusy převzali kontrolu nad novoazovskem takovou silou , že se ukrajinské bezpečnostní orgány obávají , že se jedná o tažení s cílem obsadit strategické pobřežní území až na krym .
to uspíšilo obrovskou civilní i vojenskou snahu opevnit mariupol , přístav s metalurgickými kombináty o 500 000 obyvatelích , který leží mezi novoazovskem a úzkou vstupní branou na krymský poloostrov .
porošenko v sobotu vystoupil na meetingu čelních představitelů evropské unie v bruselu a vybízel k akci , která by zabránila další ruské agresi proti ukrajině , bývalé sovětské republice , která je posledních 23 let nezávislá .
„ blížíme se k bodu , ze kterého není návratu , “ varoval porošenko .
na území ukrajiny se nyní nachází tisíce cizích vojenských jednotek a stovky cizích tanků .
summit eu nepodnikl žádné definitivní kroky - lídři vyzývají k přijetí dalších sankcí proti rusku v případě blíže nespecifikované eskalace ukrajinské krize .
plukovník andrij lysenko , mluvčí ukrajinské národní bezpečnostní a obranné rady v sobotu reportérům v kyjevě řekl , že ukrajinští vojáci se museli stáhnout ze svých pozic v ilovajsku poté , co minulý týden dvě kolony ruských obrněných vozidel a 1 000 vojenských jednotek proniklo do doněcké oblasti , aby podpořily obléhané separatisty .
první ze 63 nahlášených ukrajinských vojáků , kteří byli zajati v ilovajsku při ruské invazi , byli v neděli vyměněni za 10 ruských výsadkářů zajatých před týdnem ve vnitrozemí ukrajiny , uvedl v neděli lysenko .
ve skandálu s odhalenými fotkami jsou zapleteny i australské celebrity a gabi grecko
geoffrey edelsten vyjádřil své znechucení nad hackery , kteří pravděpodobně ukradli intimní fotky jeho snoubenky gabi grecko a dalších vlivných hollywoodských hvězd .
tinseltown je v šoku poté , co se v největším skandálu s hacknutými fotografiemi celebrit dostala na internet série explicitních fotek nahé jennifer lawrencové .
hacker tvrdí , že má šedesát fotek s nahou hvězdou hunger games lawrencovou a dalších hvězd včetně kate uptonové a cary delevingne , zpěvaček rihanny , ariany grande a ley michellové a herečky kirsten dunstové .
kvůli úniku z icloud se na veřejnost údajně dostaly i osobní snímky australských hereček teresy palmerové , emily browningové , yvonne strahovski a melbournské herečky grecko .
na seznamu je 101 celebrit .
edelsten , který grecko požádal o ruku minulý měsíc , magazínu confidential řekl : „ je to nechutné . “
všechna soukromá korespondence a všechny soukromé obrázky by soukromé měly zůstat .
je ostuda , že se osobní informace dají ukrást a rozšířit na veřejnost .
grecko , která je nyní v new yorku , podle zpravodajů online novinám sdělila , že hacknutí je „ nestydaté “ a ti , kteří se stali jeho terčem , si „ připadají ponížení “ .
má se za to , že hacker získal třicet fotek palmerové s bývalým přítelem scottem speedmanem včetně dvou snímků , na kterých se nahoře bez rozvaluje u bazénu .
palmerová účinkovala například ve filmu láska a čest , kde byl jejím protějškem liam hemsworth .
palmerová , hvězda televizní série chuck strahovski a herečka z thrilleru sucker punch browningová včera ukradené snímky nekomentovaly .
zástupce lawrencové tmz řekl : „ jde o jasné porušení soukromí . “
herec seth rogen hackera na svém twitteru kritizoval : „ zveřejňovat fotky z hacknutých telefonů je úplně stejné jako prodávat ukradené zboží . “
z právního hlediska by se zveřejňování ukradených snímků nemělo tolerovat .
fotbalisté sigmy si lébra udobřili , i bez výhry
olomouc - hromy a blesky , které spolumajitel olomoucké sigmy josef lébr sesílal na své podřízené minulý týden , jsou , zdá se , minulostí .
byť z opavy přivezli nakonec jenom bod za bezbrankovou remízu .
nasazením a bojovností si klubového bosse přece jen trochu udobřili .
peníze na výplaty by do klubu brzy mohly přijít .
&quot; nechám si ještě jeden zápas , jak jsem o tom mluvil minulý týden , ale jsem už daleko optimističtější , &quot; potvrdil lébr , že navzdory tomu , že sigma nevyhrála , jej hráči zlepšeným výkonem přesvědčili .
bojovnost a nasazení , se kterým jsme hráli hlavně ve druhém poločase , bylo přesně to , co chci od hráčů vidět .
v takovém případě jsem schopen odpustit , že se nevyhraje .
kdybychom tak hráli od začátku sezony , tak jsem přesvědčen , že jsme ještě neprohráli , &quot; myslí si lébr .
sigma v opavě přestála úvodní tlak domácích , pak hru vyrovnala a ve druhé půli už byla lepší .
po vítězství kalvodovi svěřenci sahali , ale své možnosti nedotáhli ke gólu , a tak vyhrát nemohli .
výsledek sice není podle našich představ .
k úplné spokojenosti nám chyběla ale jen jedna proměněná šance , &quot; prohlásil lébr , který si ale nemyslí , že změnu v přístupu fotbalistů způsobila jen jeho výhrůžka .
bylo tam určitě více aspektů .
ať už z mojí strany , ze strany trenéra , nebo fanoušků , &quot; řekl lébr .
s tlakem musí sigma počítat
hráčům se po zápase v opavě události z minulého týdne moc komentovat nechtělo .
tyhle věci se snažím dát úplně pryč .
snažil jsem si to nepřipouštět , &quot; kroutil hlavou mladý brankář michal reichl .
úplně bez komentáře pak nechal otázku na lébrova prohlášení z minulého týdne útočník václav vašíček , který neproměnil největší příležitost sigmy v sobotním zápase .
posléze se ale přece jen trošičku o tlaku rozpovídal .
pod tlakem budeme pořád .
všichni se na nás chtějí vytáhnout .
dnes jsme ukázali , že když budeme bojovat a jezdit všichni po prdeli , tak to půjde , &quot; řekl .
varování si vzali k srdci
ani kouč leoš kalvoda nezastíral , že příprava na zápas nebyla nejjednodušší vzhledem k atmosféře , která v olomouci v minulém týdnu panovala .
bylo to dost těžké .
ale myslím , že kluci si to uvědomili , a dnes bylo vidět , že si to varování pana lébra vzali k srdci .
i když ani předtím to nebylo o tom , že by nechtěli bojovat a odflákli to , &quot; mínil olomoucký trenér .
bylo to podobné jako dnes prvních patnáct minut .
trvalo , než jsme se srovnali s tvrdostí a uvědomili si , o čem druhá liga je .
že to není jen o fotbalovosti , ale hlavně o té bojovnosti , &quot; řekl kalvoda .
nezbývá než doufat , že v příštích zápasech už to sigmě bude fungovat od začátku .
&quot; hrozně rád bych tomu věřil , &quot; dodal .
